import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image
import stepic

def encode_image():
    file_path = filedialog.askopenfilename(title="Select Image", filetypes=[("Image Files", "*.png;*.jpg;*.jpeg")])
    if not file_path:
        return
    
    # Show the message entry box
    message_entry_label.pack(pady=5)
    message_entry.pack(pady=5)
    submit_button.pack(pady=5)

    def encode_message():
        message = message_entry.get()
        if not message:
            messagebox.showerror("Error", "Please enter a message.")
            return
        
        img = Image.open(file_path)
        encoded_img = stepic.encode(img, message.encode())
        
        save_path = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG Files", "*.png")])
        if save_path:
            encoded_img.save(save_path)
            messagebox.showinfo("Success", "Message encoded successfully.")
        
        message_entry.delete(0, tk.END)
        message_entry_label.pack_forget()
        message_entry.pack_forget()
        submit_button.pack_forget()

    submit_button.config(command=encode_message)

def decode_image():
    file_path = filedialog.askopenfilename(title="Select Image", filetypes=[("Image Files", "*.png;*.jpg;*.jpeg")])
    if not file_path:
        return
    
    img = Image.open(file_path)
    decoded_message = stepic.decode(img).encode()
    messagebox.showinfo("Decoded Message", decoded_message)

# Tkinter window setup
root = tk.Tk()
root.title("Image Steganography")
root.geometry("500x300")
root.eval('tk::PlaceWindow . center')  # Center window on screen

# Styling the UI
root.configure(bg="#f0f0f0")
title_label = tk.Label(root, text="Steganography - Encode & Decode", font=("Helvetica", 16), bg="#f0f0f0", fg="#2e8b57")
title_label.pack(pady=20)

button_frame = tk.Frame(root, bg="#f0f0f0")
button_frame.pack(pady=10)

# Encode button
encode_button = tk.Button(button_frame, text="Encode Image", font=("Helvetica", 12), bg="#3498db", fg="white", command=encode_image)
encode_button.pack(side=tk.LEFT, padx=20)

# Decode button
decode_button = tk.Button(button_frame, text="Decode Image", font=("Helvetica", 12), bg="#e74c3c", fg="white", command=decode_image)
decode_button.pack(side=tk.LEFT, padx=20)

# Message entry for encoding
message_entry_label = tk.Label(root, text="Enter message to encode:", font=("Helvetica", 12), bg="#f0f0f0")
message_entry = tk.Entry(root, font=("Helvetica", 12), width=40)

# Submit button
submit_button = tk.Button(root, text="Submit", font=("Helvetica", 12), bg="#2ecc71", fg="white")

root.mainloop()
