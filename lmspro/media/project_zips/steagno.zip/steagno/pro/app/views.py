from django.shortcuts import render,HttpResponse,redirect
from django.contrib.auth import authenticate,login
from django.contrib.auth.models import User
from .models import Contact
# Create your views here.
def home(request):
    return render(request,"home.html")
    
def about(request):
    return render(request,"about.html")

def text(request):
    return render(request,"text.html")

def audio(request):
    return render(request,"audio.html")

def video(request):
    return render(request,"video.html")

def image(request):
    return render(request,"image.html")

def callback(request):
    callbacks=Contact.objects.all()
    return render(request,"callback.html",{'callbacks':callbacks})

def users(request):
    userdetails=User.objects.all()
    return render(request,"userdetails.html",{'userdetails':userdetails})

def adminlogin(request):
    if request.method == 'POST':
        uname = request.POST.get('username')
        password = request.POST.get('pass')
        if password == '!@#$': 
            return render(request, 'admindash.html')
        else:
            error_message = 'Please enter valid credentials.' 
            return render(request, 'admin.html', {'error_message': error_message})
    else:
        return render(request,"admin.html")

def admindashboard(request):
    return render(request,"admindash.html")

def reg(request):
    if request.method=='POST':
        uname=request.POST.get('username')
        email=request.POST.get('email')
        pass1=request.POST.get('password1')
        pass2=request.POST.get('password2')
        
        if pass1!=pass2:
            return HttpResponse("Your password and confrom password are not Same!!")
        else:

            my_user=User.objects.create_user(uname,email,pass1)
            my_user.save()
            return redirect('/login/')
    return render(request,"reg.html")

def loginn(request):
    error_message = None  # Initialize error message variable
    
    if request.method == 'POST':
        username = request.POST.get('username')
        pass1 = request.POST.get('pass')
        user = authenticate(request, username=username, password=pass1)
        
        if user is not None:
            login(request, user)
            return redirect('/home/')
        else:
            error_message = "Username or Password is incorrect!!!"
    return render(request,"login.html",{'error_message':error_message})

def contact(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        mobile= request.POST.get('mobile')
        email = request.POST.get('email')
        message = request.POST.get('message')
        feedback = Contact(name=name,mobile=mobile,email=email,message=message)
        feedback.save()
    return render(request,"contact.html")

import subprocess

from django.shortcuts import render
from django.http import HttpResponse

def run_text_script(request):
    if request.method == "POST":
        # Run your Python script here
        try:
            subprocess.Popen(["C:/Users/Udaykumar.Botte/AppData/Local/Programs/Python/Python312/python.exe", "app/text.py"])
 # Adjust this to point to your Python script
            return HttpResponse("Script executed successfully!")
        except Exception as e:
            return HttpResponse(f"Error: {e}")
    else:
        return HttpResponse("Invalid request method.")
    
def run_video_script(request):
    if request.method == "POST":
        # Run your Python script here
        try:
            subprocess.Popen(["C:/Users/Udaykumar.Botte/AppData/Local/Programs/Python/Python312/python.exe", "app/video.py"])
 # Adjust this to point to your Python script
            return HttpResponse("Script executed successfully!")
        except Exception as e:
            return HttpResponse(f"Error: {e}")
    else:
        return HttpResponse("Invalid request method.")
    
def run_image_script(request):
    if request.method == "POST":
        # Run your Python script here
        try:
            subprocess.Popen(["C:/Users/Udaykumar.Botte/AppData/Local/Programs/Python/Python312/python.exe", "app/image.py"])
 # Adjust this to point to your Python script
            return HttpResponse("Script executed successfully!")
        except Exception as e:
            return HttpResponse(f"Error: {e}")
    else:
        return HttpResponse("Invalid request method.")

