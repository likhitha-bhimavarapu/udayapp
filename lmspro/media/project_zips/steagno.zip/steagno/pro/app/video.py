import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter import ttk
from stegano import lsb
import os
import shutil
import cv2
import numpy as np
import math
from subprocess import call, STDOUT

# Functions for splitting string, frame extraction, encoding, and decoding
def split_string(s_str, count=10):
    per_c = math.ceil(len(s_str) / count)
    c_cout = 0
    out_str = ''
    split_list = []
    for s in s_str:
        out_str += s
        c_cout += 1
        if c_cout == per_c:
            split_list.append(out_str)
            out_str = ''
            c_cout = 0
    if c_cout != 0:
        split_list.append(out_str)
    return split_list

def frame_extraction(video):
    if not os.path.exists("./tmp"):
        os.makedirs("tmp")
    temp_folder = "./tmp"
    print("[INFO] tmp directory is created")

    vidcap = cv2.VideoCapture(video)
    count = 0
    while True:
        success, image = vidcap.read()
        if not success:
            break
        cv2.imwrite(os.path.join(temp_folder, "{:d}.png".format(count)), image)
        count += 1

def encode_string(input_string, root="./tmp/"):
    split_string_list = split_string(input_string)
    for i in range(0, len(split_string_list)):
        f_name = "{}{}.png".format(root, i)
        secret_enc = lsb.hide(f_name, split_string_list[i])
        secret_enc.save(f_name)
        print("[INFO] frame {} holds {}".format(f_name, split_string_list[i]))

def decode_string(video):
    frame_extraction(video)
    secret = []
    root = "./tmp/"
    for i in range(len(os.listdir(root))):
        f_name = "{}{}.png".format(root, i)
        secret_dec = lsb.reveal(f_name)
        if secret_dec is None:
            break
        secret.append(secret_dec)

    decoded_message = ''.join([i for i in secret])
    messagebox.showinfo("Decoded Message", decoded_message)
    clean_tmp()

def clean_tmp(path="./tmp"):
    if os.path.exists(path):
        shutil.rmtree(path)
        print("[INFO] tmp files are cleaned up")

# Tkinter GUI
class SteganographyApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Steganography Application")

        self.frame = ttk.Frame(self.root, padding="10")
        self.frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        # Input fields
        self.label_file = ttk.Label(self.frame, text="Video File:")
        self.label_file.grid(row=0, column=0, sticky=tk.W)
        self.entry_file = ttk.Entry(self.frame, width=50)
        self.entry_file.grid(row=0, column=1, padx=5, pady=5)

        self.button_browse = ttk.Button(self.frame, text="Browse", command=self.browse_file)
        self.button_browse.grid(row=0, column=2, padx=5, pady=5)

        self.label_message = ttk.Label(self.frame, text="Message:")
        self.label_message.grid(row=1, column=0, sticky=tk.NW)
        self.text_message = tk.Text(self.frame, height=5, width=50)
        self.text_message.grid(row=1, column=1, columnspan=2, padx=5, pady=5)

        self.button_encode = ttk.Button(self.frame, text="Encode Message", command=self.encode_message)
        self.button_encode.grid(row=2, column=1, padx=5, pady=5, sticky=tk.W)

        self.button_decode = ttk.Button(self.frame, text="Decode Message", command=self.decode_message)
        self.button_decode.grid(row=2, column=2, padx=5, pady=5, sticky=tk.E)

    def browse_file(self):
        filename = filedialog.askopenfilename(filetypes=[("Video Files", "*.mp4 *.avi *.mov")])
        if filename:
            self.entry_file.delete(0, tk.END)
            self.entry_file.insert(0, filename)

    def encode_message(self):
        input_string = self.text_message.get("1.0", tk.END).strip()
        video_file = self.entry_file.get().strip()
        if not input_string or not video_file:
            messagebox.showerror("Error", "Please provide both the message and the video file.")
            return

        frame_extraction(video_file)
        call(["ffmpeg", "-i", video_file, "-q:a", "0", "-map", "a", "tmp/audio.mp3", "-y"], stdout=open(os.devnull, "w"), stderr=STDOUT)
        encode_string(input_string)
        call(["ffmpeg", "-i", "tmp/%d.png", "-vcodec", "png", "tmp/video.mov", "-y"], stdout=open(os.devnull, "w"), stderr=STDOUT)
        call(["ffmpeg", "-i", "tmp/video.mov", "-i", "tmp/audio.mp3", "-codec", "copy", "video_with_message.mov", "-y"], stdout=open(os.devnull, "w"), stderr=STDOUT)
        clean_tmp()
        messagebox.showinfo("Success", "Message encoded successfully. Saved as 'video_with_message.mov'.")

    def decode_message(self):
        video_file = self.entry_file.get().strip()
        if not video_file:
            messagebox.showerror("Error", "Please provide the video file.")
            return

        decode_string(video_file)

if __name__ == "__main__":
    root = tk.Tk()
    app = SteganographyApp(root)
    root.mainloop()
