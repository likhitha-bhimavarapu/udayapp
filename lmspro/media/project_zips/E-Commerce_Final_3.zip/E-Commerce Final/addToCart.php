<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $product = $_POST['product'];
    $price = $_POST['price'];
    $quantity = $_POST['quantity'];

    $cartItem = [
        'product' => $product,
        'price' => $price,
        'quantity' => $quantity
    ];

    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    // Add item to the session cart
    $_SESSION['cart'][] = $cartItem;

    // Set a flag to indicate the item was added successfully
    $_SESSION['item_added'] = true;

    // Redirect back to the referring page
    header("Location: " . $_SERVER["HTTP_REFERER"]);
    exit();
}
?>
