<?php
// Database credentials
$servername = "localhost";
$username = "root";
$password = "";
$database = "ecommerceOne";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

echo "Connected successfully";
// Handle search query
if (isset($_GET['query'])) {
    $search_query = htmlspecialchars($_GET['query']);
    // Perform search in the database
    // Replace this with your actual database query
    $connection = mysqli_connect("localhost", "username", "password", "database");
    $query = "SELECT * FROM products WHERE name LIKE '%$search_query%'";
    $result = mysqli_query($connection, $query);
    $products = mysqli_fetch_all($result, MYSQLI_ASSOC);
    mysqli_close($connection);
}
?>
<!-- Display search results -->
<?php if (isset($products) && !empty($products)) : ?>
    <h2>Search Results for "<?php echo $search_query; ?>"</h2>
    <ul>
        <?php foreach ($products as $product) : ?>
            <li>
                <a href="product_details.php?id=<?php echo $product['id']; ?>">
                    <?php echo $product['name']; ?>
                </a>
            </li>
        <?php endforeach; ?>
    </ul>
<?php else : ?>
    <p>No products found for "<?php echo $search_query; ?>"</p>
<?php endif; ?>
