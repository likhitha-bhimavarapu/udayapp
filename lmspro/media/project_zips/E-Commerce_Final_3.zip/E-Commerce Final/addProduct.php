<?php
// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Clear form inputs by setting empty values
    $productName = "";
    $description = "";
    $price = "";
    $category = "";
} else {
    // Default values for the form when it's loaded initially
    $productName = "";
    $description = "";
    $price = "";
    $category = "";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Product</title>

</head>
<style>
    :root {
        --primary: #4361ee;
        --secondary: #ef476f;
        --success: #06d6a0;
        --warning: #ffd166;
        --info: #118ab2;
        --light: #f8f9fa;
        --dark: #212529;
        --gray: #6c757d;
        --gray-light: #e9ecef;
        --gray-dark: #343a40;
        --border-radius: 12px;
        --box-shadow: 0 10px 20px rgba(0, 0, 0, 0.05);
        --transition: all 0.3s ease;
    }
    
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }
    
    body {
        font-family: 'Poppins', sans-serif;
        min-height: 100vh;
        background: linear-gradient(135deg, #f5f7ff 0%, #e8eeff 100%);
        position: relative;
        overflow-x: hidden;
        padding-bottom: 60px;
    }
    
    body::before {
        content: '';
        position: absolute;
        top: 0;
        right: 0;
        width: 400px;
        height: 400px;
        background: radial-gradient(circle, rgba(239, 71, 111, 0.1) 0%, rgba(239, 71, 111, 0) 70%);
        z-index: -1;
    }
    
    body::after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        width: 300px;
        height: 300px;
        background: radial-gradient(circle, rgba(67, 97, 238, 0.1) 0%, rgba(67, 97, 238, 0) 70%);
        z-index: -1;
    }
    
    .product-form-container {
        max-width: 650px;
        margin: 40px auto;
        padding: 0 15px;
    }
    
    .product-form-card {
        background: white;
        border-radius: var(--border-radius);
        box-shadow: var(--box-shadow);
        overflow: hidden;
        border: none;
        position: relative;
        transition: var(--transition);
    }
    
    .product-form-card:hover {
        box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
    }
    
    .form-header {
        background: linear-gradient(135deg, var(--primary) 0%, #3a56d4 100%);
        padding: 25px 30px;
        position: relative;
        overflow: hidden;
    }
    
    .form-header::before {
        content: '';
        position: absolute;
        top: -50px;
        right: -50px;
        width: 150px;
        height: 150px;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.1);
    }
    
    .form-header::after {
        content: '';
        position: absolute;
        bottom: -60px;
        left: -60px;
        width: 180px;
        height: 180px;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.05);
    }
    
    .form-title {
        color: white;
        font-weight: 600;
        margin: 0;
        font-size: 1.8rem;
        position: relative;
        z-index: 1;
        display: flex;
        align-items: center;
        gap: 12px;
    }
    
    .form-title i {
        font-size: 1.5rem;
    }
    
    .form-body {
        padding: 30px;
    }
    
    .form-group {
        margin-bottom: 25px;
        position: relative;
    }
    
    .form-label {
        display: block;
        margin-bottom: 8px;
        font-weight: 500;
        color: var(--dark);
        font-size: 0.95rem;
    }
    
    .form-control {
        height: 50px;
        padding: 10px 15px;
        border-radius: 8px;
        border: 1px solid #dce1e9;
        width: 100%;
        font-family: 'Poppins', sans-serif;
        transition: var(--transition);
        font-size: 0.95rem;
    }
    
    .form-control:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.15);
        outline: none;
    }
    
    textarea.form-control {
        min-height: 120px;
        resize: vertical;
    }
    
    .form-select {
        height: 50px;
        padding: 10px 15px;
        border-radius: 8px;
        border: 1px solid #dce1e9;
        width: 100%;
        font-family: 'Poppins', sans-serif;
        transition: var(--transition);
        font-size: 0.95rem;
        background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%23343a40' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M2 5l6 6 6-6'/%3e%3c/svg%3e");
        background-repeat: no-repeat;
        background-position: right 0.75rem center;
        background-size: 16px 12px;
        appearance: none;
    }
    
    .form-select:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.15);
        outline: none;
    }
    
    .file-upload {
        position: relative;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-direction: column;
        height: 150px;
        border: 2px dashed #dce1e9;
        border-radius: 8px;
        background-color: #f8f9fa;
        transition: var(--transition);
        cursor: pointer;
        overflow: hidden;
    }
    
    .file-upload:hover {
        border-color: var(--primary);
        background-color: rgba(67, 97, 238, 0.05);
    }
    
    .file-upload input[type="file"] {
        position: absolute;
        width: 100%;
        height: 100%;
        top: 0;
        left: 0;
        opacity: 0;
        cursor: pointer;
    }
    
    .file-upload-icon {
        font-size: 2.5rem;
        color: var(--primary);
        margin-bottom: 10px;
    }
    
    .file-upload-text {
        color: var(--gray);
        font-size: 0.9rem;
        text-align: center;
    }
    
    .file-name {
        margin-top: 10px;
        font-size: 0.9rem;
        color: var(--primary);
        font-weight: 500;
        display: none;
    }
    
    .submit-btn {
        background: linear-gradient(135deg, var(--primary) 0%, #3a56d4 100%);
        color: white;
        border: none;
        height: 50px;
        border-radius: 8px;
        font-weight: 600;
        font-size: 1rem;
        cursor: pointer;
        transition: var(--transition);
        width: 100%;
        margin-top: 10px;
        position: relative;
        overflow: hidden;
    }
    
    .submit-btn::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
        transition: 0.5s;
    }
    
    .submit-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(67, 97, 238, 0.3);
    }
    
    .submit-btn:hover::before {
        left: 100%;
    }
    
    .back-btn {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        color: var(--secondary);
        text-decoration: none;
        font-weight: 500;
        padding: 10px 20px;
        border: 1px solid var(--secondary);
        border-radius: 8px;
        transition: var(--transition);
        margin-top: 20px;
    }
    
    .back-btn:hover {
        background-color: var(--secondary);
        color: white;
        transform: translateY(-2px);
    }
    
    .back-btn i {
        font-size: 0.9rem;
    }
    
    /* Animation */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .animate-fade-in-up {
        animation: fadeInUp 0.5s ease forwards;
    }
    
    /* Responsive styles */
    @media (max-width: 767px) {
        .product-form-container {
            padding: 0 10px;
        }
        
        .form-body {
            padding: 20px;
        }
        
        .form-title {
            font-size: 1.5rem;
        }
    }
</style>
<div class="product-form-container animate-fade-in-up">
    <div class="product-form-card">
        <div class="form-header">
            <h3 class="form-title">
                <i class="fas fa-plus-circle"></i>
                Add New Product
            </h3>
        </div>
        
        <div class="form-body">
            <form action="insert_product.php" method="post" enctype="multipart/form-data" id="productForm">
                <div class="form-group">
                    <label for="name" class="form-label">Product Name</label>
                    <input type="text" id="name" name="name" required class="form-control" placeholder="Enter product name">
                </div>
                
                <div class="form-group">
                    <label for="description" class="form-label">Description</label>
                    <textarea id="description" name="description" required class="form-control" placeholder="Enter product description"></textarea>
                </div>
                
                <div class="form-group">
                    <label for="price" class="form-label">Price (₹)</label>
                    <input type="text" id="price" name="price" required class="form-control" placeholder="Enter product price">
                </div>
                
                <div class="form-group">
                    <label for="category" class="form-label">Category</label>
                    <select id="category" name="category" required class="form-select">
                        <option value="">Select Category</option>
                        <option value="f">Fruits & Vegetables</option>
                        <option value="m">Eggs, Fish & Meat</option>
                        <option value="rice">Rice, Dal & Pulses</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="image" class="form-label">Product Image</label>
                    <div class="file-upload">
                        <i class="fas fa-cloud-upload-alt file-upload-icon"></i>
                        <div class="file-upload-text">
                            <p>Drag & drop your image here or click to browse</p>
                            <p class="text-muted">Supported formats: JPG, PNG, GIF</p>
                        </div>
                        <input type="file" id="image" name="image" required accept="image/*">
                    </div>
                    <div class="file-name" id="fileName"></div>
                </div>
                
                <button type="submit" class="submit-btn">
                    <i class="fas fa-save me-2"></i>
                    Add Product
                </button>
            </form>
        </div>
    </div>
    
    <div class="text-center mt-4">
        <a href="admin_dashboard.php" class="back-btn">
            <i class="fas fa-arrow-left"></i>
            Back to Dashboard
        </a>
    </div>
</div>


<!-- Bootstrap JS Bundle (Popper.js included) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // File upload preview
        const fileInput = document.getElementById('image');
        const fileName = document.getElementById('fileName');
        
        fileInput.addEventListener('change', function() {
            if (this.files && this.files[0]) {
                fileName.textContent = this.files[0].name;
                fileName.style.display = 'block';
                
                // Optional: Preview image
                // const reader = new FileReader();
                // reader.onload = function(e) {
                //     // Add image preview if needed
                // }
                // reader.readAsDataURL(this.files[0]);
            }
        });
        
        // Form validation
        const productForm = document.getElementById('productForm');
        const priceInput = document.getElementById('price');
        
        productForm.addEventListener('submit', function(event) {
            // Validate price is a number
            const price = priceInput.value.trim();
            if (isNaN(parseFloat(price)) || !isFinite(price)) {
                event.preventDefault();
                alert('Please enter a valid price');
                priceInput.focus();
            }
        });
    });
</script>