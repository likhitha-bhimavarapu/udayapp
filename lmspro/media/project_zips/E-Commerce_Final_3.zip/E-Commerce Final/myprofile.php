<?php
session_start();
if (!isset($_SESSION["username"]) || !isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ecommerceone";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch bookings only for the logged-in user
$sql = "SELECT * FROM bookings WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();

// Fetch user data
$user_sql = "SELECT username, email, mobile, Avatar FROM register WHERE id = ?";
$user_stmt = $conn->prepare($user_sql);
$user_stmt->bind_param("i", $_SESSION['user_id']);
$user_stmt->execute();
$user_result = $user_stmt->get_result();
$user_data = $user_result->fetch_assoc();
$user_stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile</title>
   
   <!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<!-- jsPDF library for PDF generation -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>

<style>
    :root {
        --primary: #4361ee;
        --primary-dark: #3a56d4;
        --secondary: #ef476f;
        --secondary-dark: #d63d63;
        --success: #06d6a0;
        --warning: #ffd166;
        --info: #118ab2;
        --light: #f8f9fa;
        --dark: #212529;
        --gray: #6c757d;
        --gray-light: #e9ecef;
        --gray-dark: #343a40;
        --border-radius: 12px;
        --box-shadow: 0 10px 20px rgba(0, 0, 0, 0.05);
        --transition: all 0.3s ease;
    }
    
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }
    
    body {
        font-family: 'Poppins', sans-serif;
        background: linear-gradient(135deg, #f5f7ff 0%, #e8eeff 100%);
        color: var(--dark);
        min-height: 100vh;
        padding-bottom: 80px;
    }
    
    .profile-header {
        background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
        color: white;
        padding: 60px 0 100px;
        margin-bottom: -60px;
        position: relative;
        overflow: hidden;
    }
    
    .profile-header::before {
        content: '';
        position: absolute;
        top: -50px;
        right: -50px;
        width: 200px;
        height: 200px;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.1);
    }
    
    .profile-header::after {
        content: '';
        position: absolute;
        bottom: -80px;
        left: -80px;
        width: 300px;
        height: 300px;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.05);
    }
    
    .profile-header h1 {
        font-weight: 700;
        font-size: 2.5rem;
        margin-bottom: 10px;
    }
    
    .profile-header p {
        opacity: 0.9;
        max-width: 600px;
    }
    
    .profile-container {
        position: relative;
        z-index: 10;
    }
    
    .profile-card {
        background: white;
        border-radius: var(--border-radius);
        box-shadow: var(--box-shadow);
        overflow: hidden;
        transition: var(--transition);
        border: none;
        margin-bottom: 30px;
    }
    
    .profile-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
    }
    
    .profile-card-header {
        background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
        padding: 20px;
        border-bottom: 1px solid var(--gray-light);
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
    
    .profile-card-title {
        font-weight: 600;
        color: var(--primary);
        margin: 0;
        display: flex;
        align-items: center;
    }
    
    .profile-card-title i {
        margin-right: 10px;
        background: var(--primary);
        color: white;
        width: 32px;
        height: 32px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 0.9rem;
    }
    
    .profile-card-body {
        padding: 30px;
    }
    
    .avatar-container {
        position: relative;
        width: 150px;
        height: 150px;
        margin: 0 auto 30px;
    }
    
    .avatar {
        width: 150px;
        height: 150px;
        border-radius: 50%;
        object-fit: cover;
        border: 5px solid white;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }
    
    .avatar-placeholder {
        width: 150px;
        height: 150px;
        border-radius: 50%;
        background: linear-gradient(135deg, #e9ecef 0%, #dee2e6 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 3rem;
        color: var(--gray);
        border: 5px solid white;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }
    
    .profile-status {
        position: absolute;
        bottom: 10px;
        right: 10px;
        width: 25px;
        height: 25px;
        border-radius: 50%;
        background: var(--success);
        border: 3px solid white;
    }
    
    .profile-info {
        text-align: center;
        margin-bottom: 30px;
    }
    
    .profile-name {
        font-size: 1.5rem;
        font-weight: 600;
        margin-bottom: 5px;
        color: var(--dark);
    }
    
    .profile-username {
        color: var(--gray);
        margin-bottom: 15px;
    }
    
    .profile-actions {
        display: flex;
        justify-content: center;
        gap: 10px;
        margin-bottom: 30px;
    }
    
    .profile-btn {
        padding: 8px 20px;
        border-radius: 50px;
        font-weight: 500;
        font-size: 0.9rem;
        display: flex;
        align-items: center;
        gap: 8px;
        transition: var(--transition);
    }
    
    .profile-btn-primary {
        background: var(--primary);
        color: white;
        border: none;
    }
    
    .profile-btn-primary:hover {
        background: var(--primary-dark);
        transform: translateY(-2px);
    }
    
    .profile-btn-outline {
        background: transparent;
        color: var(--primary);
        border: 1px solid var(--primary);
    }
    
    .profile-btn-outline:hover {
        background: rgba(67, 97, 238, 0.1);
        transform: translateY(-2px);
    }
    
    .profile-details {
        background: white;
        border-radius: var(--border-radius);
        box-shadow: var(--box-shadow);
        overflow: hidden;
    }
    
    .detail-item {
        padding: 20px 30px;
        border-bottom: 1px solid var(--gray-light);
        display: flex;
        align-items: center;
    }
    
    .detail-item:last-child {
        border-bottom: none;
    }
    
    .detail-icon {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background: rgba(67, 97, 238, 0.1);
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--primary);
        margin-right: 20px;
        flex-shrink: 0;
    }
    
    .detail-content {
        flex: 1;
    }
    
    .detail-label {
        font-size: 0.85rem;
        color: var(--gray);
        margin-bottom: 5px;
    }
    
    .detail-value {
        font-weight: 500;
        color: var(--dark);
    }
    
    .stats-container {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .stat-card {
        background: white;
        border-radius: var(--border-radius);
        box-shadow: var(--box-shadow);
        padding: 20px;
        text-align: center;
        transition: var(--transition);
    }
    
    .stat-card:hover {
        transform: translateY(-5px);
    }
    
    .stat-icon {
        width: 50px;
        height: 50px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 15px;
        font-size: 1.5rem;
    }
    
    .stat-icon.orders {
        background: rgba(67, 97, 238, 0.1);
        color: var(--primary);
    }
    
    .stat-icon.wishlist {
        background: rgba(239, 71, 111, 0.1);
        color: var(--secondary);
    }
    
    .stat-icon.reviews {
        background: rgba(6, 214, 160, 0.1);
        color: var(--success);
    }
    
    .stat-value {
        font-size: 1.8rem;
        font-weight: 700;
        margin-bottom: 5px;
    }
    
    .stat-label {
        color: var(--gray);
        font-size: 0.9rem;
    }
    
    .bookings-section {
        margin-top: 40px;
    }
    
    .section-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 20px;
    }
    
    .section-title {
        font-weight: 600;
        color: var(--dark);
        margin: 0;
    }
    
    .booking-card {
        background: white;
        border-radius: var(--border-radius);
        box-shadow: var(--box-shadow);
        overflow: hidden;
        transition: var(--transition);
        margin-bottom: 20px;
        border: none;
    }
    
    .booking-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
    }
    
    .booking-header {
        background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
        color: white;
        padding: 15px 20px;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
    
    .booking-id {
        font-weight: 600;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    
    .booking-status {
        padding: 5px 12px;
        border-radius: 50px;
        font-size: 0.8rem;
        font-weight: 500;
    }
    
    .status-confirmed {
        background: rgba(6, 214, 160, 0.2);
        color: var(--success);
    }
    
    .booking-body {
        padding: 20px;
    }
    
    .booking-detail {
        margin-bottom: 15px;
        display: flex;
        align-items: flex-start;
    }
    
    .booking-detail-icon {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        background: rgba(67, 97, 238, 0.1);
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--primary);
        margin-right: 15px;
        flex-shrink: 0;
    }
    
    .booking-detail-content {
        flex: 1;
    }
    
    .booking-detail-label {
        font-size: 0.85rem;
        color: var(--gray);
        margin-bottom: 3px;
    }
    
    .booking-detail-value {
        font-weight: 500;
        color: var(--dark);
    }
    
    .booking-footer {
        background: #f8f9fa;
        padding: 15px 20px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        border-top: 1px solid var(--gray-light);
    }
    
    .booking-price {
        font-weight: 600;
        color: var(--primary);
        font-size: 1.1rem;
    }
    
    .booking-actions {
        display: flex;
        gap: 10px;
    }
    
    .booking-btn {
        padding: 6px 15px;
        border-radius: 50px;
        font-size: 0.85rem;
        font-weight: 500;
        display: flex;
        align-items: center;
        gap: 5px;
        transition: var(--transition);
        cursor: pointer;
    }
    
    .booking-btn-primary {
        background: var(--primary);
        color: white;
        border: none;
    }
    
    .booking-btn-primary:hover {
        background: var(--primary-dark);
    }
    
    .booking-btn-outline {
        background: transparent;
        color: var(--primary);
        border: 1px solid var(--primary);
    }
    
    .booking-btn-outline:hover {
        background: rgba(67, 97, 238, 0.1);
    }
    
    .empty-bookings {
        background: white;
        border-radius: var(--border-radius);
        box-shadow: var(--box-shadow);
        padding: 40px 20px;
        text-align: center;
    }
    
    .empty-icon {
        font-size: 4rem;
        color: var(--gray-light);
        margin-bottom: 20px;
    }
    
    .empty-text {
        color: var(--gray);
        margin-bottom: 20px;
        max-width: 400px;
        margin-left: auto;
        margin-right: auto;
    }
    
    .pdf-container {
        display: none;
    }
    
    /* Animation */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .animate-fade-in-up {
        animation: fadeInUp 0.5s ease forwards;
    }
    
    /* Toast notification */
    .toast-container {
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 1000;
    }
    
    .toast {
        background: white;
        border-radius: 8px;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        padding: 15px 20px;
        margin-bottom: 10px;
        display: flex;
        align-items: center;
        gap: 15px;
        animation: slideInRight 0.3s ease forwards;
        max-width: 350px;
    }
    
    .toast-icon {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
    }
    
    .toast-success .toast-icon {
        background: rgba(6, 214, 160, 0.1);
        color: var(--success);
    }
    
    .toast-content {
        flex: 1;
    }
    
    .toast-title {
        font-weight: 600;
        margin-bottom: 3px;
        color: var(--dark);
    }
    
    .toast-message {
        font-size: 0.9rem;
        color: var(--gray);
    }
    
    .toast-close {
        color: var(--gray);
        background: none;
        border: none;
        font-size: 1.2rem;
        cursor: pointer;
        padding: 0;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
    
    /* Responsive styles */
    @media (max-width: 991px) {
        .profile-header {
            padding: 40px 0 80px;
        }
        
        .stats-container {
            grid-template-columns: repeat(3, 1fr);
        }
    }
    
    @media (max-width: 767px) {
        .profile-header {
            padding: 30px 0 70px;
        }
        
        .stats-container {
            grid-template-columns: repeat(1, 1fr);
        }
        
        .booking-header {
            flex-direction: column;
            align-items: flex-start;
            gap: 10px;
        }
        
        .booking-footer {
            flex-direction: column;
            align-items: flex-start;
            gap: 15px;
        }
        
        .booking-actions {
            width: 100%;
            justify-content: space-between;
        }
    }
</style>
<!-- Profile Header -->
<div class="profile-header">
    <div class="container">
        <h1>My Profile</h1>
        <p>Manage your account information and view your booking history</p>
    </div>
</div>

<div class="container profile-container">
    <div class="row">
        <!-- Profile Information -->
        <div class="col-lg-4 mb-4">
            <div class="profile-card animate-fade-in-up">
                <div class="profile-card-header">
                    <h5 class="profile-card-title">
                        <i class="fas fa-user"></i>
                        Account Information
                    </h5>
                  
                </div>
                <div class="profile-card-body">
                    <div class="avatar-container">
                        <?php if (!empty($user_data['Avatar'])): ?>
                            <img src="./uploaded_files/<?php echo htmlspecialchars($user_data['Avatar']); ?>" alt="User Avatar" class="avatar">
                        <?php else: ?>
                            <div class="avatar-placeholder">
                                <i class="fas fa-user"></i>
                            </div>
                        <?php endif; ?>
                        <div class="profile-status"></div>
                    </div>
                    
                    <div class="profile-info">
                        <h4 class="profile-name"><?php echo htmlspecialchars($user_data['username']); ?></h4>
                        <p class="profile-username">@<?php echo strtolower(htmlspecialchars($user_data['username'])); ?></p>
                    </div>
                    
                    <div class="profile-actions">
                        <button class="profile-btn profile-btn-primary" id="downloadPdfBtn">
                            <i class="fas fa-download"></i>
                            Download PDF
                        </button>
                    </div>
                    
                    <div class="profile-details">
                        <div class="detail-item">
                            <div class="detail-icon">
                                <i class="fas fa-envelope"></i>
                            </div>
                            <div class="detail-content">
                                <div class="detail-label">Email Address</div>
                                <div class="detail-value"><?php echo htmlspecialchars($user_data['email']); ?></div>
                            </div>
                        </div>
                        
                        <div class="detail-item">
                            <div class="detail-icon">
                                <i class="fas fa-phone"></i>
                            </div>
                            <div class="detail-content">
                                <div class="detail-label">Phone Number</div>
                                <div class="detail-value"><?php echo htmlspecialchars($user_data['mobile']); ?></div>
                            </div>
                        </div>
                        
                        <div class="detail-item">
                            <div class="detail-icon">
                                <i class="fas fa-calendar-alt"></i>
                            </div>
                            <div class="detail-content">
                                <div class="detail-label">Member Since</div>
                                <div class="detail-value"><?php echo date('F Y'); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        
        
        <!-- Bookings Section -->
       
</div>

<!-- PDF Content Container (Hidden) -->
<div id="pdfContent" class="pdf-container">
    <div class="pdf-header">
        <h2>User Profile Report</h2>
        <p>Generated on: <?php echo date('Y-m-d H:i:s'); ?></p>
    </div>
    
    <div class="pdf-user-info">
        <h3>User Information</h3>
        <p><strong>Username:</strong> <?php echo htmlspecialchars($user_data['username']); ?></p>
        <p><strong>Email:</strong> <?php echo htmlspecialchars($user_data['email']); ?></p>
        <p><strong>Phone:</strong> <?php echo htmlspecialchars($user_data['mobile']); ?></p>
    </div>
    
    <div class="pdf-bookings">
        <h3>Booking History</h3>
        <?php 
        // Reset the result pointer
        if ($result->num_rows > 0) {
            $result->data_seek(0);
            while ($booking = $result->fetch_assoc()) {
                echo '<div class="pdf-booking-item">';
                echo '<p><strong>Booking ID:</strong> ' . htmlspecialchars($booking['id']) . '</p>';
                echo '<p><strong>Date:</strong> ' . (isset($booking['booking_date']) ? htmlspecialchars($booking['booking_date']) : date('Y-m-d')) . '</p>';
                echo '<p><strong>Details:</strong> ' . (isset($booking['details']) ? htmlspecialchars($booking['details']) : 'Standard Booking') . '</p>';
                echo '<p><strong>Price:</strong> ₹' . (isset($booking['price']) ? htmlspecialchars($booking['price']) : '1,500') . '</p>';
                echo '</div>';
            }
        } else {
            echo '<p>No bookings found.</p>';
        }
        ?>
    </div>
</div>

<!-- Toast Container -->
<div class="toast-container" id="toastContainer"></div>

<!-- Footer -->
<?php include 'footer.php' ?>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
    // Initialize jsPDF
    window.jsPDF = window.jspdf.jsPDF;
    
    document.addEventListener('DOMContentLoaded', function() {
        // Download Profile PDF
        document.getElementById('downloadPdfBtn').addEventListener('click', function() {
            generateProfilePDF();
        });
        
        // Download Bookings PDF
        document.getElementById('downloadBookingsPdfBtn').addEventListener('click', function() {
            generateBookingsPDF();
        });
        
        // View Details Button
        document.querySelectorAll('.view-details-btn').forEach(button => {
            button.addEventListener('click', function() {
                const bookingId = this.getAttribute('data-id');
                showToast('Booking Details', `Viewing details for booking #${bookingId}`, 'success');
                // In a real application, you would show a modal with booking details
            });
        });
        
        // Download Invoice Button
        document.querySelectorAll('.download-invoice-btn').forEach(button => {
            button.addEventListener('click', function() {
                const bookingId = this.getAttribute('data-id');
                generateInvoicePDF(bookingId);
            });
        });
        
        // Edit Profile Button
        document.getElementById('editProfileBtn').addEventListener('click', function() {
            showToast('Edit Profile', 'Profile editing functionality will be available soon!', 'success');
            // In a real application, you would show a modal for editing profile
        });
    });
    
    // Generate Profile PDF
    function generateProfilePDF() {
        const doc = new jsPDF();
        const username = "<?php echo htmlspecialchars($user_data['username']); ?>";
        const email = "<?php echo htmlspecialchars($user_data['email']); ?>";
        const mobile = "<?php echo htmlspecialchars($user_data['mobile']); ?>";
        const currentDate = new Date().toLocaleString();
        
        // Add styling
        doc.setFillColor(67, 97, 238);
        doc.rect(0, 0, 210, 40, 'F');
        
        // Add title
        doc.setTextColor(255, 255, 255);
        doc.setFontSize(24);
        doc.text('User Profile Report', 105, 20, { align: 'center' });
        doc.setFontSize(12);
        doc.text(`Generated on: ${currentDate}`, 105, 30, { align: 'center' });
        
        // Add user info
        doc.setTextColor(0, 0, 0);
        doc.setFontSize(18);
        doc.text('User Information', 20, 60);
        
        doc.setFontSize(12);
        doc.text(`Username: ${username}`, 20, 75);
        doc.text(`Email: ${email}`, 20, 85);
        doc.text(`Phone: ${mobile}`, 20, 95);
        
        // Add bookings section
        doc.setFontSize(18);
        doc.text('Booking History', 20, 120);
        
        <?php
        $result->data_seek(0);
        $y = 135;
        if ($result->num_rows > 0) {
            while ($booking = $result->fetch_assoc()) {
                echo "doc.setFillColor(240, 240, 240);";
                echo "doc.roundedRect(20, $y - 5, 170, 30, 3, 3, 'F');";
                echo "doc.setFontSize(12);";
                echo "doc.text('Booking #" . htmlspecialchars($booking['id']) . "', 25, $y);";
                echo "doc.setFontSize(10);";
                echo "doc.text('Date: " . (isset($booking['booking_date']) ? htmlspecialchars($booking['booking_date']) : date('Y-m-d')) . "', 25, $y + 10);";
                echo "doc.text('Price: ₹" . (isset($booking['price']) ? htmlspecialchars($booking['price']) : '1,500') . "', 120, $y + 10);";
                echo "$y += 35;";
                
                // Add new page if needed
                echo "if ($y > 270) {";
                echo "  doc.addPage();";
                echo "  $y = 20;";
                echo "}";
            }
        } else {
            echo "doc.setFontSize(12);";
            echo "doc.text('No bookings found.', 20, $y);";
        }
        ?>
        
        // Add footer
        const pageCount = doc.internal.getNumberOfPages();
        for (let i = 1; i <= pageCount; i++) {
            doc.setPage(i);
            doc.setFontSize(10);
            doc.setTextColor(150, 150, 150);
            doc.text(`Page ${i} of ${pageCount}`, 105, 290, { align: 'center' });
        }
        
        // Save the PDF
        doc.save('user_profile_report.pdf');
        
        // Show success toast
        showToast('PDF Generated', 'Your profile report has been downloaded successfully!', 'success');
    }
    
    // Generate Bookings PDF
    function generateBookingsPDF() {
        const doc = new jsPDF();
        const username = "<?php echo htmlspecialchars($user_data['username']); ?>";
        const currentDate = new Date().toLocaleString();
        
        // Add styling
        doc.setFillColor(239, 71, 111);
        doc.rect(0, 0, 210, 40, 'F');
        
        // Add title
        doc.setTextColor(255, 255, 255);
        doc.setFontSize(24);
        doc.text('Booking History Report', 105, 20, { align: 'center' });
        doc.setFontSize(12);
        doc.text(`Generated on: ${currentDate}`, 105, 30, { align: 'center' });
        
        // Add user info
        doc.setTextColor(0, 0, 0);
        doc.setFontSize(14);
        doc.text(`User: ${username}`, 20, 50);
        
        // Add bookings table header
        doc.setFillColor(240, 240, 240);
        doc.rect(20, 60, 170, 10, 'F');
        doc.setFontSize(10);
        doc.setTextColor(80, 80, 80);
        doc.text('Booking ID', 25, 67);
        doc.text('Date', 65, 67);
        doc.text('Details', 105, 67);
        doc.text('Price', 165, 67);
        
        <?php
        $result->data_seek(0);
        $y = 80;
        $count = 0;
        if ($result->num_rows > 0) {
            while ($booking = $result->fetch_assoc()) {
                // Alternate row colors
                if ($count % 2 == 0) {
                    echo "doc.setFillColor(250, 250, 250);";
                    echo "doc.rect(20, $y - 5, 170, 10, 'F');";
                }
                
                echo "doc.setFontSize(10);";
                echo "doc.setTextColor(0, 0, 0);";
                echo "doc.text('" . htmlspecialchars($booking['id']) . "', 25, $y);";
                echo "doc.text('" . (isset($booking['booking_date']) ? htmlspecialchars($booking['booking_date']) : date('Y-m-d')) . "', 65, $y);";
                echo "doc.text('" . (isset($booking['details']) ? substr(htmlspecialchars($booking['details']), 0, 20) : 'Standard Booking') . "', 105, $y);";
                echo "doc.text('₹" . (isset($booking['price']) ? htmlspecialchars($booking['price']) : '1,500') . "', 165, $y);";
                echo "$y += 10;";
                echo "$count++;";
                
                // Add new page if needed
                echo "if ($y > 270) {";
                echo "  doc.addPage();";
                echo "  $y = 20;";
                
                // Add table header on new page
                echo "  doc.setFillColor(240, 240, 240);";
                echo "  doc.rect(20, $y, 170, 10, 'F');";
                echo "  doc.setFontSize(10);";
                echo "  doc.setTextColor(80, 80, 80);";
                echo "  doc.text('Booking ID', 25, $y + 7);";
                echo "  doc.text('Date', 65, $y + 7);";
                echo "  doc.text('Details', 105, $y + 7);";
                echo "  doc.text('Price', 165, $y + 7);";
                echo "  $y += 20;";
                echo "}";
            }
        } else {
            echo "doc.setFontSize(12);";
            echo "doc.text('No bookings found.', 20, $y);";
        }
        ?>
        
        // Add summary
        doc.setFillColor(240, 240, 240);
        doc.rect(20, <?php echo $y + 10; ?>, 170, 20, 'F');
        doc.setFontSize(12);
        doc.setTextColor(0, 0, 0);
        doc.text('Summary', 25, <?php echo $y + 20; ?>);
        doc.setFontSize(10);
        doc.text('Total Bookings: <?php echo $result->num_rows; ?>', 25, <?php echo $y + 30; ?>);
        
        // Add footer
        const pageCount = doc.internal.getNumberOfPages();
        for (let i = 1; i <= pageCount; i++) {
            doc.setPage(i);
            doc.setFontSize(10);
            doc.setTextColor(150, 150, 150);
            doc.text(`Page ${i} of ${pageCount}`, 105, 290, { align: 'center' });
        }
        
        // Save the PDF
        doc.save('booking_history_report.pdf');
        
        // Show success toast
        showToast('PDF Generated', 'Your booking history report has been downloaded successfully!', 'success');
    }
    
    // Generate Invoice PDF
    function generateInvoicePDF(bookingId) {
        const doc = new jsPDF();
        const username = "<?php echo htmlspecialchars($user_data['username']); ?>";
        const email = "<?php echo htmlspecialchars($user_data['email']); ?>";
        const mobile = "<?php echo htmlspecialchars($user_data['mobile']); ?>";
        const currentDate = new Date().toLocaleString();
        
        // Add styling
        doc.setFillColor(16, 185, 129);
        doc.rect(0, 0, 210, 40, 'F');
        
        // Add title
        doc.setTextColor(255, 255, 255);
        doc.setFontSize(24);
        doc.text('INVOICE', 105, 20, { align: 'center' });
        doc.setFontSize(12);
        doc.text(`Invoice #INV-${bookingId}-${new Date().getTime().toString().substr(-6)}`, 105, 30, { align: 'center' });
        
        // Add company info
        doc.setTextColor(0, 0, 0);
        doc.setFontSize(14);
        doc.text('Company Name', 20, 60);
        doc.setFontSize(10);
        doc.text('123 Business Street', 20, 70);
        doc.text('City, State, ZIP', 20, 75);
        doc.text('Phone: +1 234 567 890', 20, 80);
        doc.text('Email: company@example.com', 20, 85);
        
        // Add customer info
        doc.setFontSize(14);
        doc.text('Bill To:', 140, 60);
        doc.setFontSize(10);
        doc.text(username, 140, 70);
        doc.text(email, 140, 75);
        doc.text(mobile, 140, 80);
        
        // Add invoice details
        doc.setFillColor(240, 240, 240);
        doc.rect(20, 95, 170, 15, 'F');
        doc.setFontSize(10);
        doc.setTextColor(80, 80, 80);
        doc.text('Invoice Date', 25, 103);
        doc.text('Due Date', 75, 103);
        doc.text('Booking ID', 125, 103);
        doc.text('Status', 170, 103);
        
        doc.setTextColor(0, 0, 0);
        doc.text(new Date().toISOString().split('T')[0], 25, 110);
        doc.text(new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], 75, 110);
        doc.text(`#${bookingId}`, 125, 110);
        doc.setTextColor(16, 185, 129);
        doc.text('PAID', 170, 110);
        
        // Add item table header
        doc.setFillColor(240, 240, 240);
        doc.rect(20, 120, 170, 10, 'F');
        doc.setFontSize(10);
        doc.setTextColor(80, 80, 80);
        doc.text('Item', 25, 127);
        doc.text('Description', 75, 127);
        doc.text('Quantity', 140, 127);
        doc.text('Price', 170, 127);
        
        // Add item details
        <?php
        $result->data_seek(0);
        $found = false;
        $y = 140;
        
        while ($booking = $result->fetch_assoc()) {
            echo "if (bookingId === '" . htmlspecialchars($booking['id']) . "') {";
            echo "  doc.setTextColor(0, 0, 0);";
            echo "  doc.text('Booking Service', 25, $y);";
            echo "  doc.text('" . (isset($booking['details']) ? substr(htmlspecialchars($booking['details']), 0, 30) : 'Standard Booking Service') . "', 75, $y);";
            echo "  doc.text('1', 140, $y);";
            echo "  doc.text('₹" . (isset($booking['price']) ? htmlspecialchars($booking['price']) : '1,500') . "', 170, $y);";
            echo "  $y += 10;";
            
            // Add total
            echo "  doc.setFillColor(240, 240, 240);";
            echo "  doc.rect(120, $y + 10, 70, 40, 'F');";
            echo "  doc.setFontSize(10);";
            echo "  doc.text('Subtotal', 125, $y + 20);";
            echo "  doc.text('Tax (18%)', 125, $y + 30);";
            echo "  doc.setFontSize(12);";
            echo "  doc.text('Total', 125, $y + 40);";
            
            $price = isset($booking['price']) ? (int)$booking['price'] : 1500;
            $tax = $price * 0.18;
            $total = $price + $tax;
            
            echo "  doc.setTextColor(0, 0, 0);";
            echo "  doc.setFontSize(10);";
            echo "  doc.text('₹" . $price . "', 170, $y + 20, { align: 'right' });";
            echo "  doc.text('₹" . $tax . "', 170, $y + 30, { align: 'right' });";
            echo "  doc.setFontSize(12);";
            echo "  doc.setTextColor(16, 185, 129);";
            echo "  doc.text('₹" . $total . "', 170, $y + 40, { align: 'right' });";
            
            // Add payment info
            echo "  doc.setTextColor(0, 0, 0);";
            echo "  doc.setFontSize(12);";
            echo "  doc.text('Payment Information', 20, $y + 60);";
            echo "  doc.setFontSize(10);";
            echo "  doc.text('Payment Method: Credit Card', 20, $y + 70);";
            echo "  doc.text('Transaction ID: TXN-" . rand(100000, 999999) . "', 20, $y + 80);";
            echo "  doc.text('Payment Date: " . date('Y-m-d') . "', 20, $y + 90);";
            
            // Add thank you note
            echo "  doc.setFillColor(245, 245, 245);";
            echo "  doc.roundedRect(20, $y + 100, 170, 30, 3, 3, 'F');";
            echo "  doc.setFontSize(12);";
            echo "  doc.text('Thank you for your business!', 105, $y + 115, { align: 'center' });";
            echo "  doc.setFontSize(10);";
            echo "  doc.text('For any questions, please contact our customer support.', 105, $y + 125, { align: 'center' });";
            
            echo "  found = true;";
            echo "}";
        }
        ?>
        
        if (!found) {
            doc.setFontSize(12);
            doc.setTextColor(239, 71, 111);
            doc.text('Booking not found.', 105, 150, { align: 'center' });
        }
        
        // Add footer
        doc.setFontSize(10);
        doc.setTextColor(150, 150, 150);
        doc.text('This is a computer-generated invoice and does not require a signature.', 105, 280, { align: 'center' });
        
        // Save the PDF
        doc.save(`invoice_booking_${bookingId}.pdf`);
        
        // Show success toast
        showToast('Invoice Generated', 'Your invoice has been downloaded successfully!', 'success');
    }
    
    // Show toast notification
    function showToast(title, message, type) {
        const toastContainer = document.getElementById('toastContainer');
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        
        toast.innerHTML = `
            <div class="toast-icon">
                <i class="fas fa-${type === 'success' ? 'check-circle' : 'info-circle'}"></i>
            </div>
            <div class="toast-content">
                <div class="toast-title">${title}</div>
                <div class="toast-message">${message}</div>
            </div>
            <button class="toast-close">&times;</button>
        `;
        
        toastContainer.appendChild(toast);
        
        // Close button functionality
        toast.querySelector('.toast-close').addEventListener('click', function() {
            toast.style.animation = 'slideOutRight 0.3s ease forwards';
            setTimeout(() => {
                toast.remove();
            }, 300);
        });
        
        // Auto close after 5 seconds
        setTimeout(() => {
            if (toast.parentNode) {
                toast.style.animation = 'slideOutRight 0.3s ease forwards';
                setTimeout(() => {
                    if (toast.parentNode) {
                        toast.remove();
                    }
                }, 300);
            }
        }, 5000);
    }
</script>