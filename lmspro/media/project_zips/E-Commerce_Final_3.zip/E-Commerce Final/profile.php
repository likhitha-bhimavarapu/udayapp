<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

include 'db_config.php';

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Add to cart functionality
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['product_id'])) {
    $product_id = $_POST['product_id'];
    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];
    $product_image = $_POST['product_image'];

    // Check if the product is already in the cart
    $found = false;
    foreach ($_SESSION['cart'] as &$item) {
        if ($item['id'] == $product_id) {
            $item['quantity']++;
            $found = true;
            break;
        }
    }

    if (!$found) {
        // Add new product to the session cart array
        $_SESSION['cart'][] = [
            'id' => $product_id,
            'name' => $product_name,
            'price' => $product_price,
            'image' => $product_image,
            'quantity' => 1
        ];
    }

    // Return a JSON response
    echo json_encode(['status' => 'success', 'message' => 'Product added to cart successfully!']);
    exit();
}

// Fetch products from the database
$search = '';
if (isset($_GET['search'])) {
    $search = $_GET['search'];
}
$sql = "SELECT * FROM product";
if (!empty($search)) {
    $sql .= " WHERE name LIKE '%$search%'";
}
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>FreshMart - User Dashboard</title>
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2ecc71;
            --secondary-color: #27ae60;
            --dark-color: #34495e;
            --light-color: #ecf0f1;
            --accent-color: #e74c3c;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f9f9f9;
            color: #333;
        }
        
        .hero-carousel {
            height: 500px;
            overflow: hidden;
        }
        
        .hero-carousel .carousel-item img {
            object-fit: cover;
            height: 500px;
            width: 100%;
        }
        
        .welcome-banner {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 1.5rem;
            border-radius: 10px;
            text-align: center;
            margin: 2rem auto;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            max-width: 600px;
        }
        
        .welcome-banner h3 {
            font-family: 'Montserrat', sans-serif;
            font-weight: 600;
            margin: 0;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.2);
        }
        
        .search-box {
            max-width: 600px;
            margin: 2rem auto;
        }
        
        .search-box .form-control {
            border-radius: 50px;
            padding: 0.75rem 1.5rem;
            border: 2px solid var(--primary-color);
        }
        
        .search-box .btn {
            border-radius: 50px;
            padding: 0.75rem 2rem;
            font-weight: 500;
            background-color: var(--primary-color);
            border: none;
        }
        
        .search-box .btn:hover {
            background-color: var(--secondary-color);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(46, 204, 113, 0.3);
        }
        
        .category-section {
            padding: 3rem 0;
            background-color: white;
            margin: 2rem 0;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }
        
        .category-title {
            font-family: 'Montserrat', sans-serif;
            font-weight: 600;
            color: var(--dark-color);
            text-align: center;
            margin-bottom: 2rem;
            position: relative;
        }
        
        .category-title::after {
            content: '';
            display: block;
            width: 80px;
            height: 4px;
            background: var(--primary-color);
            margin: 10px auto;
            border-radius: 2px;
        }
        
        .category-links {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 2rem;
        }
        
        .category-link {
            text-decoration: none;
            color: var(--dark-color);
            font-weight: 500;
            padding: 1rem 1.5rem;
            border-radius: 50px;
            transition: all 0.3s ease;
            background-color: var(--light-color);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .category-link:hover {
            background-color: var(--primary-color);
            color: white;
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(46, 204, 113, 0.2);
        }
        
        .category-link i {
            font-size: 1.2rem;
        }
        
        .products-section {
            padding: 2rem 0;
        }
        
        .section-title {
            font-family: 'Montserrat', sans-serif;
            font-weight: 600;
            color: var(--dark-color);
            text-align: center;
            margin-bottom: 2rem;
            position: relative;
        }
        
        .section-title::after {
            content: '';
            display: block;
            width: 80px;
            height: 4px;
            background: var(--primary-color);
            margin: 10px auto;
            border-radius: 2px;
        }
        
        .product-card {
            border: none;
            border-radius: 15px;
            overflow: hidden;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            height: 100%;
            margin-bottom: 1.5rem;
        }
        
        .product-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(46, 204, 113, 0.2);
        }
        
        .product-image {
            height: 200px;
            object-fit: contain;
            padding: 1rem;
            transition: transform 0.3s;
        }
        
        .product-card:hover .product-image {
            transform: scale(1.1);
        }
        
        .card-body {
            padding: 1.5rem;
            display: flex;
            flex-direction: column;
        }
        
        .product-title {
            font-family: 'Montserrat', sans-serif;
            font-weight: 600;
            color: var(--dark-color);
            margin-bottom: 0.5rem;
        }
        
        .product-description {
            color: #666;
            font-size: 0.9rem;
            margin-bottom: 1rem;
            flex-grow: 1;
        }
        
        .product-price {
            font-weight: 700;
            color: var(--accent-color);
            font-size: 1.2rem;
            margin-bottom: 1rem;
        }
        
        .product-actions {
            display: flex;
            gap: 1rem;
        }
        
        .btn-add-to-cart {
            background-color: var(--primary-color);
            border: none;
            border-radius: 50px;
            padding: 0.5rem 1.5rem;
            font-weight: 500;
            transition: all 0.3s;
            flex-grow: 1;
        }
        
        .btn-add-to-cart:hover {
            background-color: var(--secondary-color);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(46, 204, 113, 0.3);
        }
        
        .btn-buy-now {
            background-color: var(--accent-color);
            border: none;
            border-radius: 50px;
            padding: 0.5rem 1.5rem;
            font-weight: 500;
            transition: all 0.3s;
            flex-grow: 1;
        }
        
        .btn-buy-now:hover {
            background-color: #c0392b;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(231, 76, 60, 0.3);
        }
        
        @media (max-width: 768px) {
            .hero-carousel, .hero-carousel .carousel-item img {
                height: 300px;
            }
            
            .category-links {
                flex-direction: column;
                align-items: center;
            }
            
            .product-actions {
                flex-direction: column;
            }
        }
        
        /* Animation */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .product-card {
            animation: fadeIn 0.5s ease forwards;
            opacity: 0;
        }
        
        .product-card:nth-child(1) { animation-delay: 0.1s; }
        .product-card:nth-child(2) { animation-delay: 0.2s; }
        .product-card:nth-child(3) { animation-delay: 0.3s; }
        .product-card:nth-child(4) { animation-delay: 0.4s; }
        .product-card:nth-child(5) { animation-delay: 0.5s; }
        .product-card:nth-child(6) { animation-delay: 0.6s; }
    </style>
</head>

<body>
    <?php include './pnav.php'; ?>
    
    <div class="hero-carousel carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
            <button type="button" data-bs-target=".hero-carousel" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target=".hero-carousel" data-bs-slide-to="1" aria-label="Slide 2"></button>
            <button type="button" data-bs-target=".hero-carousel" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="./one.jpg" class="d-block w-100" alt="Fresh Groceries">
            </div>
            <div class="carousel-item">
                <img src="./g.jpg" class="d-block w-100" alt="Quality Products">
            </div>
            <div class="carousel-item">
                <img src="./download.jpg" class="d-block w-100" alt="Great Deals">
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target=".hero-carousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target=".hero-carousel" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
    
    <div class="welcome-banner">
        <h3>WELCOME <?php echo strtoupper(htmlspecialchars($_SESSION['username'])); ?></h3>
    </div>
    
    <div class="container">
        <form class="search-box" method="GET">
            <div class="input-group">
                <input class="form-control" type="search" placeholder="Search products..." aria-label="Search" name="search" value="<?php echo htmlspecialchars($search); ?>">
                <button class="btn btn-primary" type="submit">
                    <i class="fas fa-search me-2"></i>Search
                </button>
            </div>
        </form>
        
        <div class="category-section">
            <h2 class="category-title">Shop By Category</h2>
            <div class="category-links">
                <a href="./fruits.php" class="category-link">
                    <i class="fas fa-apple-alt"></i> Fruits & Vegetables
                </a>
                <a href="./meat.php" class="category-link">
                    <i class="fas fa-drumstick-bite"></i> Eggs, Meat & Fish
                </a>
                <a href="./rice.php" class="category-link">
                    <i class="fas fa-wheat-awn"></i> Rice, Atta & Dal
                </a>
            </div>
        </div>
        
        <div class="products-section">
            <h2 class="section-title">Our Fresh Products</h2>
            <div class="row">
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo '<div class="col-md-4">';
                        echo '<div class="card product-card">';
                        echo '<img src="' . htmlspecialchars($row['image']) . '" class="product-image card-img-top mx-auto d-block" alt="' . htmlspecialchars($row['name']) . '">';
                        echo '<div class="card-body">';
                        echo '<h5 class="product-title card-title">' . htmlspecialchars($row['name']) . '</h5>';
                        echo '<p class="product-description card-text">' . htmlspecialchars($row['description']) . '</p>';
                        echo '<p class="product-price">₹' . htmlspecialchars($row['price']) . '</p>';
                        echo '<form class="add-to-cart-form">';
                        echo '<input type="hidden" name="product_id" value="' . htmlspecialchars($row['id']) . '">';
                        echo '<input type="hidden" name="product_name" value="' . htmlspecialchars($row['name']) . '">';
                        echo '<input type="hidden" name="product_price" value="' . htmlspecialchars($row['price']) . '">';
                        echo '<input type="hidden" name="product_image" value="' . htmlspecialchars($row['image']) . '">';
                        echo '<div class="product-actions">';
                        echo '<button type="button" class="btn btn-buy-now">Buy Now</button>';
                        echo '<button type="button" class="btn btn-add-to-cart add-to-cart-button">Add to Cart</button>';
                        echo '</div>';
                        echo '</form>';
                        echo '</div>';
                        echo '</div>';
                        echo '</div>';
                    }
                } else {
                    echo '<div class="col-12 text-center">';
                    echo '<div class="alert alert-info">No products found. Please try a different search term.</div>';
                    echo '</div>';
                }
                ?>
            </div>
        </div>
    </div>

    <?php include './footer.php'; ?>

    <script>
        document.querySelectorAll('.add-to-cart-button').forEach(function(button) {
            button.addEventListener('click', function(event) {
                var form = event.target.closest('.add-to-cart-form');
                var formData = new FormData(form);
                
                // Show loading state
                button.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Adding...';
                button.disabled = true;

                fetch('', {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 'success') {
                            // Show success message with SweetAlert or similar
                            Swal.fire({
                                position: 'top-end',
                                icon: 'success',
                                title: data.message,
                                showConfirmButton: false,
                                timer: 1500
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Oops...',
                                text: 'An error occurred. Please try again.',
                            });
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        Swal.fire({
                            icon: 'error',
                            title: 'Oops...',
                            text: 'An error occurred. Please try again.',
                        });
                    })
                    .finally(() => {
                        // Reset button state
                        button.innerHTML = 'Add to Cart';
                        button.disabled = false;
                    });
            });
        });
        
        // Initialize tooltips
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    </script>
    
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</body>

</html>