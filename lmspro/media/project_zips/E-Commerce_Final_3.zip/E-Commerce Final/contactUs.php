<!DOCTYPE html>
<html>

<head>
    <title>Contact Us</title>
</head>
<style>
     body{
        background: linear-gradient(rgba(1.1,10.10,10.10,0.1),rgba(100.1,2.1,1.1,0.5));
    }
    .contact-section {
            display: flex;
            align-items: center;
            gap: 20PX;
            border: 1PX SOLID cornsilk;
          
            padding: 15PX;
          
            border-radius: 10PX;
      
        
        }

        .contact-section svg {
            width: 36px; /* Optional: Adjust icon size */
            height: 36px; /* Optional: Adjust icon size */
            margin-right: 15px; /* Optional: Adjust spacing between icon and text */
        }

    

        .contact-section h4 {
            margin-bottom: 5px; /* Optional: Adjust spacing */
        }

        .contact-section p {
            margin-bottom: 0; /* Optional: Adjust spacing */
        }
</style>
<body>
    <?php include './pnav.php'; ?>

    <div class="container">
        <div class="container mt-0">
            <h3 style="text-align: center;" class="text-danger">Contact Details</h3>

            <div class="row justify-content-center">
                <div class="contact-section  m-2 ">
                    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" fill="currentColor" class="bi bi-geo-alt" viewBox="0 0 16 16">
                        <path d="M12.166 8.94c-.524 1.062-1.234 2.12-1.96 3.07A32 32 0 0 1 8 14.58a32 32 0 0 1-2.206-2.57c-.726-.95-1.436-2.008-1.96-3.07C3.304 7.867 3 6.862 3 6a5 5 0 0 1 10 0c0 .862-.305 1.867-.834 2.94M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10" />
                        <path d="M8 8a2 2 0 1 1 0-4 2 2 0 0 1 0 4m0 1a3 3 0 1 0 0-6 3 3 0 0 0 0 6" />
                    </svg>
                    <div class="text-black">
                        <h4>Registered Office</h4>
                        <p>Flat No. 100/9, 10th Floor, #1013, Raj Mahal Grand,<br />Madhura, Chennai, 500001.</p>
                    </div>
                </div>

                <div class="contact-section m-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" fill="currentColor" class="bi bi-geo-alt" viewBox="0 0 16 16">
                        <path d="M12.166 8.94c-.524 1.062-1.234 2.12-1.96 3.07A32 32 0 0 1 8 14.58a32 32 0 0 1-2.206-2.57c-.726-.95-1.436-2.008-1.96-3.07C3.304 7.867 3 6.862 3 6a5 5 0 0 1 10 0c0 .862-.305 1.867-.834 2.94M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10" />
                        <path d="M8 8a2 2 0 1 1 0-4 2 2 0 0 1 0 4m0 1a3 3 0 1 0 0-6 3 3 0 0 0 0 6" />
                    </svg>
                    <div class="text-black">
                        <h4>Corporate Office</h4>
                        <p>Flat No. 100/9, 10th Floor, #1013, Raj Mahal Grand,<br />Madhura, Chennai, 500001.</p>
                    </div>
                </div>

                <div class="contact-section m-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" fill="currentColor" class="bi bi-phone" viewBox="0 0 16 16">
                        <path d="M11 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1zM5 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2z" />
                        <path d="M8 14a1 1 0 1 0 0-2 1 1 0 0 0 0 2" />
                    </svg>
                    <div class="text-black">
                        <h4>Phone</h4>
                        <p>040-0000 0109</p>
                    </div>
                </div>

                <div class="contact-section  m-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" fill="currentColor" class="bi bi-envelope" viewBox="0 0 16 16">
                        <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2zm2-1a1 1 0 0 0-1 1v.217l7 4.2 7-4.2V4a1 1 0 0 0-1-1zm13 2.383-4.708 2.825L15 11.105zm-.034 6.876-5.64-3.471L8 9.583l-1.326-.795-5.64 3.47A1 1 0 0 0 2 13h12a1 1 0 0 0 .966-.741M1 11.105l4.708-2.897L1 5.383z" />
                    </svg>
                    <div class="text-black">
                        <h4>Email</h4>
                        <p>info@ecommerce.com</p>
                    </div>
                </div>

                <div class="contact-section  m-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" fill="currentColor" class="bi bi-headset" viewBox="0 0 16 16">
                        <path d="M8 1a5 5 0 0 0-5 5v1h1a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V6a6 6 0 1 1 12 0v6a2.5 2.5 0 0 1-2.5 2.5H9.366a1 1 0 0 1-.866.5h-1a1 1 0 1 1 0-2h1a1 1 0 0 1 .866.5H11.5A1.5 1.5 0 0 0 13 12h-1a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1h1V6a5 5 0 0 0-5-5" />
                    </svg>
                    <div class="text-black">
                        <h4>Customer Support</h4>
                        <p>CustomerCare Number:+91 0863-1000-0001</p>
                        <p>24/7*365 Days</p>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <?php include 'footer.php'; ?>
</body>

</html>