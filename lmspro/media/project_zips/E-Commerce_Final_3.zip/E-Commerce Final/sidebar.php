<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <!-- Add your CSS stylesheets here -->
</head>
<style>
    .sidebar{
        display: flex;
        flex: column;
        padding: 20px;
        margin: 20px;
    }
    .sidebar ul li:hover{
        color: white;
        background-color:transparent;
        border-radius: 10px;
        padding: 5px;
       border: 3px solid red;
    }
</style>
<body>
    <div class="sidebar">
       
        <ul style="list-style: none;">
            
            <li><a href="users.php" style="text-decoration: none;color:black;font-size:25px">Users</a></li>
            <li><a href="user_orders.php" style="text-decoration: none;color:black;font-size:25px">Users Orders</a></li>
            
            <!-- Add more sidebar links as needed -->
        </ul>
    </div>

    <div class="content">
        <!-- Main content goes here -->
    </div>

    <!-- Add your JavaScript files here -->
</body>
</html>
