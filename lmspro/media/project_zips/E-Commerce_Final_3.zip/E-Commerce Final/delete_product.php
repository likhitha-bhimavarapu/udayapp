<?php
session_start();
include 'db_config.php';

if (isset($_POST['product_id'])) {
    $product_id = $_POST['product_id'];

    try {
        // Start transaction
        $conn->begin_transaction();

        // Prepare delete statements for each table
        $stmt1 = $conn->prepare("DELETE FROM F WHERE product_id = ?");
        $stmt1->bind_param("i", $product_id);
        $stmt1->execute();
        $rows1 = $stmt1->affected_rows; // Check affected rows

        $stmt2 = $conn->prepare("DELETE FROM M WHERE product_id = ?");
        $stmt2->bind_param("i", $product_id);
        $stmt2->execute();
        $rows2 = $stmt2->affected_rows; // Check affected rows

        $stmt3 = $conn->prepare("DELETE FROM RICE WHERE product_id = ?");
        $stmt3->bind_param("i", $product_id);
        $stmt3->execute();
        $rows3 = $stmt3->affected_rows; // Check affected rows

        // Commit transaction
        $conn->commit();

        // Check if any rows affected
        if ($rows1 > 0 || $rows2 > 0 || $rows3 > 0) {
            $_SESSION['message'] = "Product deleted successfully from all tables.";
        } else {
            $_SESSION['error'] = "Product not found or failed to delete from one or more tables.";
        }
    } catch (Exception $e) {
        // Rollback transaction on error
        $conn->rollback();
        $_SESSION['error'] = "Error deleting product: " . $e->getMessage();
    }
} else {
    $_SESSION['error'] = "Product ID not provided.";
}

// Redirect back to the previous page (database_data.php)
header("Location: allProducts.php");
exit();
?>
