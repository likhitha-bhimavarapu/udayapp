<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-commerce</title>

    <!-- Bootstrap link -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<style>
    /* Global Styles */
    :root {
        --primary-color: #ff3d57;
        --secondary-color: #2d3436;
        --accent-color: #0984e3;
        --light-color: #f9f9f9;
        --dark-color: #2d3436;
    }
    
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }
    
    body {
        font-family: 'Nunito', sans-serif;
        background-color: var(--light-color);
    }
    
    /* Navbar Styles */
    .navbar {
        background: white;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
        padding: 15px 0;
        position: sticky;
        top: 0;
        z-index: 1000;
        transition: all 0.3s ease;
    }
    
    .container-fluid {
        padding: 0 30px;
    }
    
    .navbar-brand {
        display: flex;
        align-items: center;
        position: relative;
    }
    
    .navbar-brand span {
        font-size: 50px;
        color: var(--primary-color);
        font-weight: 800;
        position: relative;
        display: inline-block;
        transition: all 0.3s ease;
        margin-right: 5px;
    }
    
    .navbar-brand span::before {
        content: '';
        position: absolute;
        width: 40px;
        height: 40px;
        background: linear-gradient(135deg, rgba(255, 61, 87, 0.2) 0%, rgba(255, 61, 87, 0) 70%);
        border-radius: 50%;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        z-index: -1;
    }
    
    .navbar-brand b {
        font-weight: 700;
        color: var(--secondary-color);
        font-size: 24px;
        letter-spacing: -0.5px;
    }
    
    .navbar-nav {
        display: flex;
        align-items: center;
    }
    
    .nav-item {
        margin: 0 5px;
        position: relative;
    }
    
    .nav-link {
        color: var(--secondary-color) !important;
        font-weight: 600;
        padding: 10px 20px !important;
        border-radius: 8px;
        transition: all 0.3s ease;
        position: relative;
        overflow: hidden;
    }
    
    .nav-link::before {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 3px;
        background: linear-gradient(90deg, var(--primary-color), var(--accent-color));
        transform: scaleX(0);
        transform-origin: right;
        transition: transform 0.3s ease;
    }
    
    .nav-link:hover {
        color: var(--primary-color) !important;
    }
    
    .nav-link:hover::before {
        transform: scaleX(1);
        transform-origin: left;
    }
    
    .nav-link.active {
        color: var(--primary-color) !important;
    }
    
    .nav-link.active::before {
        transform: scaleX(1);
    }
    
    /* Special styling for Register and Login links */
    .nav-item:nth-last-child(2) .nav-link {
        background: linear-gradient(to right, #ffffff, #f5f5f5);
        border: 2px solid var(--primary-color);
        color: var(--primary-color) !important;
        padding: 8px 20px !important;
        border-radius: 50px;
        transition: all 0.3s ease;
        box-shadow: 0 2px 10px rgba(255, 61, 87, 0.1);
    }
    
    .nav-item:nth-last-child(2) .nav-link:hover {
        background: linear-gradient(to right, #fff5f7, #fff0f3);
        transform: translateY(-2px);
        box-shadow: 0 4px 15px rgba(255, 61, 87, 0.2);
    }
    
    .nav-item:nth-last-child(2) .nav-link::before {
        display: none;
    }
    
    .nav-item:last-child .nav-link {
        background: linear-gradient(135deg, var(--primary-color) 0%, #ff6b81 100%);
        color: white !important;
        padding: 10px 25px !important;
        border-radius: 50px;
        transition: all 0.3s ease;
        box-shadow: 0 4px 15px rgba(255, 61, 87, 0.3);
    }
    
    .nav-item:last-child .nav-link:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(255, 61, 87, 0.4);
    }
    
    .nav-item:last-child .nav-link::before {
        display: none;
    }
    
    /* Responsive styles without hamburger menu */
    @media (max-width: 991px) {
        .navbar {
            padding: 15px 0;
        }
        
        .container-fluid {
            flex-direction: column;
            padding: 0 15px;
        }
        
        .navbar-brand {
            margin-bottom: 15px;
            justify-content: center;
        }
        
        .navbar-collapse {
            display: flex !important;
            width: 100%;
        }
        
        .navbar-nav {
            flex-direction: row;
            justify-content: center;
            width: 100%;
            flex-wrap: wrap;
        }
        
        .nav-item {
            margin: 5px;
        }
        
        .nav-link {
            padding: 8px 15px !important;
            font-size: 0.9rem;
        }
    }
    
    @media (max-width: 576px) {
        .navbar-brand span {
            font-size: 40px;
        }
        
        .navbar-brand b {
            font-size: 20px;
        }
        
        .nav-link {
            padding: 6px 12px !important;
            font-size: 0.85rem;
        }
    }
    
    /* Animation for navbar on scroll */
    .navbar-scrolled {
        padding: 10px 0;
        background: rgba(255, 255, 255, 0.98);
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
    }
</style>
<body>
    <header>
        <nav class="navbar ">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">
                    <span>E</span><b>-commerce</b>
                </a>
                <!-- No navbar-toggler button -->
                <div class="" id="navbarSupportedContent">
                    <ul class="nav d-flex">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="./index.php">
                                <i class="fas fa-home me-1"></i> Home
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./registration.php" aria-disabled="true">
                                <i class="fas fa-user-plus me-1"></i> Register
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./login.php" aria-disabled="true">
                                <i class="fas fa-sign-in-alt me-1"></i> Login
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    
    <script>
        // Add scrolled class to navbar when scrolling
        window.addEventListener('scroll', function() {
            const navbar = document.querySelector('.navbar');
            if (window.scrollY > 50) {
                navbar.classList.add('navbar-scrolled');
            } else {
                navbar.classList.remove('navbar-scrolled');
            }
        });
    </script>
</body>

</html>