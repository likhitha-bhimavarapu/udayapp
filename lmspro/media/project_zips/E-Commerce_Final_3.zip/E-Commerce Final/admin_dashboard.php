<?php
session_start();

// Check if the user is logged in and is an admin
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}
?>
<style>
     body{
        height: 100vh;
        background: linear-gradient(rgba(1.1,10.10,10.10,0.1),rgba(100.1,2.1,1.1,0.5));
    }

</style>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>
<style>
    :root {
        --primary: #4361ee;
        --secondary: #ef476f;
        --success: #06d6a0;
        --warning: #ffd166;
        --info: #118ab2;
        --light: #f8f9fa;
        --dark: #212529;
        --gray: #6c757d;
        --gray-light: #e9ecef;
        --gray-dark: #343a40;
        --border-radius: 12px;
        --box-shadow: 0 10px 20px rgba(0, 0, 0, 0.05);
        --transition: all 0.3s ease;
    }
    
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }
    
    body {
        font-family: 'Poppins', sans-serif;
        min-height: 100vh;
        background: linear-gradient(135deg, #f5f7ff 0%, #e8eeff 100%);
        position: relative;
        overflow-x: hidden;
    }
    
    body::before {
        content: '';
        position: absolute;
        top: 0;
        right: 0;
        width: 400px;
        height: 400px;
        background: radial-gradient(circle, rgba(239, 71, 111, 0.1) 0%, rgba(239, 71, 111, 0) 70%);
        z-index: -1;
    }
    
    body::after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        width: 300px;
        height: 300px;
        background: radial-gradient(circle, rgba(67, 97, 238, 0.1) 0%, rgba(67, 97, 238, 0) 70%);
        z-index: -1;
    }
    
    .dashboard-container {
        padding: 40px 0;
    }
    
    .dashboard-header {
        background: linear-gradient(135deg, var(--primary) 0%, #3a56d4 100%);
        color: white;
        border-radius: var(--border-radius);
        padding: 30px;
        margin-bottom: 40px;
        position: relative;
        overflow: hidden;
        box-shadow: var(--box-shadow);
    }
    
    .dashboard-header::before {
        content: '';
        position: absolute;
        top: -50px;
        right: -50px;
        width: 200px;
        height: 200px;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.1);
    }
    
    .dashboard-header::after {
        content: '';
        position: absolute;
        bottom: -80px;
        left: -80px;
        width: 300px;
        height: 300px;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.05);
    }
    
    .dashboard-title {
        font-weight: 700;
        font-size: 2.5rem;
        margin-bottom: 10px;
        position: relative;
        z-index: 1;
    }
    
    .welcome-message {
        font-size: 1.2rem;
        opacity: 0.9;
        margin-bottom: 0;
        position: relative;
        z-index: 1;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    
    .welcome-message i {
        font-size: 1.5rem;
    }
    
    .stats-row {
        display: flex;
        flex-wrap: wrap;
        gap: 20px;
        margin-bottom: 40px;
    }
    
    .stat-card {
        background: white;
        border-radius: var(--border-radius);
        padding: 20px;
        flex: 1;
        min-width: 200px;
        box-shadow: var(--box-shadow);
        display: flex;
        align-items: center;
        gap: 20px;
        transition: var(--transition);
    }
    
    .stat-card:hover {
        transform: translateY(-5px);
    }
    
    .stat-icon {
        width: 60px;
        height: 60px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
    }
    
    .stat-icon.products {
        background: rgba(67, 97, 238, 0.1);
        color: var(--primary);
    }
    
    .stat-icon.users {
        background: rgba(239, 71, 111, 0.1);
        color: var(--secondary);
    }
    
    .stat-icon.orders {
        background: rgba(6, 214, 160, 0.1);
        color: var(--success);
    }
    
    .stat-icon.revenue {
        background: rgba(255, 209, 102, 0.1);
        color: var(--warning);
    }
    
    .stat-content {
        flex: 1;
    }
    
    .stat-value {
        font-size: 1.8rem;
        font-weight: 700;
        margin-bottom: 5px;
        line-height: 1;
    }
    
    .stat-label {
        color: var(--gray);
        font-size: 0.9rem;
    }
    
    .admin-card {
        background: white;
        border-radius: var(--border-radius);
        overflow: hidden;
        box-shadow: var(--box-shadow);
        height: 100%;
        transition: var(--transition);
        border: none;
        position: relative;
    }
    
    .admin-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
    }
    
    .admin-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 5px;
        background: linear-gradient(90deg, var(--primary) 0%, var(--secondary) 100%);
        opacity: 0;
        transition: var(--transition);
    }
    
    .admin-card:hover::before {
        opacity: 1;
    }
    
    .card-icon {
        font-size: 2.5rem;
        margin-bottom: 15px;
        background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        display: inline-block;
    }
    
    .card-title {
        font-weight: 600;
        margin-bottom: 10px;
        color: var(--dark);
    }
    
    .card-text {
        color: var(--gray);
        margin-bottom: 20px;
        font-size: 0.9rem;
    }
    
    .admin-btn {
        padding: 8px 20px;
        border-radius: 50px;
        font-weight: 500;
        font-size: 0.9rem;
        display: flex;
        align-items: center;
        gap: 8px;
        transition: var(--transition);
        width: fit-content;
    }
    
    .admin-btn-primary {
        background: var(--primary);
        color: white;
        border: none;
    }
    
    .admin-btn-primary:hover {
        background: #3a56d4;
        transform: translateY(-2px);
    }
    
    .admin-btn-outline {
        background: transparent;
        color: var(--primary);
        border: 1px solid var(--primary);
    }
    
    .admin-btn-outline:hover {
        background: rgba(67, 97, 238, 0.1);
        transform: translateY(-2px);
    }
    
    .quick-actions {
        background: white;
        border-radius: var(--border-radius);
        padding: 25px;
        box-shadow: var(--box-shadow);
        margin-top: 40px;
    }
    
    .section-title {
        font-weight: 600;
        margin-bottom: 20px;
        color: var(--dark);
        display: flex;
        align-items: center;
        gap: 10px;
    }
    
    .section-title i {
        color: var(--primary);
    }
    
    .action-buttons {
        display: flex;
        flex-wrap: wrap;
        gap: 15px;
    }
    
    .action-btn {
        padding: 12px 20px;
        border-radius: var(--border-radius);
        font-weight: 500;
        font-size: 0.9rem;
        display: flex;
        align-items: center;
        gap: 10px;
        transition: var(--transition);
        background: var(--gray-light);
        color: var(--dark);
        border: none;
        cursor: pointer;
    }
    
    .action-btn:hover {
        background: var(--primary);
        color: white;
        transform: translateY(-2px);
    }
    
    .action-btn i {
        font-size: 1.2rem;
    }
    
    /* Animation */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .animate-fade-in-up {
        animation: fadeInUp 0.5s ease forwards;
    }
    
    /* Responsive styles */
    @media (max-width: 991px) {
        .stats-row {
            flex-wrap: wrap;
        }
        
        .stat-card {
            flex: 1 1 calc(50% - 20px);
        }
    }
    
    @media (max-width: 767px) {
        .dashboard-header {
            padding: 20px;
        }
        
        .dashboard-title {
            font-size: 2rem;
        }
        
        .stat-card {
            flex: 1 1 100%;
        }
        
        .action-buttons {
            flex-direction: column;
        }
    }
</style>
<?php include './adminNavbar.php'; ?>

<div class="container dashboard-container">
    <!-- Dashboard Header -->
    <div class="dashboard-header animate-fade-in-up">
        <h1 class="dashboard-title">Admin Dashboard</h1>
        <p class="welcome-message">
            <i class="fas fa-user-shield"></i>
            Welcome, <?php echo strtoupper($_SESSION['username']); ?>!
        </p>
    </div>
    
    <!-- Stats Row -->
  
    
    <!-- Admin Cards -->
    <div class="row g-4">
        <div class="col-md-6 col-lg-3 animate-fade-in-up" style="animation-delay: 0.5s;">
            <div class="admin-card">
                <div class="card-body d-flex flex-column">
                    <i class="fas fa-plus-circle card-icon"></i>
                    <h5 class="card-title">Add Products</h5>
                    <p class="card-text">Add new products to your inventory with detailed information and images.</p>
                    <a href="addProduct.php" class="admin-btn admin-btn-primary mt-auto">
                        <i class="fas fa-plus"></i>
                        Add Product
                    </a>
                </div>
            </div>
        </div>
        
        <div class="col-md-6 col-lg-3 animate-fade-in-up" style="animation-delay: 0.6s;">
            <div class="admin-card">
                <div class="card-body d-flex flex-column">
                    <i class="fas fa-boxes card-icon"></i>
                    <h5 class="card-title">All Products</h5>
                    <p class="card-text">View, edit, and manage all products in your inventory with ease.</p>
                    <a href="allProducts.php" class="admin-btn admin-btn-primary mt-auto">
                        <i class="fas fa-list"></i>
                        View Products
                    </a>
                </div>
            </div>
        </div>
        
        <div class="col-md-6 col-lg-3 animate-fade-in-up" style="animation-delay: 0.7s;">
            <div class="admin-card">
                <div class="card-body d-flex flex-column">
                    <i class="fas fa-user-cog card-icon"></i>
                    <h5 class="card-title">Manage Users</h5>
                    <p class="card-text">View and manage user accounts, permissions, and activities.</p>
                    <a href="users.php" class="admin-btn admin-btn-primary mt-auto">
                        <i class="fas fa-users-cog"></i>
                        Manage Users
                    </a>
                </div>
            </div>
        </div>
        
        <div class="col-md-6 col-lg-3 animate-fade-in-up" style="animation-delay: 0.8s;">
            <div class="admin-card">
                <div class="card-body d-flex flex-column">
                    <i class="fas fa-shopping-bag card-icon"></i>
                    <h5 class="card-title">View Orders</h5>
                    <p class="card-text">Track, process, and manage customer orders and shipments.</p>
                    <a href="user_orders.php" class="admin-btn admin-btn-primary mt-auto">
                        <i class="fas fa-clipboard-list"></i>
                        View Orders
                    </a>
                </div>
            </div>
        </div>
    </div>
 
<!-- Bootstrap JS Bundle (Popper.js included) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
    // Add dynamic counters for stats
    document.addEventListener('DOMContentLoaded', function() {
        // Function to animate counting
        function animateCounter(element, target, duration) {
            let start = 0;
            const increment = target / (duration / 16);
            
            function updateCount() {
                start += increment;
                if (start >= target) {
                    element.textContent = target.toString().includes('.') ? 
                        target : 
                        parseInt(target).toLocaleString();
                    return;
                }
                
                element.textContent = Math.floor(start).toLocaleString();
                requestAnimationFrame(updateCount);
            }
            
            updateCount();
        }
        
        // Get all stat value elements
        const statValues = document.querySelectorAll('.stat-value');
        
        // Animate each counter with a delay
        statValues.forEach((element, index) => {
            const originalText = element.textContent;
            const targetValue = parseFloat(originalText.replace(/[^\d.-]/g, ''));
            
            // Reset to zero
            if (originalText.includes('₹')) {
                element.textContent = '₹0';
            } else {
                element.textContent = '0';
            }
            
            // Start animation after a delay
            setTimeout(() => {
                animateCounter(element, targetValue, 1500);
            }, 500 + (index * 200));
        });
    });
</script>