<?php
session_start();

// Fixed admin credentials
$admin_username = "admin";
$admin_password = "admin123";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if this is a forgot password request
    if (isset($_POST['forgot_password'])) {
        $email = $_POST['email'];
        
        // Validate email
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $_SESSION['login_error'] = "Invalid email format";
            header("Location: login.php");
            exit();
        }
        
        // Check if email exists in database
        $conn = new mysqli("localhost", "root", "", "ecommerceone");
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        
        $stmt = $conn->prepare("SELECT id, username FROM register WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();
        
        if ($stmt->num_rows > 0) {
            $stmt->bind_result($user_id, $username);
            $stmt->fetch();
            
            // Generate a unique token
            $token = bin2hex(random_bytes(32));
            $expires = date("Y-m-d H:i:s", time() + 3600); // 1 hour expiration
            
            // Store the token in database
            $stmt2 = $conn->prepare("INSERT INTO password_resets (user_id, token, expires_at) VALUES (?, ?, ?)");
            $stmt2->bind_param("iss", $user_id, $token, $expires);
            $stmt2->execute();
            $stmt2->close();
            
            // Send email with reset link (in a real app, you would actually send an email)
            $reset_link = "http://yourdomain.com/reset_password.php?token=$token";
            $_SESSION['reset_token'] = $token; // For demo purposes, we'll store in session
            
            $_SESSION['login_success'] = "Password reset link has been sent to your email.";
            header("Location: login.php");
            exit();
        } else {
            $_SESSION['login_error'] = "No account found with that email address";
            header("Location: login.php");
            exit();
        }
        
        $stmt->close();
        $conn->close();
    }
    
    // Regular login check (your existing code)
    if (isset($_POST['username']) && isset($_POST['password'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];

        // Check admin credentials
        if ($username === $admin_username && $password === $admin_password) {
            $_SESSION['username'] = $username;
            $_SESSION['role'] = 'admin';
            $_SESSION['login_success'] = "Admin login successful! Welcome, $username.";
            $_SESSION['redirect_url'] = "admin_dashboard.php";
            header("Location: login.php");
            exit();
        }
        
        // Regular user login check
        $conn = new mysqli("localhost", "root", "", "ecommerceone");
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        
        $stmt = $conn->prepare("SELECT id, username FROM register WHERE username = ? AND password = ?");
        $stmt->bind_param("ss", $username, $password);
        $stmt->execute();
        $stmt->store_result();
        
        if ($stmt->num_rows > 0) {
            $stmt->bind_result($user_id, $username);
            $stmt->fetch();
            $_SESSION['user_id'] = $user_id;
            $_SESSION['username'] = $username;
            $_SESSION['login_success'] = "User login successful! Welcome, $username.";
            $_SESSION['redirect_url'] = "profile.php";
            header("Location: login.php");
            exit();
        } else {
            $_SESSION['login_error'] = "Invalid login credentials";
            header("Location: login.php");
            exit();
        }
        
        $stmt->close();
        $conn->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Your Brand</title>
    <link rel="stylesheet" href="../css/navbar.css">
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --accent-color: #4895ef;
            --light-color: #f8f9fa;
            --dark-color: #212529;
            --success-color: #4bb543;
            --error-color: #ff3333;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        .auth-container {
            max-width: 450px;
            width: 100%;
            margin: auto;
            padding: 2rem;
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            position: relative;
            overflow: hidden;
        }
        
        .auth-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: linear-gradient(90deg, var(--primary-color), var(--accent-color));
        }
        
        .auth-header {
            text-align: center;
            margin-bottom: 2rem;
        }
        
        .auth-header h2 {
            color: var(--dark-color);
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        
        .auth-header p {
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        .form-control {
            padding: 12px 15px;
            border-radius: 8px;
            border: 1px solid #e0e0e0;
            transition: all 0.3s;
        }
        
        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(67, 97, 238, 0.25);
        }
        
        .form-floating label {
            padding: 12px 15px;
            color: #6c757d;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border: none;
            padding: 12px;
            border-radius: 8px;
            font-weight: 500;
            letter-spacing: 0.5px;
            transition: all 0.3s;
        }
        
        .btn-primary:hover {
            background-color: var(--secondary-color);
            transform: translateY(-2px);
        }
        
        .btn-link {
            color: var(--primary-color);
            text-decoration: none;
            font-size: 0.9rem;
        }
        
        .btn-link:hover {
            color: var(--secondary-color);
            text-decoration: underline;
        }
        
        .auth-footer {
            text-align: center;
            margin-top: 1.5rem;
            font-size: 0.9rem;
            color: #6c757d;
        }
        
        .input-group-text {
            background-color: transparent;
            border-right: none;
        }
        
        .password-toggle {
            cursor: pointer;
            background-color: transparent;
            border-left: none;
        }
        
        .form-icon {
            position: absolute;
            top: 50%;
            left: 15px;
            transform: translateY(-50%);
            color: #6c757d;
            z-index: 5;
        }
        
        .form-group {
            position: relative;
        }
        
        .form-group input {
            padding-left: 40px;
        }
        
        .forgot-password-form {
            display: none;
        }
        
        .brand-logo {
            text-align: center;
            margin-bottom: 1.5rem;
        }
        
        .brand-logo img {
            height: 50px;
        }
        
        @media (max-width: 576px) {
            .auth-container {
                border-radius: 0;
                box-shadow: none;
                padding: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <?php include './navbar.php' ?>
    
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <div class="auth-container">
                    <div class="brand-logo">
                        
                    </div>
                    
                    <!-- Login Form -->
                    <form action="login.php" method="post" class="login-form">
                        <div class="auth-header">
                            <h2>Welcome Back</h2>
                            <p>Please enter your credentials to login</p>
                        </div>
                        
                        <div class="mb-4 form-group">
                            <i class="fas fa-user form-icon"></i>
                            <input type="text" id="username" class="form-control" name="username" placeholder="Username" required>
                        </div>
                        
                        <div class="mb-4 form-group">
                            <i class="fas fa-lock form-icon"></i>
                            <input type="password" id="password" class="form-control" name="password" placeholder="Password" required>
                            <i class="fas fa-eye password-toggle" onclick="togglePassword()" style="position: absolute; right: 15px; top: 50%; transform: translateY(-50%); cursor: pointer;"></i>
                        </div>
                        
                        <div class="d-flex justify-content-between mb-4">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="rememberMe">
                                <label class="form-check-label" for="rememberMe">Remember me</label>
                            </div>
                            <a href="reset_password.php" class="btn btn-link p-0">Forgot password?</a>
                        </div>
                        
                        <button type="submit" class="btn btn-primary w-100 mb-3">Login</button>
                        
                        <div class="auth-footer">
                            Don't have an account? <a href="register.php" class="btn-link">Sign up</a>
                        </div>
                    </form>
                    
                    
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        function showForgotPassword() {
            document.querySelector('.login-form').style.display = 'none';
            document.querySelector('.forgot-password-form').style.display = 'block';
        }
        
        function showLoginForm() {
            document.querySelector('.login-form').style.display = 'block';
            document.querySelector('.forgot-password-form').style.display = 'none';
        }
        
        function togglePassword() {
            const password = document.getElementById('password');
            const icon = document.querySelector('.password-toggle');
            if (password.type === 'password') {
                password.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                password.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }
        
        window.onload = function() {
            <?php
            if (isset($_SESSION['login_success'])) {
                echo "showAlert('success', '" . $_SESSION['login_success'] . "');";
                if (isset($_SESSION['redirect_url'])) {
                    echo "setTimeout(function() { window.location.href = '" . $_SESSION['redirect_url'] . "'; }, 1500);";
                    unset($_SESSION['redirect_url']);
                }
                unset($_SESSION['login_success']);
            } elseif (isset($_SESSION['login_error'])) {
                echo "showAlert('error', '" . $_SESSION['login_error'] . "');";
                unset($_SESSION['login_error']);
            }
            ?>
        }
        
        function showAlert(type, message) {
            const alert = document.createElement('div');
            alert.className = `alert alert-${type === 'success' ? 'success' : 'danger'} alert-dismissible fade show`;
            alert.style.position = 'fixed';
            alert.style.top = '20px';
            alert.style.right = '20px';
            alert.style.zIndex = '9999';
            alert.style.minWidth = '300px';
            alert.style.boxShadow = '0 4px 12px rgba(0,0,0,0.15)';
            alert.style.border = 'none';
            alert.style.borderLeft = `4px solid ${type === 'success' ? 'var(--success-color)' : 'var(--error-color)'}`;
            alert.innerHTML = `
                <strong>${type === 'success' ? 'Success!' : 'Error!'}</strong> ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            `;
            document.body.appendChild(alert);
            
            // Auto dismiss after 5 seconds
            setTimeout(() => {
                alert.classList.remove('show');
                alert.classList.add('fade');
                setTimeout(() => alert.remove(), 150);
            }, 5000);
        }
    </script>
</body>
</html>