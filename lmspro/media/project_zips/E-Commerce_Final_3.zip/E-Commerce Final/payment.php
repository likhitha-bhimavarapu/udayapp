<?php
session_start();

// Function to convert price from dollars to Indian Rupees (INR)
function convertToINR($price)
{
    return number_format($price, 2);
}

$cart_items = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
$total_price = 0;
$cart_details = [];
foreach ($cart_items as $item) {
    if (isset($item['price'], $item['quantity'])) {
        $total_price += convertToINR($item['price']) * $item['quantity'];
        $cart_details[] = "Product: " . $item['name'] . ", Quantity: " . $item['quantity'] . ", Price: ₹" . number_format($item['price'], 2);
    }
}

$cart_details_string = implode('; ', $cart_details);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate input data
    $name = trim($_POST['name']);
    $contact_number = trim($_POST['contact_number']);
    $card_number = str_replace(' ', '', trim($_POST['card_number'])); // Remove spaces from card number
    $expiry_date = trim($_POST['expiry_date']);
    $cvv = trim($_POST['cvv']);
    $address = trim($_POST['address']);

    // Validation checks
    $errors = [];
    if (empty($name)) {
        $errors[] = "Name is required.";
    }
    if (empty($contact_number) || !preg_match("/^\d{10}$/", $contact_number)) {
        $errors[] = "Valid contact number is required (10 digits).";
    }
    if (empty($card_number) || !preg_match("/^\d{16}$/", $card_number)) {
        $errors[] = "Valid card number is required (16 digits).";
    }
    if (empty($expiry_date) || !preg_match("/^\d{2}\/\d{4}$/", $expiry_date)) {
        $errors[] = "Valid expiry date is required (MM/YYYY).";
    }
    if (empty($cvv) || !preg_match("/^\d{3,4}$/", $cvv)) {
        $errors[] = "Valid CVV is required (3 or 4 digits).";
    }
    if (empty($address)) {
        $errors[] = "Address is required.";
    }

    if (!empty($errors)) {
        $_SESSION['payment_errors'] = $errors;
        header("Location: payment.php");
        exit();
    }

    // Get user ID from session
    $user_id = $_SESSION['user_id'];

    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "ecommerceone";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Insert payment details
    $sql = "INSERT INTO payments (user_id, name, contact_number, card_number, expiry_date, cvv, address, total_price, cart_details)
            VALUES ('$user_id', '$name', '$contact_number', '$card_number', '$expiry_date', '$cvv', '$address', '$total_price', '$cart_details_string')";

    if ($conn->query($sql) === TRUE) {
        $_SESSION['payment_success'] = "Payment Successful! Thank you for your purchase.";
        unset($_SESSION['cart']);
        header("Location: payment.php");
        exit();
    } else {
        $_SESSION['payment_errors'] = ["Error processing payment. Please try again."];
        header("Location: payment.php");
    }

    $conn->close();
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Secure Payment | FreshMart</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2ecc71;
            --error-color: #e74c3c;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f5f7fa;
        }
        
        .payment-card {
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(46, 204, 113, 0.25);
        }
        
        .error-message {
            color: var(--error-color);
            font-size: 0.875rem;
            margin-top: 0.25rem;
        }
        
        .btn-pay {
            background-color: var(--primary-color);
            border: none;
            padding: 0.75rem;
            font-weight: 600;
        }
    </style>
</head>

<body>
    <?php include './pnav.php'; ?>

    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="payment-card bg-white p-4 mb-4">
                    <h2 class="text-center mb-4">Secure Payment</h2>
                    <div class="text-center mb-4">
                        <h4>Total Amount: ₹<?php echo number_format($total_price, 2); ?></h4>
                    </div>

                    <?php if (isset($_SESSION['payment_errors'])): ?>
                        <div class="alert alert-danger">
                            <?php foreach ($_SESSION['payment_errors'] as $error): ?>
                                <p class="mb-1"><?php echo $error; ?></p>
                            <?php endforeach; ?>
                            <?php unset($_SESSION['payment_errors']); ?>
                        </div>
                    <?php endif; ?>

                    <form id="paymentForm" method="POST">
                        <div class="mb-3">
                            <label for="name" class="form-label">Full Name</label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="contact_number" class="form-label">Contact Number</label>
                            <input type="tel" class="form-control" id="contact_number" name="contact_number" required>
                            <div id="contactError" class="error-message"></div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="card_number" class="form-label">Card Number</label>
                            <input type="text" class="form-control" id="card_number" name="card_number" required>
                            <div id="cardError" class="error-message"></div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="expiry_date" class="form-label">Expiry Date (MM/YYYY)</label>
                                <input type="text" class="form-control" id="expiry_date" name="expiry_date" required>
                                <div id="expiryError" class="error-message"></div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="cvv" class="form-label">CVV</label>
                                <input type="text" class="form-control" id="cvv" name="cvv" required>
                                <div id="cvvError" class="error-message"></div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="address" class="form-label">Delivery Address</label>
                            <textarea class="form-control" id="address" name="address" rows="3" required></textarea>
                        </div>
                        
                        <button type="submit" class="btn btn-pay btn-primary w-100 mt-3">
                            <i class="fas fa-lock me-2"></i>Pay ₹<?php echo number_format($total_price, 2); ?>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // Format card number with spaces
        document.getElementById('card_number').addEventListener('input', function(e) {
            let value = e.target.value.replace(/\s+/g, '');
            if (value.length > 0) {
                value = value.match(/.{1,4}/g).join(' ');
            }
            e.target.value = value;
            
            // Validate card number
            const cardNumber = value.replace(/\s+/g, '');
            const cardError = document.getElementById('cardError');
            if (cardNumber.length !== 16 || !/^\d+$/.test(cardNumber)) {
                cardError.textContent = 'Please enter a valid 16-digit card number';
            } else {
                cardError.textContent = '';
            }
        });

        // Format expiry date
        document.getElementById('expiry_date').addEventListener('input', function(e) {
            let value = e.target.value.replace(/[^0-9]/g, '');
            if (value.length > 2) {
                value = value.substring(0, 2) + '/' + value.substring(2, 6);
            }
            e.target.value = value;
            
            // Validate expiry date
            const expiryError = document.getElementById('expiryError');
            if (!/^\d{2}\/\d{4}$/.test(value)) {
                expiryError.textContent = 'Please enter in MM/YYYY format';
            } else {
                expiryError.textContent = '';
            }
        });

        // Validate contact number
        document.getElementById('contact_number').addEventListener('input', function(e) {
            const contactError = document.getElementById('contactError');
            if (!/^\d{10}$/.test(e.target.value)) {
                contactError.textContent = 'Please enter a valid 10-digit number';
            } else {
                contactError.textContent = '';
            }
        });

        // Validate CVV
        document.getElementById('cvv').addEventListener('input', function(e) {
            const cvvError = document.getElementById('cvvError');
            if (!/^\d{3,4}$/.test(e.target.value)) {
                cvvError.textContent = 'CVV must be 3 or 4 digits';
            } else {
                cvvError.textContent = '';
            }
        });

        // Form validation before submission
        document.getElementById('paymentForm').addEventListener('submit', function(e) {
            let isValid = true;
            
            // Card number validation
            const cardNumber = document.getElementById('card_number').value.replace(/\s+/g, '');
            if (cardNumber.length !== 16 || !/^\d+$/.test(cardNumber)) {
                document.getElementById('cardError').textContent = 'Please enter a valid 16-digit card number';
                isValid = false;
            }
            
            // Other validations...
            
            if (!isValid) {
                e.preventDefault();
            }
        });

        // Show success message if payment was successful
        <?php if (isset($_SESSION['payment_success'])): ?>
            Swal.fire({
                icon: 'success',
                title: '<?php echo $_SESSION['payment_success']; ?>',
                showConfirmButton: false,
                timer: 2000
            });
            <?php unset($_SESSION['payment_success']); ?>
        <?php endif; ?>
    </script>
</body>
</html>