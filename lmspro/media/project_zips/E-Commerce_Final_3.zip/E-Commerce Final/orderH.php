<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ecommerceone";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to fetch user-specific payment details
$sql = "SELECT * FROM payments WHERE user_id = '$user_id'";
$result = $conn->query($sql);

// Check if any rows are returned
$payments = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Check if product_image key exists in $row
        if (array_key_exists('product_image', $row)) {
            // Fetch image path from the database
            $image_path = $row['product_image'];

            // Add image path to $row array
            $row['image_path'] = $image_path;
        }

        // Add row to $payments array
        $payments[] = $row;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Payments</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- jsPDF -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.25/jspdf.plugin.autotable.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <!-- Custom Styles -->
    <style>
        :root {
            --primary-color: #6a11cb;
            --secondary-color: #2575fc;
            --accent-color: #ff416c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
            --success-color: #28a745;
            --danger-color: #dc3545;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f5f7fa;
            color: #333;
        }
        
        .navbar-brand {
            font-size: 1.8rem;
            font-weight: 700;
            background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
        
        .payment-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 2rem 0;
            margin-bottom: 2rem;
            border-radius: 0 0 20px 20px;
            box-shadow: 0 4px 20px rgba(106, 17, 203, 0.2);
        }
        
        .payment-card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
            overflow: hidden;
            margin-bottom: 30px;
            background-color: white;
        }
        
        .payment-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.12);
        }
        
        .card-img-top {
            height: 200px;
            object-fit: contain;
            background-color: var(--light-bg);
            padding: 20px;
        }
        
        .card-body {
            padding: 2rem;
        }
        
        .card-title {
            font-weight: 700;
            color: var(--primary-color);
            margin-bottom: 1.5rem;
            font-size: 1.5rem;
        }
        
        .card-text {
            margin-bottom: 0.8rem;
        }
        
        .text-primary {
            color: var(--primary-color) !important;
        }
        
        .text-success {
            color: var(--success-color) !important;
        }
        
        .text-danger {
            color: var(--danger-color) !important;
        }
        
        .cart-item-card {
            background-color: var(--light-bg);
            border-radius: 10px;
            margin-bottom: 10px;
            border-left: 4px solid var(--primary-color);
            transition: all 0.2s ease;
        }
        
        .cart-item-card:hover {
            transform: translateX(5px);
        }
        
        .btn-pdf {
            background: linear-gradient(to right, var(--accent-color), #ff4b2b);
            border: none;
            color: white;
            font-weight: 600;
            padding: 12px 25px;
            border-radius: 50px;
            box-shadow: 0 4px 15px rgba(255, 65, 108, 0.3);
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }
        
        .btn-pdf:hover {
            background: linear-gradient(to right, #ff4b2b, var(--accent-color));
            color: white;
            box-shadow: 0 8px 25px rgba(255, 65, 108, 0.4);
            transform: translateY(-2px);
        }
        
        .btn-pdf i {
            margin-right: 8px;
        }
        
        .total-price {
            font-size: 1.4rem;
            font-weight: 700;
            color: var(--success-color);
            background-color: rgba(40, 167, 69, 0.1);
            padding: 8px 15px;
            border-radius: 50px;
            display: inline-block;
        }
        
        .no-payments {
            text-align: center;
            padding: 5rem;
            background-color: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
        }
        
        .no-payments i {
            font-size: 5rem;
            color: #adb5bd;
            margin-bottom: 2rem;
            opacity: 0.7;
        }
        
        .no-payments h3 {
            color: var(--dark-bg);
            margin-bottom: 1rem;
            font-weight: 600;
        }
        
        .no-payments p {
            color: #6c757d;
            font-size: 1.1rem;
            margin-bottom: 2rem;
        }
        
        .status-badge {
            font-size: 0.9rem;
            font-weight: 600;
            padding: 5px 15px;
            border-radius: 50px;
        }
        
        footer {
            background-color: var(--dark-bg);
            color: white;
            padding: 3rem 0;
            margin-top: 3rem;
        }
        
        footer a {
            color: #adb5bd;
            text-decoration: none;
            transition: color 0.3s;
        }
        
        footer a:hover {
            color: white;
        }
        
        .social-icons a {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            margin-right: 10px;
            transition: all 0.3s;
        }
        
        .social-icons a:hover {
            background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            transform: translateY(-3px);
        }
        
        @media (max-width: 768px) {
            .payment-header {
                padding: 1.5rem 0;
            }
            
            .card-body {
                padding: 1.5rem;
            }
            
            .no-payments {
                padding: 3rem 1.5rem;
            }
        }
    </style>
</head>

<body>

    <?php include './pnav.php'; ?>

    <div class="payment-header">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center">
                <h1 class="mb-0 text-white"><i class="fas fa-receipt me-3"></i>My Payments</h1>
                <?php if (count($payments) > 0) : ?>
                    <button id="generatePdf" class="btn btn-pdf">
                        <i class="fas fa-file-pdf me-2"></i>Download Report
                    </button>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="container mb-5">
        <div class="row">
            <?php if (count($payments) > 0) : ?>
                <?php foreach ($payments as $payment) : ?>
                    <div class="col-lg-6 mb-4">
                        <div class="card payment-card h-100">
                            <?php if (isset($payment['image_path'])) : ?>
                                <img src="<?php echo htmlspecialchars($payment['image_path']); ?>" class="card-img-top" alt="Product Image">
                            <?php endif; ?>
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start mb-3">
                                    <h5 class="card-title mb-0">Payment #<?php echo htmlspecialchars($payment['id']); ?></h5>
                                    <span class="status-badge bg-success">Completed</span>
                                </div>
                                
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <p class="card-text"><strong class="text-primary">Name:</strong> <?php echo htmlspecialchars($payment['name']); ?></p>
                                    </div>
                                    <div class="col-md-6">
                                        <p class="card-text"><strong class="text-primary">Contact:</strong> <?php echo htmlspecialchars($payment['contact_number']); ?></p>
                                    </div>
                                    <div class="col-12">
                                        <p class="card-text"><strong class="text-primary">Address:</strong> <?php echo htmlspecialchars($payment['address']); ?></p>
                                    </div>
                                </div>
                                
                                <div class="d-flex justify-content-end mb-4">
                                    <p class="total-price mb-0">
                                        <i class="fas fa-rupee-sign me-1"></i><?php echo htmlspecialchars($payment['total_price']); ?>
                                    </p>
                                </div>
                                
                                <h6 class="card-subtitle mb-3 text-danger"><i class="fas fa-shopping-cart me-2"></i>Order Details</h6>
                                <?php
                                $cart_items = explode('; ', $payment['cart_details']);
                                foreach ($cart_items as $item) {
                                    $item_parts = explode(' (Quantity: ', $item);
                                    $product_name = $item_parts[0];
                                    $quantity = isset($item_parts[1]) ? rtrim($item_parts[1], ')') : '1';
                                ?>
                                    <div class="card cart-item-card mb-2">
                                        <div class="card-body p-3">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <p class="card-text mb-0"><strong><?php echo htmlspecialchars($product_name); ?></strong></p>
                                                <span class="badge bg-primary">Qty: <?php echo htmlspecialchars($quantity); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                <?php } ?>
                            </div>
                            <div class="card-footer bg-transparent border-top-0 text-end">
                                <small class="text-muted">
                                    <i class="far fa-calendar-alt me-1"></i> 
                                    <?php echo isset($payment['payment_date']) ? date('M d, Y', strtotime($payment['payment_date'])) : date('M d, Y'); ?>
                                </small>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else : ?>
                <div class="col-12">
                    <div class="no-payments">
                        <i class="far fa-file-alt"></i>
                        <h3>No Payment History Found</h3>
                        <p>You haven't made any payments yet. Your payment history will appear here once you complete a purchase.</p>
                        <a href="products.php" class="btn btn-primary btn-lg mt-3">
                            <i class="fas fa-shopping-bag me-2"></i>Browse Products
                        </a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Footer -->
    <?php include 'footer.php'; ?>

    <script>
        // Initialize jsPDF
        const { jsPDF } = window.jspdf;
        
        document.getElementById('generatePdf').addEventListener('click', function() {
            // Create new PDF document
            const doc = new jsPDF();
            
            // Add title
            doc.setFontSize(20);
            doc.setTextColor(40, 40, 40);
            doc.text('Payment History Report', 105, 20, { align: 'center' });
            
            // Add date
            doc.setFontSize(10);
            doc.setTextColor(100, 100, 100);
            doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 105, 30, { align: 'center' });
            
            // Add line separator
            doc.setDrawColor(200, 200, 200);
            doc.line(20, 35, 190, 35);
            
            let yPosition = 45;
            
            // Add each payment to PDF
            <?php foreach ($payments as $index => $payment): ?>
                // Payment header
                doc.setFontSize(14);
                doc.setTextColor(106, 17, 203);
                doc.text(`Payment #<?php echo $payment['id']; ?>`, 20, yPosition);
                
                // Customer details
                doc.setFontSize(10);
                doc.setTextColor(40, 40, 40);
                yPosition += 10;
                doc.text(`Name: <?php echo $payment['name']; ?>`, 20, yPosition);
                yPosition += 7;
                doc.text(`Contact: <?php echo $payment['contact_number']; ?>`, 20, yPosition);
                yPosition += 7;
                doc.text(`Address: <?php echo $payment['address']; ?>`, 20, yPosition);
                yPosition += 7;
                
                // Total price
                doc.setFontSize(12);
                doc.setTextColor(40, 167, 69);
                doc.text(`Total Price: ₹<?php echo $payment['total_price']; ?>`, 20, yPosition);
                yPosition += 10;
                
                // Order items header
                doc.setFontSize(11);
                doc.setTextColor(220, 53, 69);
                doc.text('Order Items:', 20, yPosition);
                yPosition += 7;
                
                // Order items
                doc.setFontSize(10);
                doc.setTextColor(40, 40, 40);
                <?php 
                $cart_items = explode('; ', $payment['cart_details']);
                foreach ($cart_items as $item): 
                    $item_parts = explode(' (Quantity: ', $item);
                    $product_name = $item_parts[0];
                    $quantity = isset($item_parts[1]) ? rtrim($item_parts[1], ')') : '1';
                ?>
                    doc.text(`• <?php echo $product_name; ?> (Qty: <?php echo $quantity; ?>)`, 25, yPosition);
                    yPosition += 7;
                <?php endforeach; ?>
                
                // Add space between payments
                yPosition += 10;
                
                // Add page break if needed
                if (yPosition > 250 && <?php echo $index; ?> < <?php echo count($payments) - 1; ?>) {
                    doc.addPage();
                    yPosition = 20;
                }
                
                // Add separator line
                doc.setDrawColor(200, 200, 200);
                doc.line(20, yPosition - 5, 190, yPosition - 5);
                
            <?php endforeach; ?>
            
            // Save the PDF
            doc.save('payment_history_<?php echo $user_id; ?>.pdf');
        });
    </script>
</body>

</html>