<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ecommerceone";

$search = isset($_GET['search']) ? $_GET['search'] : '';

try {
    // Create connection using PDO for prepared statements
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // Set PDO to throw exceptions on error
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Query to fetch products from different tables with search filter
    $sql = "
        SELECT id, name, image, description, price, product_id FROM F WHERE name LIKE :search
        UNION
        SELECT id, name, image, description, price, product_id FROM M WHERE name LIKE :search
        UNION
        SELECT id, name, image, description, price, product_id FROM RICE WHERE name LIKE :search
    ";

    $stmt = $conn->prepare($sql);
    $stmt->bindValue(':search', '%' . $search . '%', PDO::PARAM_STR);
    $stmt->execute();
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Close PDO connection
    $conn = null;
} catch (PDOException $e) {
    // Exception handling
    echo "Connection failed: " . $e->getMessage();
    exit(); // Exit script if connection fails
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Management</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --primary: #4361ee;
            --secondary: #ef476f;
            --success: #06d6a0;
            --warning: #ffd166;
            --info: #118ab2;
            --light: #f8f9fa;
            --dark: #212529;
            --gray: #6c757d;
            --gray-light: #e9ecef;
            --gray-dark: #343a40;
            --border-radius: 12px;
            --box-shadow: 0 10px 20px rgba(0, 0, 0, 0.05);
            --transition: all 0.3s ease;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            background: linear-gradient(135deg, #f5f7ff 0%, #e8eeff 100%);
            position: relative;
            overflow-x: hidden;
            padding-bottom: 60px;
        }
        
        body::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            width: 400px;
            height: 400px;
            background: radial-gradient(circle, rgba(239, 71, 111, 0.1) 0%, rgba(239, 71, 111, 0) 70%);
            z-index: -1;
        }
        
        body::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 300px;
            height: 300px;
            background: radial-gradient(circle, rgba(67, 97, 238, 0.1) 0%, rgba(67, 97, 238, 0) 70%);
            z-index: -1;
        }
        
        .products-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .page-header {
            background: linear-gradient(135deg, var(--primary) 0%, #3a56d4 100%);
            color: white;
            border-radius: var(--border-radius);
            padding: 25px 30px;
            margin-bottom: 30px;
            position: relative;
            overflow: hidden;
            box-shadow: var(--box-shadow);
        }
        
        .page-header::before {
            content: '';
            position: absolute;
            top: -50px;
            right: -50px;
            width: 200px;
            height: 200px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.1);
        }
        
        .page-header::after {
            content: '';
            position: absolute;
            bottom: -80px;
            left: -80px;
            width: 300px;
            height: 300px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.05);
        }
        
        .page-title {
            font-weight: 700;
            font-size: 2.2rem;
            margin-bottom: 0;
            position: relative;
            z-index: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
        }
        
        .page-title i {
            font-size: 1.8rem;
        }
        
        .search-section {
            background: white;
            border-radius: var(--border-radius);
            padding: 20px;
            margin-bottom: 30px;
            box-shadow: var(--box-shadow);
        }
        
        .search-form {
            display: flex;
            gap: 15px;
            align-items: center;
        }
        
        .search-input {
            flex: 1;
            height: 50px;
            padding: 10px 20px;
            border-radius: 8px;
            border: 1px solid #dce1e9;
            font-family: 'Poppins', sans-serif;
            transition: var(--transition);
            font-size: 0.95rem;
        }
        
        .search-input:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.15);
            outline: none;
        }
        
        .search-btn {
            height: 50px;
            padding: 0 25px;
            background: var(--primary);
            color: white;
            border: none;
            border-radius: 8px;
            font-weight: 500;
            font-size: 0.95rem;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .search-btn:hover {
            background: #3a56d4;
            transform: translateY(-2px);
        }
        
        .action-buttons {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .action-btn {
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 500;
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: var(--transition);
            cursor: pointer;
        }
        
        .action-btn-primary {
            background: var(--primary);
            color: white;
            border: none;
        }
        
        .action-btn-primary:hover {
            background: #3a56d4;
            transform: translateY(-2px);
        }
        
        .action-btn-secondary {
            background: var(--secondary);
            color: white;
            border: none;
        }
        
        .action-btn-secondary:hover {
            background: #e63e65;
            transform: translateY(-2px);
        }
        
        .action-btn-success {
            background: var(--success);
            color: white;
            border: none;
        }
        
        .action-btn-success:hover {
            background: #05c091;
            transform: translateY(-2px);
        }
        
        .products-table-wrapper {
            background: white;
            border-radius: var(--border-radius);
            overflow: hidden;
            box-shadow: var(--box-shadow);
            margin-bottom: 30px;
        }
        
        .products-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .products-table th {
            background: #f8f9fa;
            padding: 15px;
            text-align: left;
            font-weight: 600;
            color: var(--dark);
            border-bottom: 2px solid #e9ecef;
        }
        
        .products-table td {
            padding: 15px;
            border-bottom: 1px solid #e9ecef;
            vertical-align: middle;
        }
        
        .products-table tr:last-child td {
            border-bottom: none;
        }
        
        .products-table tr:hover {
            background-color: #f8f9fa;
        }
        
        .product-image {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        
        .product-name {
            font-weight: 500;
            color: var(--dark);
        }
        
        .product-description {
            color: var(--gray);
            font-size: 0.9rem;
            max-width: 300px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        
        .product-price {
            font-weight: 600;
            color: var(--primary);
        }
        
        .product-id {
            font-size: 0.9rem;
            color: var(--gray);
        }
        
        .action-column {
            width: 120px;
        }
        
        .delete-btn {
            background: rgba(239, 71, 111, 0.1);
            color: var(--secondary);
            border: none;
            padding: 8px 15px;
            border-radius: 6px;
            font-weight: 500;
            font-size: 0.85rem;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .delete-btn:hover {
            background: var(--secondary);
            color: white;
        }
        
        .back-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: var(--primary);
            text-decoration: none;
            font-weight: 500;
            padding: 10px 20px;
            border: 1px solid var(--primary);
            border-radius: 8px;
            transition: var(--transition);
        }
        
        .back-btn:hover {
            background-color: var(--primary);
            color: white;
            transform: translateY(-2px);
        }
        
        .back-btn i {
            font-size: 0.9rem;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 30px;
        }
        
        .pagination-item {
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 8px;
            background: white;
            color: var(--dark);
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        }
        
        .pagination-item:hover, .pagination-item.active {
            background: var(--primary);
            color: white;
        }
        
        /* Modal styles */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
        }
        
        .modal-overlay.active {
            opacity: 1;
            visibility: visible;
        }
        
        .modal-container {
            background: white;
            width: 90%;
            max-width: 500px;
            border-radius: var(--border-radius);
            overflow: hidden;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
            transform: translateY(20px);
            transition: all 0.3s ease;
        }
        
        .modal-overlay.active .modal-container {
            transform: translateY(0);
        }
        
        .modal-header {
            background: linear-gradient(135deg, var(--primary) 0%, #3a56d4 100%);
            color: white;
            padding: 20px;
            position: relative;
        }
        
        .modal-title {
            font-weight: 600;
            margin: 0;
            font-size: 1.2rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .modal-close {
            position: absolute;
            top: 15px;
            right: 15px;
            background: rgba(255, 255, 255, 0.2);
            border: none;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            cursor: pointer;
            transition: var(--transition);
        }
        
        .modal-close:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: rotate(90deg);
        }
        
        .modal-body {
            padding: 20px;
        }
        
        .modal-footer {
            padding: 15px 20px;
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            border-top: 1px solid #e9ecef;
        }
        
        .modal-btn {
            padding: 8px 20px;
            border-radius: 6px;
            font-weight: 500;
            font-size: 0.9rem;
            cursor: pointer;
            transition: var(--transition);
        }
        
        .modal-btn-cancel {
            background: #f8f9fa;
            color: var(--gray);
            border: 1px solid #e9ecef;
        }
        
        .modal-btn-cancel:hover {
            background: #e9ecef;
        }
        
        .modal-btn-confirm {
            background: var(--secondary);
            color: white;
            border: none;
        }
        
        .modal-btn-confirm:hover {
            background: #e63e65;
        }
        
        /* Animation */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .animate-fade-in-up {
            animation: fadeInUp 0.5s ease forwards;
        }
        
        /* Responsive styles */
        @media (max-width: 991px) {
            .search-form {
                flex-direction: column;
                align-items: stretch;
            }
            
            .products-table {
                display: block;
                overflow-x: auto;
            }
        }
        
        @media (max-width: 767px) {
            .page-title {
                font-size: 1.8rem;
            }
            
            .action-buttons {
                flex-wrap: wrap;
            }
            
            .action-btn {
                flex: 1 1 calc(50% - 10px);
                justify-content: center;
            }
        }
    </style>
</head>

<body>
    <!-- Include necessary files or components -->
    <?php include './adminNavbar.php'; ?>
    
    <div class="products-container">
        <!-- Page Header -->
        <div class="page-header animate-fade-in-up">
            <h1 class="page-title">
                <i class="fas fa-boxes"></i>
                Product Management
            </h1>
        </div>
        
        <!-- Search Section -->
        <div class="search-section animate-fade-in-up" style="animation-delay: 0.1s;">
            <form class="search-form" method="GET">
                <input 
                    type="search" 
                    class="search-input" 
                    placeholder="Search products by name..." 
                    name="search" 
                    value="<?php echo htmlspecialchars($search); ?>"
                >
                <button type="submit" class="search-btn">
                    <i class="fas fa-search"></i>
                    Search
                </button>
            </form>
        </div>
        
        <!-- Action Buttons -->
        <div class="action-buttons animate-fade-in-up" style="animation-delay: 0.2s;">
            <button class="action-btn action-btn-primary" id="generateReportBtn">
                <i class="fas fa-file-pdf"></i>
                Generate PDF Report
            </button>
            <button class="action-btn action-btn-success">
                <i class="fas fa-file-excel"></i>
                Export to Excel
            </button>
            <button class="action-btn action-btn-secondary">
                <i class="fas fa-print"></i>
                Print List
            </button>
        </div>
        
        <!-- Products Table -->
        <div class="products-table-wrapper animate-fade-in-up" style="animation-delay: 0.3s;">
            <table class="products-table" id="productsTable">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Product</th>
                        <th>Description</th>
                        <th>Price</th>
                        <th>Product ID</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($products) > 0): ?>
                        <?php foreach ($products as $product): ?>
                            <tr>
                                <td><?php echo $product['id']; ?></td>
                                <td>
                                    <div class="d-flex align-items-center gap-3">
                                        <img src="<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>" class="product-image">
                                        <span class="product-name"><?php echo $product['name']; ?></span>
                                    </div>
                                </td>
                                <td>
                                    <div class="product-description" title="<?php echo $product['description']; ?>">
                                        <?php echo $product['description']; ?>
                                    </div>
                                </td>
                                <td class="product-price">₹<?php echo $product['price']; ?></td>
                                <td class="product-id"><?php echo $product['product_id']; ?></td>
                                <td class="action-column">
                                    <button 
                                        class="delete-btn" 
                                        data-product-id="<?php echo htmlspecialchars($product['product_id']); ?>"
                                        data-product-name="<?php echo htmlspecialchars($product['name']); ?>"
                                    >
                                        <i class="fas fa-trash-alt"></i>
                                        Delete
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="text-center py-4">No products found</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Pagination -->
        <div class="pagination animate-fade-in-up" style="animation-delay: 0.4s;">
            <div class="pagination-item">
                <i class="fas fa-chevron-left"></i>
            </div>
            <div class="pagination-item active">1</div>
            <div class="pagination-item">2</div>
            <div class="pagination-item">3</div>
            <div class="pagination-item">
                <i class="fas fa-chevron-right"></i>
            </div>
        </div>
        
        <!-- Back Button -->
        <div class="text-center mt-4 animate-fade-in-up" style="animation-delay: 0.5s;">
            <a href="admin_dashboard.php" class="back-btn">
                <i class="fas fa-arrow-left"></i>
                Back to Dashboard
            </a>
        </div>
    </div>
    
    <!-- Delete Confirmation Modal -->
    <div class="modal-overlay" id="deleteModal">
        <div class="modal-container">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-exclamation-triangle"></i>
                    Confirm Deletion
                </h5>
                <button class="modal-close" id="closeModal">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete the product <strong id="productNameToDelete"></strong>?</p>
                <p class="text-muted">This action cannot be undone.</p>
            </div>
            <div class="modal-footer">
                <button class="modal-btn modal-btn-cancel" id="cancelDelete">Cancel</button>
                <form method="POST" action="delete_product.php" id="deleteForm">
                    <input type="hidden" name="product_id" id="productIdToDelete">
                    <button type="submit" class="modal-btn modal-btn-confirm">Delete</button>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Include footer -->
    <?php include './footer.php'; ?>
    
    <!-- Bootstrap JS Bundle (Popper.js included) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jsPDF for PDF generation -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Delete confirmation modal
            const deleteModal = document.getElementById('deleteModal');
            const closeModal = document.getElementById('closeModal');
            const cancelDelete = document.getElementById('cancelDelete');
            const deleteButtons = document.querySelectorAll('.delete-btn');
            const productNameToDelete = document.getElementById('productNameToDelete');
            const productIdToDelete = document.getElementById('productIdToDelete');
            
            // Show modal when delete button is clicked
            deleteButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const productId = this.getAttribute('data-product-id');
                    const productName = this.getAttribute('data-product-name');
                    
                    productIdToDelete.value = productId;
                    productNameToDelete.textContent = productName;
                    
                    deleteModal.classList.add('active');
                });
            });
            
            // Close modal
            closeModal.addEventListener('click', function() {
                deleteModal.classList.remove('active');
            });
            
            cancelDelete.addEventListener('click', function() {
                deleteModal.classList.remove('active');
            });
            
            // Close modal when clicking outside
            deleteModal.addEventListener('click', function(e) {
                if (e.target === deleteModal) {
                    deleteModal.classList.remove('active');
                }
            });
            
            // PDF Report Generation
            const generateReportBtn = document.getElementById('generateReportBtn');
            
            generateReportBtn.addEventListener('click', function() {
                // Initialize jsPDF
                const { jsPDF } = window.jspdf;
                const doc = new jsPDF();
                
                // Add title
                doc.setFontSize(18);
                doc.setTextColor(67, 97, 238);
                doc.text('Product Inventory Report', 105, 15, { align: 'center' });
                
                // Add date
                const today = new Date();
                const dateStr = today.toLocaleDateString('en-US', { 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric' 
                });
                doc.setFontSize(11);
                doc.setTextColor(108, 117, 125);
                doc.text(`Generated on: ${dateStr}`, 105, 22, { align: 'center' });
                
                // Add company info
                doc.setFontSize(10);
                doc.setTextColor(33, 37, 41);
                doc.text('Your Company Name', 20, 35);
                doc.text('123 Business Street', 20, 40);
                doc.text('City, State, ZIP', 20, 45);
                doc.text('Phone: (123) 456-7890', 20, 50);
                
                // Create table data from products
                const tableColumn = ["ID", "Name", "Description", "Price", "Product ID"];
                const tableRows = [];
                
                // Get data from table
                const table = document.getElementById('productsTable');
                const rows = table.querySelectorAll('tbody tr');
                
                rows.forEach(row => {
                    const cells = row.querySelectorAll('td');
                    if (cells.length >= 5) {
                        const rowData = [
                            cells[0].textContent.trim(),
                            cells[1].querySelector('.product-name').textContent.trim(),
                            cells[2].querySelector('.product-description').textContent.trim(),
                            cells[3].textContent.trim(),
                            cells[4].textContent.trim()
                        ];
                        tableRows.push(rowData);
                    }
                });
                
                // Generate table
                doc.autoTable({
                    head: [tableColumn],
                    body: tableRows,
                    startY: 60,
                    theme: 'grid',
                    styles: {
                        fontSize: 9,
                        cellPadding: 3,
                    },
                    headStyles: {
                        fillColor: [67, 97, 238],
                        textColor: [255, 255, 255],
                        fontStyle: 'bold'
                    },
                    alternateRowStyles: {
                        fillColor: [245, 247, 255]
                    }
                });
                
                // Add summary
                const finalY = doc.lastAutoTable.finalY || 60;
                doc.setFontSize(11);
                doc.setTextColor(33, 37, 41);
                doc.text(`Total Products: ${tableRows.length}`, 20, finalY + 15);
                
                // Add footer
                const pageCount = doc.internal.getNumberOfPages();
                for (let i = 1; i <= pageCount; i++) {
                    doc.setPage(i);
                    doc.setFontSize(9);
                    doc.setTextColor(108, 117, 125);
                    doc.text('Page ' + i + ' of ' + pageCount, 105, doc.internal.pageSize.height - 10, { align: 'center' });
                    doc.text('© ' + new Date().getFullYear() + ' Your Company Name - All Rights Reserved', 105, doc.internal.pageSize.height - 5, { align: 'center' });
                }
                
                // Save PDF
                doc.save('product_inventory_report.pdf');
            });
        });
    </script>
</body>
</html>