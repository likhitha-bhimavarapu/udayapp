<?php
session_start();
include 'db_config.php';

// Fetch products from the database
$sql = "SELECT * FROM product";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grocery Store</title>

   <!-- Bootstrap link -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

<!-- Tailwind CSS -->
<script src="https://cdn.tailwindcss.com"></script>

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>
    body {
        font-family: 'Poppins', sans-serif;
        background-color: #f7f9fc;
    }
    
    .hero-image {
        height: 60vh;
        object-fit: cover;
        filter: brightness(0.9);
    }
    
    .hero-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 60vh;
        background: linear-gradient(rgba(0,0,0,0.2), rgba(0,0,0,0.5));
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .hero-text {
        color: white;
        text-align: center;
        text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
    }
    
    .product-card {
        transition: all 0.3s ease;
        border: none;
        border-radius: 12px;
        overflow: hidden;
        box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    }
    
    .product-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 25px rgba(0,0,0,0.1);
    }
    
    .product-img-container {
        height: 180px;
        display: flex;
        align-items: center;
        justify-content: center;
        background-color: #f8f9fa;
        padding: 20px;
    }
    
    .product-img {
        max-height: 140px;
        max-width: 80%;
        object-fit: contain;
    }
    
    .product-title {
        font-weight: 600;
        font-size: 1.1rem;
        color: #2d3748;
        margin-bottom: 8px;
    }
    
    .product-description {
        color: #718096;
        font-size: 0.9rem;
        height: 60px;
        overflow: hidden;
    }
    
    .product-price {
        font-weight: 700;
        color: #38a169;
        font-size: 1.2rem;
        margin: 10px 0;
    }
    
    .buy-btn {
        background: linear-gradient(135deg, #38a169, #2f855a);
        border: none;
        border-radius: 50px;
        padding: 8px 25px;
        color: white;
        font-weight: 500;
        transition: all 0.3s ease;
    }
    
    .buy-btn:hover {
        background: linear-gradient(135deg, #2f855a, #276749);
        transform: scale(1.05);
    }
    
    .section-title {
        position: relative;
        display: inline-block;
        font-weight: 700;
        color: #2d3748;
        margin-bottom: 30px;
        padding-bottom: 10px;
    }
    
    .section-title::after {
        content: '';
        position: absolute;
        left: 0;
        bottom: 0;
        width: 60px;
        height: 4px;
        background: linear-gradient(135deg, #38a169, #2f855a);
        border-radius: 2px;
    }
    
    .category-badge {
        background-color: #ebf4ff;
        color: #4c51bf;
        font-size: 0.75rem;
        padding: 4px 10px;
        border-radius: 20px;
        display: inline-block;
        margin-bottom: 10px;
    }
    
    .stock-info {
        font-size: 0.8rem;
        color: #718096;
    }
    
    .in-stock {
        color: #38a169;
        font-weight: 500;
    }
</style>
    <?php include './navbar.php'?>
<!-- Hero Section -->
<div class="relative">
    <img src="./one.jpg" class="w-full hero-image" alt="Fresh Groceries">
    <div class="hero-overlay">
        <div class="hero-text">
            <h1 class="text-4xl md:text-5xl font-bold mb-2">Fresh & Healthy Groceries</h1>
            <p class="text-xl md:text-2xl">Quality products delivered to your doorstep</p>
        </div>
    </div>
</div>

<!-- Features Section -->
<div class="container mx-auto py-10 px-4">
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="bg-white p-6 rounded-lg shadow-md text-center">
            <div class="text-4xl mb-4 text-green-600">🚚</div>
            <h3 class="text-xl font-semibold mb-2">Free Delivery</h3>
            <p class="text-gray-600">On orders above ₹500</p>
        </div>
        <div class="bg-white p-6 rounded-lg shadow-md text-center">
            <div class="text-4xl mb-4 text-green-600">🥦</div>
            <h3 class="text-xl font-semibold mb-2">Fresh Produce</h3>
            <p class="text-gray-600">Farm to table quality</p>
        </div>
        <div class="bg-white p-6 rounded-lg shadow-md text-center">
            <div class="text-4xl mb-4 text-green-600">⏱️</div>
            <h3 class="text-xl font-semibold mb-2">24/7 Support</h3>
            <p class="text-gray-600">Always here to help you</p>
        </div>
    </div>
</div>

<!-- Products Section -->
<div class="container mx-auto py-10 px-4">
    <h2 class="section-title text-3xl">Grocery Products</h2>
    
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '<div class="product-card bg-white">';
                echo '<div class="product-img-container">';
                echo '<img src="' . $row['image'] . '" class="product-img" alt="' . $row['name'] . '">';
                echo '</div>';
                echo '<div class="p-5">';
                echo '<span class="category-badge">Grocery</span>';
                echo '<h5 class="product-title">' . $row['name'] . '</h5>';
                echo '<p class="product-description">' . $row['description'] . '</p>';
                echo '<div class="flex justify-between items-center mt-4">';
                echo '<p class="product-price">₹' . $row['price'] . '</p>';
                echo '<span class="stock-info"><span class="in-stock">✓</span> In Stock</span>';
                echo '</div>';
                echo '<div class="mt-4">';
                echo '<a href="./login.php" class="buy-btn inline-block">Add to Cart</a>';
                echo '</div>';
                echo '</div>';
                echo '</div>';
            }
        } else {
            echo '<div class="col-span-3 text-center py-10">';
            echo '<div class="text-5xl mb-4">😢</div>';
            echo '<h3 class="text-2xl font-semibold mb-2">No Products Found</h3>';
            echo '<p class="text-gray-600">Please check back later for our amazing grocery products.</p>';
            echo '</div>';
        }
        ?>
    </div>
</div>

<!-- Newsletter Section -->
<div class="bg-green-50 py-12">
    <div class="container mx-auto px-4">
        <div class="max-w-2xl mx-auto text-center">
            <h3 class="text-2xl font-bold mb-4">Subscribe to Our Newsletter</h3>
            <p class="text-gray-600 mb-6">Get updates on new products and exclusive offers</p>
            <div class="flex flex-col md:flex-row gap-2">
                <input type="email" placeholder="Your email address" class="flex-grow px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                <button class="buy-btn px-6 py-3">Subscribe</button>
            </div>
        </div>
    </div>
</div>

<?php include './footer.php' ?>

<script>
    // Add smooth scrolling
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });
</script>