<?php
// Start the session at the beginning of the script
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Payments</title>
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- jsPDF -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>
    <style>
        :root {
            --primary-color: #dc3545;
            --secondary-color: #6c757d;
            --accent-color: #fd7e14;
            --light-color: #f8f9fa;
            --dark-color: #343a40;
            --success-color: #28a745;
            --info-color: #17a2b8;
        }
        
        body {
            background-color: #f5f5f5;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .container {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            padding: 25px;
            margin-top: 30px;
            margin-bottom: 30px;
        }
        
        .page-title {
            color: var(--primary-color);
            font-weight: 700;
            margin-bottom: 25px;
            position: relative;
            padding-bottom: 10px;
        }
        
        .page-title:after {
            content: '';
            position: absolute;
            left: 0;
            bottom: 0;
            width: 60px;
            height: 3px;
            background-color: var(--primary-color);
        }
        
        .search-container {
            margin-bottom: 25px;
        }
        
        .search-container input {
            border-radius: 20px;
            padding: 10px 20px;
            border: 1px solid #ced4da;
            transition: all 0.3s;
        }
        
        .search-container input:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(220, 53, 69, 0.25);
        }
        
        .search-container .btn {
            border-radius: 20px;
            padding: 10px 20px;
            transition: all 0.3s;
        }
        
        .cards-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 20px;
        }
        
        .payment-card {
            border-radius: 10px;
            border: none;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            overflow: hidden;
        }
        
        .payment-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
        }
        
        .payment-card .card-header {
            background-color: var(--primary-color);
            color: white;
            font-weight: 600;
            padding: 15px;
            border-bottom: none;
        }
        
        .payment-card .card-body {
            padding: 20px;
        }
        
        .payment-card .info-label {
            color: var(--secondary-color);
            font-weight: 500;
        }
        
        .payment-card .info-value {
            color: var(--dark-color);
            font-weight: 400;
        }
        
        .cart-item {
            background-color: rgba(40, 167, 69, 0.1);
            border-radius: 8px;
            padding: 10px;
            margin-bottom: 10px;
            border-left: 3px solid var(--success-color);
        }
        
        .cart-item-title {
            color: var(--success-color);
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .btn-pdf {
            background-color: var(--accent-color);
            color: white;
            border: none;
            border-radius: 20px;
            padding: 10px 20px;
            transition: all 0.3s;
        }
        
        .btn-pdf:hover {
            background-color: #e06c00;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        
        .btn-back {
            border-radius: 20px;
            padding: 10px 20px;
            transition: all 0.3s;
        }
        
        @media (max-width: 768px) {
            .cards-container {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
<?php include './adminNavbar.php'; ?>

<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="page-title">View Payments</h2>
        <button id="generatePdf" class="btn btn-pdf">
            <i class="fas fa-file-pdf me-2"></i> Generate PDF Report
        </button>
    </div>
    
    <div class="search-container">
        <form method="GET" action="" class="d-flex">
            <input type="text" class="form-control me-2" name="search" placeholder="Search by Name, Contact Number, or Payment ID" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
            <button class="btn btn-outline-danger" type="submit">
                <i class="fas fa-search me-1"></i> Search
            </button>
        </form>
    </div>
    
    <div class="cards-container">
    <?php
        // Database connection details
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "ecommerceone";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Get search query if it exists
        $search_query = isset($_GET['search']) ? $_GET['search'] : '';

        // Query to fetch payment details from the database
        $sql = "SELECT * FROM payments";
        if ($search_query) {
            $sql .= " WHERE name LIKE '%$search_query%' OR contact_number LIKE '%$search_query%' OR id LIKE '%$search_query%'";
        }
        $sql .= " ORDER BY id DESC";

        $result = $conn->query($sql);

        // Check if any rows are returned
        if ($result->num_rows > 0) {
            // Output data of each row in card format
            while ($row = $result->fetch_assoc()) {
                echo "<div class='card payment-card mb-4'>";
                echo "<div class='card-header'>";
                echo "Payment ID: " . htmlspecialchars($row["id"]);
                echo "</div>";
                echo "<div class='card-body'>";
                echo "<div class='mb-3'>";
                echo "<p class='info-label'>Name</p>";
                echo "<p class='info-value'>" . htmlspecialchars($row["name"]) . "</p>";
                echo "</div>";
                
                echo "<div class='mb-3'>";
                echo "<p class='info-label'>Contact Number</p>";
                echo "<p class='info-value'>" . htmlspecialchars($row["contact_number"]) . "</p>";
                echo "</div>";
                
                echo "<div class='mb-3'>";
                echo "<p class='info-label'>Card Number</p>";
                echo "<p class='info-value'>**** **** **** " . substr(htmlspecialchars($row["card_number"]), -4) . "</p>";
                echo "</div>";
                
                echo "<div class='mb-3'>";
                echo "<p class='info-label'>Expiry Date</p>";
                echo "<p class='info-value'>" . htmlspecialchars($row["expiry_date"]) . "</p>";
                echo "</div>";
                
                echo "<div class='mb-3'>";
                echo "<p class='info-label'>Address</p>";
                echo "<p class='info-value'>" . htmlspecialchars($row["address"]) . "</p>";
                echo "</div>";
                
                echo "<div class='mb-3'>";
                echo "<p class='info-label'>Total Price</p>";
                echo "<p class='info-value' style='color: var(--primary-color); font-weight: 600;'>₹" . htmlspecialchars($row["total_price"]) . "</p>";
                echo "</div>";
                
                echo "<div class='mb-3'>";
                echo "<p class='info-label'>Cart Details</p>";
                
                // Split cart details and display each item
                $cart_items = explode('; ', $row['cart_details']);
                foreach ($cart_items as $item) {
                    $item_parts = explode(', Price: ₹', $item);
                    if (count($item_parts) >= 2) {
                        $product_name = $item_parts[0];
                        $price = $item_parts[1];
                        
                        echo "<div class='cart-item'>";
                        echo "<p class='cart-item-title'>" . htmlspecialchars($product_name) . "</p>";
                        echo "<p class='info-value'>Price: ₹" . htmlspecialchars($price) . "</p>";
                        echo "</div>";
                    }
                }
                echo "</div>";
                echo "</div>";
                echo "</div>";
            }
        } else {
            echo "<div class='col-12 text-center py-5'>";
            echo "<i class='fas fa-receipt fa-3x mb-3' style='color: var(--secondary-color);'></i>";
            echo "<h4 class='text-muted'>No payment records found</h4>";
            echo "</div>";
        }

        $conn->close();
    ?>
    </div>
</div>

<a href="admin_dashboard.php" class="btn btn-outline-danger m-4">
    <i class="fas fa-arrow-left me-2"></i> Back to Dashboard
</a>

<?php include './footer.php'; ?>

<script>
    // PDF Generation with jsPDF - Improved version to prevent overlapping
    document.getElementById('generatePdf').addEventListener('click', function() {
        // Show loading indicator
        Swal.fire({
            title: 'Generating PDF',
            html: 'Please wait while we prepare your report...',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });

        // Initialize jsPDF in landscape mode for more space
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF('l', 'pt', 'a4'); // Landscape mode
        
        // Add title
        doc.setFontSize(18);
        doc.setTextColor(220, 53, 69);
        doc.text('Payment Records Report', doc.internal.pageSize.width / 2, 30, { align: 'center' });
        
        // Add date
        doc.setFontSize(10);
        doc.setTextColor(100, 100, 100);
        doc.text('Generated on: ' + new Date().toLocaleString(), doc.internal.pageSize.width / 2, 45, { align: 'center' });
        
        // Add line separator
        doc.setDrawColor(220, 53, 69);
        doc.setLineWidth(0.5);
        doc.line(40, 55, doc.internal.pageSize.width - 40, 55);
        
        // Prepare table data with better formatting
        const headers = [
            { title: "ID", dataKey: "id" },
            { title: "Name", dataKey: "name" },
            { title: "Contact", dataKey: "contact" },
            { title: "Total", dataKey: "total" },
            { title: "Items (Qty)", dataKey: "items" }
        ];
        
        const rows = [];
        
        // Get all payment cards
        const paymentCards = document.querySelectorAll('.payment-card');
        paymentCards.forEach(card => {
            const id = card.querySelector('.card-header').textContent.replace('Payment ID: ', '');
            const name = card.querySelectorAll('.info-value')[0].textContent;
            const contact = card.querySelectorAll('.info-value')[1].textContent;
            const total = card.querySelectorAll('.info-value')[5].textContent;
            
            // Get cart items with better formatting
            const items = [];
            const cartItems = card.querySelectorAll('.cart-item');
            cartItems.forEach(item => {
                const itemName = item.querySelector('.cart-item-title').textContent;
                const itemPrice = item.querySelector('.info-value').textContent;
                items.push(`${itemName} (${itemPrice})`);
            });
            
            rows.push({
                id: id,
                name: name,
                contact: contact,
                total: total,
                items: items.join('\n') // Single newline between items
            });
        });
        
        // Calculate column widths based on content
        const columnStyles = {
            0: { cellWidth: 40 },  // ID
            1: { cellWidth: 60 },  // Name
            2: { cellWidth: 70 },  // Contact
            3: { cellWidth: 40 },  // Total
            4: { cellWidth: 120 }  // Items (fixed width with line breaks)
        };
        
        // Add table to PDF with better configuration
        doc.autoTable({
            head: [headers.map(header => header.title)],
            body: rows.map(row => [row.id, row.name, row.contact, row.total, row.items]),
            startY: 65,
            theme: 'grid',
            headStyles: {
                fillColor: [220, 53, 69],
                textColor: 255,
                fontStyle: 'bold',
                fontSize: 10
            },
            bodyStyles: {
                fontSize: 9,
                cellPadding: 4,
                overflow: 'linebreak',
                minCellHeight: 20
            },
            alternateRowStyles: {
                fillColor: [248, 249, 250]
            },
            columnStyles: columnStyles,
            margin: { 
                top: 65,
                left: 40,
                right: 40,
                bottom: 40
            },
            tableWidth: 'wrap',
            showHead: 'everyPage',
            pageBreak: 'auto',
            horizontalPageBreak: true,
            tableLineWidth: 0.1,
            tableLineColor: [200, 200, 200],
            didDrawPage: function(data) {
                // Footer with page numbers
                doc.setFontSize(10);
                doc.setTextColor(150);
                const pageCount = doc.internal.getNumberOfPages();
                doc.text(
                    `Page ${data.pageNumber} of ${pageCount}`,
                    doc.internal.pageSize.width / 2,
                    doc.internal.pageSize.height - 20,
                    { align: 'center' }
                );
            }
        });
        
        // Save the PDF
        setTimeout(() => {
            doc.save('payment_report_' + new Date().toISOString().slice(0, 10) + '.pdf');
            
            // Show success message
            Swal.fire({
                title: 'Report Generated!',
                text: 'The PDF report has been downloaded.',
                icon: 'success',
                confirmButtonColor: '#dc3545',
                timer: 2000,
                timerProgressBar: true
            });
        }, 500);
    });
</script>

<!-- SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>