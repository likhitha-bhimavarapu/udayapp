<!-- Footer -->
<footer class="text-center text-lg-start text-dark" style="background-color: #ECEFF1">
  <!-- Section: Social media -->
  <section class="d-flex justify-content-between p-4 text-white" style="background-color: skyblue">
    <!-- Left -->
    <div class="me-5">
      <span>Get connected with us on social networks:</span>
    </div>
    <!-- Left -->

    <!-- Right -->
    <div>
      <a href="" class="text-white me-4">
        <i class="fab fa-facebook-f"></i>
      </a>
      <a href="" class="text-white me-4">
        <i class="fab fa-twitter"></i>
      </a>
      <a href="" class="text-white me-4">
        <i class="fab fa-google"></i>
      </a>
      <a href="" class="text-white me-4">
        <i class="fab fa-instagram"></i>
      </a>
      <a href="" class="text-white me-4">
        <i class="fab fa-linkedin"></i>
      </a>
      <a href="" class="text-white me-4">
        <i class="fab fa-github"></i>
      </a>
    </div>
    <!-- Right -->
  </section>
  <!-- Section: Social media -->

  <!-- Section: Links  -->
  <section class="">
    <div class="container text-center text-md-start mt-5">
      <!-- Grid row -->
      <div class="row mt-3">
        <!-- Grid column -->
        <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
          <!-- Content -->
          <h6 class="text-uppercase fw-bold text-info">Company name</h6>
          <hr class="mb-4 mt-0 d-inline-block mx-auto" style="width: 60px; background-color: #7c4dff; height: 2px" />
          <h6 class="text-success ">
            Registered Office
            Flat No. 100/9, 10th Floor, #1013, Raj Mahal Grand,
            Madhura, Chennai, 500001.
</h6>
        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
          <!-- Links -->
          <h6 class="text-uppercase fw-bold text-info">Products</h6>
          <hr class="mb-4 mt-0 d-inline-block mx-auto" style="width: 60px; background-color: #7c4dff; height: 2px" />
          <h6>
            <a href="fruits.php" class="text-success" style="text-decoration: none;">Fruit's & Vegetable's</a>
</h6>
<h6>
            <a href="meat.php" class="text-success" style="text-decoration: none;">Egg's, Meat & Fish Product's</a>
</h6>
<h6>
            <a href="rice.php" class="text-success" style="text-decoration: none;">Rice, Atta & Dal's</a>
</h6>
        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
          <!-- Links -->
          <h6 class="text-uppercase fw-bold text-info">Useful links</h6>
          <hr class="mb-4 mt-0 d-inline-block mx-auto" style="width: 60px; background-color: #7c4dff; height: 2px" />
          <h6>
            <a href="myprofile.php" class="text-success" style="text-decoration: none;">Your Account</a>
</h6>
          <h6>
            <a href="mycart.php" class="text-success" style="text-decoration: none;">Your Cart</a>
</h6>
<h6>
            <a href="orderH.php" class="text-success" style="text-decoration: none;">Your Orders</a>
</h6>
        
        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
          <!-- Links -->
          <h6 class="text-uppercase fw-bold text-info">Contact</h6>
          <hr class="mb-4 mt-0 d-inline-block mx-auto" style="width: 60px; background-color: #7c4dff; height: 2px" />
          <h6 class="text-success">Customer Support
            CustomerCare Number:+91 0863-1000-0001

            24/7*365 Days</h6>
        </div>
        <!-- Grid column -->
      </div>
      <!-- Grid row -->
    </div>
  </section>
  <!-- Section: Links  -->

  <!-- Copyright -->
  <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2)">
    © 2020 Copyright:
  </div>
  <!-- Copyright -->
</footer>
<!-- Footer -->
</div>
<!-- End of .container -->