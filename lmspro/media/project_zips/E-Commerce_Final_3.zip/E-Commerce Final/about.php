<!-- about.php -->
<!DOCTYPE html>
<html>
<head>
    <title>About Us</title>
</head>
<style>
      body {
        background: linear-gradient(rgba(1.1, 10.10, 10.10, 0.1), rgba(100.1, 2.1, 1.1, 0.5));
    }
</style>
<body>
    <?php include 'pnav.php'; ?>
    <!-- Other content of the about page -->
    <br>
    <br>
    <div class="container">
    <h2 class="text-danger">Welcome to [Grocery Store E-commerce]!</h2>
<br>
<br>
<i class=""><span style="font-size: 80px;">W</span>e are a family-owned and operated grocery store that has been serving the community for over 50 years. We are committed to providing our customers with the freshest and highest quality products at the best possible prices.
We offer a wide variety of groceries, including fresh produce, meat, seafood, dairy, baked goods, and more. We also have a full-service deli and bakery, where you can find everything from fresh-made sandwiches and salads to custom-decorated cakes and pastries.
Our friendly and knowledgeable staff is always happy to help you find what you need. We also offer a variety of convenient services, such as online ordering, curbside pickup, and delivery.
We are proud to be a part of the community and we are committed to supporting our local businesses. We source our products from local farms and suppliers whenever possible. We also donate a portion of our proceeds to local charities and organizations.
Thank you for choosing [Grocery Store Name]! We look forward to serving you.</i>
    </div>
    <br>
    <br>
    <br>
    <?php include 'footer.php'; ?>
</body>
</html>
