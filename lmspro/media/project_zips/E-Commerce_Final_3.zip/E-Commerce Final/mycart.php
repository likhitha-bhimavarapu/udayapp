<?php
session_start();

// Function to calculate total
function calculateTotal($cart_items)
{
    $total = 0;
    foreach ($cart_items as $item) {
        $total += $item['price'] * $item['quantity'];
    }
    return number_format($total, 2);
}

// Initialize session cart for testing
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Handle add to cart form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    $product_id = $_POST['product_id']; // Example: You need to have a way to identify products uniquely
    $quantity = $_POST['quantity'];

    // Check if the product already exists in the cart
    $product_exists = true;
    foreach ($_SESSION['cart'] as &$item) {
        if ($item['product_id'] == $product_id) {
            // Product already exists, update the quantity
            $item['quantity'] += $quantity;
            $product_exists = true;
            break;
        }
    }

    // If the product doesn't exist, add it as a new item
 
}

// Remove item from cart based on index
if (isset($_POST['remove_index']) && is_numeric($_POST['remove_index'])) {
    $index = $_POST['remove_index'];
    if (isset($_SESSION['cart'][$index])) {
        unset($_SESSION['cart'][$index]);
        // Reset array keys to maintain continuity
        $_SESSION['cart'] = array_values($_SESSION['cart']);
    }
}

// Get cart items from session
$cart_items = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Cart</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
        integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
        crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
        crossorigin="anonymous"></script>
  
</head>
    <style>
        :root {
            --primary-color: #3498db;
            --secondary-color: #2ecc71;
            --accent-color: #f39c12;
            --danger-color: #e74c3c;
            --dark-color: #2c3e50;
            --light-color: #ecf0f1;
            --border-color: #e0e0e0;
            --shadow-color: rgba(0, 0, 0, 0.1);
        }
        
        body {
            font-family: 'Nunito', sans-serif;
            background-color: #f8f9fa;
            color: #333;
            padding-bottom: 50px;
        }
        
        .cart-container {
            padding: 40px 0;
        }
        
        .cart-header {
            margin-bottom: 30px;
            position: relative;
            text-align: center;
        }
        
        .cart-header h2 {
            font-weight: 700;
            color: var(--dark-color);
            display: inline-block;
            position: relative;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        
        .cart-header h2::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
            border-radius: 2px;
        }
        
        .cart-header p {
            color: #6c757d;
            font-size: 1.1rem;
        }
        
        .cart-items-container {
            background-color: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px var(--shadow-color);
            padding: 25px;
            margin-bottom: 30px;
        }
        
        .cart-item {
            position: relative;
            background-color: white;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            border: 1px solid var(--border-color);
        }
        
        .cart-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }
        
        .cart-item img {
            width: 120px;
            height: 120px;
            object-fit: cover;
            border-radius: 10px;
            margin-right: 25px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
        }
        
        .cart-item:hover img {
            transform: scale(1.05);
        }
        
        .cart-item-details {
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        
        .cart-item-details p:first-child {
            font-size: 1.2rem;
            font-weight: 700;
            color: var(--dark-color);
            margin-bottom: 5px;
        }
        
        .cart-item-details p:nth-child(2) {
            font-size: 0.95rem;
            color: #6c757d;
            margin-bottom: 15px;
        }
        
        .cart-item-details p:nth-child(2) span {
            font-weight: 600;
            color: var(--primary-color);
        }
        
        .quantity-control {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .quantity-control p {
            margin-bottom: 0;
            margin-right: 10px;
            font-weight: 600;
        }
        
        .quantity-btn {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
            font-weight: 700;
            background-color: var(--primary-color);
            color: white;
            border: none;
            cursor: pointer;
            transition: all 0.2s ease;
            box-shadow: 0 3px 10px rgba(52, 152, 219, 0.3);
        }
        
        .quantity-btn:hover {
            background-color: #2980b9;
            transform: scale(1.05);
        }
        
        .quantity-btn:active {
            transform: scale(0.95);
        }
        
        .quantity-input {
            width: 50px;
            height: 36px;
            text-align: center;
            font-weight: 600;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            margin: 0 10px;
            transition: all 0.3s ease;
        }
        
        .quantity-input:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.2);
            outline: none;
        }
        
        .totalPrice {
            font-size: 1.1rem;
            font-weight: 700;
            color: var(--secondary-color);
            margin-bottom: 15px;
        }
        
        .remove-btn {
            background-color: var(--danger-color);
            color: white;
            border: none;
            border-radius: 8px;
            padding: 8px 15px;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 3px 10px rgba(231, 76, 60, 0.3);
        }
        
        .remove-btn:hover {
            background-color: #c0392b;
            transform: translateY(-2px);
        }
        
        .remove-btn:active {
            transform: translateY(0);
        }
        
        .cart-summary {
            background-color: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px var(--shadow-color);
            padding: 25px;
            position: sticky;
            top: 20px;
        }
        
        .summary-header {
            font-size: 1.3rem;
            font-weight: 700;
            color: var(--dark-color);
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid var(--border-color);
            position: relative;
        }
        
        .summary-header::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 80px;
            height: 2px;
            background-color: var(--primary-color);
        }
        
        .summary-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 12px;
            font-size: 0.95rem;
            color: #6c757d;
        }
        
        .summary-item.highlight {
            color: var(--dark-color);
            font-weight: 600;
        }
        
        .summary-item .value {
            font-weight: 600;
        }
        
        .summary-item .strikethrough {
            text-decoration: line-through;
            color: #adb5bd;
            margin-right: 5px;
        }
        
        .summary-item .discount {
            color: var(--danger-color);
            font-weight: 600;
        }
        
        .free-delivery-note {
            background-color: rgba(46, 204, 113, 0.1);
            border-left: 4px solid var(--secondary-color);
            padding: 10px 15px;
            border-radius: 5px;
            margin: 15px 0;
            font-size: 0.9rem;
            color: #2c3e50;
        }
        
        .estimated-total {
            margin-top: 20px;
            padding-top: 15px;
            border-top: 2px solid var(--border-color);
            font-size: 1.3rem;
            font-weight: 700;
            color: var(--secondary-color);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .checkout-btn {
            display: block;
            width: 100%;
            background: linear-gradient(135deg, var(--secondary-color) 0%, #27ae60 100%);
            color: white;
            border: none;
            border-radius: 50px;
            padding: 12px;
            font-size: 1.1rem;
            font-weight: 700;
            margin-top: 20px;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(46, 204, 113, 0.3);
            text-align: center;
            text-decoration: none;
        }
        
        .checkout-btn:hover {
            background: linear-gradient(135deg, #27ae60 0%, var(--secondary-color) 100%);
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(46, 204, 113, 0.4);
            color: white;
        }
        
        .checkout-btn:active {
            transform: translateY(-1px);
        }
        
        .checkout-btn i {
            margin-left: 8px;
        }
        
        .empty-cart {
            text-align: center;
            padding: 50px 0;
        }
        
        .empty-cart i {
            font-size: 5rem;
            color: #adb5bd;
            margin-bottom: 20px;
        }
        
        .empty-cart h4 {
            color: var(--secondary-color);
            font-weight: 600;
            margin-bottom: 20px;
        }
        
        .empty-cart .shop-now-btn {
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-radius: 50px;
            padding: 10px 25px;
            font-weight: 600;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
        }
        
        .empty-cart .shop-now-btn:hover {
            background-color: #2980b9;
            transform: translateY(-2px);
        }
        
        /* Responsive styles */
        @media (max-width: 991px) {
            .cart-summary {
                margin-top: 30px;
                position: static;
            }
        }
        
        @media (max-width: 767px) {
            .cart-item {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .cart-item img {
                margin-right: 0;
                margin-bottom: 15px;
                width: 100%;
                height: 200px;
            }
            
            .cart-container {
                padding: 20px 0;
            }
        }
        
        /* Animation */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .cart-item {
            animation: fadeIn 0.5s ease forwards;
        }
        
        .cart-item:nth-child(1) { animation-delay: 0.1s; }
        .cart-item:nth-child(2) { animation-delay: 0.2s; }
        .cart-item:nth-child(3) { animation-delay: 0.3s; }
        .cart-item:nth-child(4) { animation-delay: 0.4s; }
        .cart-item:nth-child(5) { animation-delay: 0.5s; }
    </style>
</head>
<body>
    <?php include './pnav.php' ?>
    
    <div class="container cart-container">
        <div class="cart-header">
            <h2><i class="fas fa-shopping-cart me-2"></i>Your Shopping Cart</h2>
            <p>Review your items and proceed to checkout</p>
        </div>
        
        <div class="row">
            <div class="col-lg-8">
                <div class="cart-items-container">
                    <?php if (!empty($cart_items)) : ?>
                        <?php foreach ($cart_items as $index => $item) : ?>
                            <div class="cart-item d-flex align-items-center">
                                <img src="<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
                                <div class="cart-item-details">
                                    <p><?php echo $item['name']; ?></p>
                                    <p>Price: <span><?php echo $item['price']; ?> Rs</span> each</p>
                                    
                                    <div class="quantity-control">
                                        <p>Quantity:</p>
                                        <button class="quantity-btn" onclick="decrement(this)">-</button>
                                        <input type="text" class="quantity-input" value="<?php echo $item['quantity']; ?>" 
                                               data-price="<?php echo $item['price']; ?>" onchange="updateTotal(this)">
                                        <button class="quantity-btn" onclick="increment(this)">+</button>
                                    </div>
                                    
                                    <p class="totalPrice">Total: <?php echo $item['price'] * $item['quantity']; ?> Rs</p>
                                    
                                    <div>
                                        <form method="POST">
                                            <input type="hidden" name="remove_index" value="<?php echo $index; ?>">
                                            <button type="submit" class="remove-btn">
                                                <i class="fas fa-trash-alt me-2"></i>Remove
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <div class="empty-cart">
                            <i class="fas fa-shopping-cart"></i>
                            <h4>Your cart is empty</h4>
                            <p>Looks like you haven't added anything to your cart yet.</p>
                            <a href="index.php" class="shop-now-btn">
                                <i class="fas fa-store me-2"></i>Shop Now
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="col-lg-4">
                <div class="cart-summary">
                    <h3 class="summary-header">Order Summary</h3>
                    
                    <div class="summary-item">
                        <span>Shipping</span>
                        <span class="value">TBD</span>
                    </div>
                    
                    <div class="summary-item">
                        <span>Discount</span>
                        <span class="value discount">-0 Rs</span>
                    </div>
                    
                    <div class="summary-item">
                        <span>Tax</span>
                        <span class="value">TBD</span>
                    </div>
                    
                    <div class="summary-item highlight">
                        <span>Delivery charges</span>
                        <span class="value">
                            <span class="strikethrough">40 Rs</span>
                            <span class="discount">0 Rs</span>
                        </span>
                    </div>
                    
                    <div class="free-delivery-note">
                        <i class="fas fa-truck me-2"></i>
                        You qualify for free delivery! Enjoy 4 free-delivery payments.
                    </div>
                    
                    <div class="estimated-total">
                        <span>Estimated Total</span>
                        <span id="estimatedTotal"><?php echo calculateTotal($cart_items); ?> Rs</span>
                    </div>
                    
                    <?php if (!empty($cart_items)) : ?>
                        <a href="payment.php" class="checkout-btn">
                            Proceed to Payment <i class="fas fa-arrow-right"></i>
                        </a>
                    <?php else : ?>
                        <a href="#" class="checkout-btn" style="background: #adb5bd; cursor: not-allowed; box-shadow: none;">
                            Proceed to Payment <i class="fas fa-arrow-right"></i>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        function increment(button) {
            const input = button.previousElementSibling;
            input.value = parseInt(input.value) + 1;
            updateTotal(input);
        }
        
        function decrement(button) {
            const input = button.nextElementSibling;
            if (parseInt(input.value) > 1) {
                input.value = parseInt(input.value) - 1;
                updateTotal(input);
            }
        }
        
        function updateTotal(input) {
            const quantity = parseInt(input.value);
            const price = parseFloat(input.getAttribute('data-price'));
            const totalElement = input.closest('.cart-item-details').querySelector('.totalPrice');
            const total = quantity * price;
            totalElement.textContent = `Total: ${total} Rs`;
            
            // Update estimated total
            updateEstimatedTotal();
        }
        
        function updateEstimatedTotal() {
            let total = 0;
            const quantityInputs = document.querySelectorAll('.quantity-input');
            
            quantityInputs.forEach(input => {
                const quantity = parseInt(input.value);
                const price = parseFloat(input.getAttribute('data-price'));
                total += quantity * price;
            });
            
            document.getElementById('estimatedTotal').textContent = `${total} Rs`;
        }
    </script>


    <script>
    function increment(button) {
        var quantityInput = button.previousElementSibling;
        var quantity = parseInt(quantityInput.value);
        quantityInput.value = quantity + 1;
        updateTotal(quantityInput);
    }

    function decrement(button) {
        var quantityInput = button.nextElementSibling;
        var quantity = parseInt(quantityInput.value);
        if (quantity > 1) {
            quantityInput.value = quantity - 1;
            updateTotal(quantityInput);
        }
    }

    function updateTotal(input) {
        var quantity = parseInt(input.value);
        var pricePerItem = parseFloat(input.getAttribute('data-price'));
        var totalPrice = quantity * pricePerItem;
        var totalPriceElement = input.closest('.cart-item').querySelector('.totalPrice');
        totalPriceElement.innerText = 'Total: ' + totalPrice.toFixed(2) + ' Rs';

        // Update estimated total
        updateEstimatedTotal();
    }

    function updateEstimatedTotal() {
        var total = 0;
        document.querySelectorAll('.totalPrice').forEach(function(totalPriceElement) {
            var totalText = totalPriceElement.innerText;
            var price = parseFloat(totalText.replace('Total: ', '').replace(' Rs', ''));
            total += price;
        });
        document.getElementById('estimatedTotal').innerText = total.toFixed(2);
    }
    </script>
</body>

</html>
