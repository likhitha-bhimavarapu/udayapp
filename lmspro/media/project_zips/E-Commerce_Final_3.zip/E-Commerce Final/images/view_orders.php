<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Payments</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }
        .navbar {
            background-color: #333;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .btn-dashboard {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            display: inline-block;
        }
        .btn-dashboard:hover {
            background-color: #0056b3;
        }
        .container {
            margin: 20px auto;
            padding: 20px;
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            max-width: 1200px;
        }
        .card {
            border: 1px solid #ddd;
            border-radius: 10px;
            margin-bottom: 20px;
            padding: 15px;
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .card h3 {
            margin-top: 0;
            color: #333;
        }
        .card p {
            margin: 5px 0;
            color: #555;
        }
        .cards-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }
        @media (max-width: 600px) {
            .cards-container {
                flex-direction: column;
            }
        }
        .search-container {
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .search-container input {
            padding: 10px;
            width: 80%;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .search-container button {
            padding: 10px 20px;
            border: none;
            background-color: #007bff;
            color: white;
            border-radius: 5px;
            cursor: pointer;
        }
        .search-container button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<div class="navbar">
    <a href="./admin.php" class="btn-dashboard me-auto">Back to Dashboard</a>
</div>

<div class="container">
    <h2>View Payments</h2>
    <div class="search-container">
        <form method="GET" action="">
            <input type="text" name="search" placeholder="Search by Name, Contact Number, or Payment ID" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
            <button type="submit">Search</button>
        </form>
    </div>
    <div class="cards-container">
    <?php
    session_start();

    // Database connection details
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "ecommerceone";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get search query if it exists
    $search_query = isset($_GET['search']) ? $_GET['search'] : '';

    // Query to fetch payment details from the database
    $sql = "SELECT * FROM payments";
    if ($search_query) {
        $sql .= " WHERE name LIKE '%$search_query%' OR contact_number LIKE '%$search_query%' OR id LIKE '%$search_query%'";
    }
    $sql .= " ORDER BY id DESC"; // Assuming 'id' represents the order of the payments

    $result = $conn->query($sql);

    // Check if any rows are returned
    if ($result->num_rows > 0) {
        // Output data of each row in card format
        while ($row = $result->fetch_assoc()) {
            echo "<div class='card'>";
            echo "<h3>Payment ID: " . htmlspecialchars($row["id"]) . "</h3>";
            echo "<p><strong>Name:</strong> " . htmlspecialchars($row["name"]) . "</p>";
            echo "<p><strong>Contact Number:</strong> " . htmlspecialchars($row["contact_number"]) . "</p>";
            echo "<p><strong>Card Number:</strong> **** **** **** " . substr(htmlspecialchars($row["card_number"]), -4) . "</p>";
            echo "<p><strong>Expiry Date:</strong> " . htmlspecialchars($row["expiry_date"]) . "</p>";
            echo "<p><strong>Address:</strong> " . htmlspecialchars($row["address"]) . "</p>";
            echo "<p><strong>Total Price:</strong> ₹" . htmlspecialchars($row["total_price"]) . "</p>";
            echo "<h6 class='card-subtitle mb-2 text-muted'>Cart Details:</h6>";
            $cart_items = explode('; ', $row['cart_details']);
            foreach ($cart_items as $item) {
                list($product_name, $product_details) = explode(' (Quantity: ', $item);
                list($quantity, $price) = explode(', Price: ₹', rtrim($product_details, ')'));
                echo "<div class='card bg-light mb-2'>";
                echo "<div class='card-body p-2'>";
                echo "<p class='card-text mb-0'><strong>" . htmlspecialchars($product_name) . "</strong></p>";
                echo "<p class='card-text mb-0'>Quantity: " . htmlspecialchars($quantity) . "</p>";
                echo "<p class='card-text mb-0'>Price: ₹" . htmlspecialchars($price) . "</p>";
                echo "</div>";
                echo "</div>";
            }
            echo "</div>";
        }
    } else {
        echo "<p>No results found</p>"; // Output if no rows are returned
    }

    $conn->close(); // Close the database connection
    ?>
    </div>
</div>

</body>
</html>
