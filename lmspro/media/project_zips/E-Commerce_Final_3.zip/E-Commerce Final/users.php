<?php
// Start the session at the beginning of the script
session_start();

// Database connection
$db_host = "localhost";
$db_username = "root";
$db_password = "";
$db_name = "ecommerceone";

$conn = new mysqli($db_host, $db_username, $db_password, $db_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$search = "";
if (isset($_GET['search'])) {
    $search = $_GET['search'];
}

// Fetch users from the database using prepared statements
$sql = $conn->prepare("SELECT * FROM register WHERE username LIKE ?");
$search_param = "%$search%";
$sql->bind_param("s", $search_param);
$sql->execute();
$result = $sql->get_result();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>User Management</title>
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- jsPDF -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>
    <style>
        :root {
            --primary-color: #6c5ce7;
            --secondary-color: #a29bfe;
            --accent-color: #fd79a8;
            --light-color: #f8f9fa;
            --dark-color: #343a40;
            --danger-color: #ff7675;
            --success-color: #55efc4;
            --warning-color: #fdcb6e;
        }
        
        body {
            background-color: #f5f6fa;
            font-family: 'Poppins', sans-serif;
        }
        
        .container {
            background-color: white;
            border-radius: 12px;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.08);
            padding: 30px;
            margin-top: 30px;
            margin-bottom: 50px;
            transition: all 0.3s ease;
        }
        
        .container:hover {
            box-shadow: 0 10px 35px rgba(0, 0, 0, 0.12);
        }
        
        .table-responsive {
            overflow-x: auto;
            border-radius: 10px;
            box-shadow: 0 2px 15px rgba(0, 0, 0, 0.05);
        }
        
        .table {
            border-collapse: separate;
            border-spacing: 0;
            width: 100%;
            margin-bottom: 0;
        }
        
        .table th {
            background-color: var(--primary-color);
            color: white;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.75rem;
            letter-spacing: 0.5px;
            padding: 15px;
            border: none;
            position: sticky;
            top: 0;
        }
        
        .table td {
            padding: 15px;
            vertical-align: middle;
            border-top: 1px solid rgba(0, 0, 0, 0.03);
            font-size: 0.9rem;
        }
        
        .table tr:hover {
            background-color: rgba(108, 92, 231, 0.05);
            transform: scale(1.005);
            box-shadow: 0 2px 10px rgba(108, 92, 231, 0.1);
        }
        
        .table tr {
            transition: all 0.2s ease;
        }
        
        .btn-report {
            background-color: var(--warning-color);
            color: var(--dark-color);
            border: none;
            transition: all 0.3s;
            font-weight: 500;
            border-radius: 8px;
            padding: 8px 15px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        
        .btn-report:hover {
            background-color: #e17055;
            color: white;
            transform: translateY(-2px) scale(1.02);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
        }
        
        .btn-delete {
            background-color: var(--danger-color);
            transition: all 0.3s;
            font-weight: 500;
            border-radius: 8px;
            padding: 8px 15px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            color: white;
        }
        
        .btn-delete:hover {
            background-color: #d63031;
            transform: translateY(-2px) scale(1.02);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
        }
        
        .btn-dashboard {
            background-color: var(--secondary-color);
            transition: all 0.3s;
            font-weight: 500;
            border-radius: 8px;
            padding: 8px 15px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            color: white;
        }
        
        .btn-dashboard:hover {
            background-color: #7d6bf2;
            transform: translateY(-2px) scale(1.02);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
        }
        
        .search-box {
            position: relative;
            margin-bottom: 20px;
        }
        
        .search-box .btn-search {
            position: absolute;
            right: 0;
            top: 0;
            height: 100%;
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-top-right-radius: 8px;
            border-bottom-right-radius: 8px;
            transition: all 0.3s;
        }
        
        .search-box .btn-search:hover {
            background-color: #5649d1;
        }
        
        .search-box .form-control {
            border-radius: 8px;
            padding: 10px 15px;
            border: 1px solid rgba(0, 0, 0, 0.1);
            transition: all 0.3s;
        }
        
        .search-box .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(108, 92, 231, 0.25);
        }
        
        .user-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid var(--secondary-color);
            transition: all 0.3s;
        }
        
        .user-avatar:hover {
            transform: scale(1.1);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        .page-title {
            color: var(--primary-color);
            font-weight: 700;
            margin-bottom: 25px;
            position: relative;
            padding-bottom: 15px;
            font-size: 1.8rem;
        }
        
        .page-title:after {
            content: '';
            position: absolute;
            left: 0;
            bottom: 0;
            width: 60px;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-color), var(--accent-color));
            border-radius: 2px;
        }
        
        .action-buttons {
            display: flex;
            gap: 10px;
        }
        
        .no-users {
            text-align: center;
            padding: 40px;
            color: var(--dark-color);
            font-size: 1.1rem;
            background-color: rgba(0, 0, 0, 0.02);
            border-radius: 10px;
        }
        
        .alert {
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            border: none;
        }
        
        .btn-close {
            filter: brightness(0.8);
        }
        
        @media (max-width: 768px) {
            .container {
                padding: 20px;
            }
            
            .page-title {
                font-size: 1.5rem;
            }
            
            .table th, .table td {
                padding: 10px;
                font-size: 0.85rem;
            }
            
            .action-buttons {
                flex-direction: column;
                gap: 5px;
            }
        }
    </style>
</head>

<body>
    <?php include './adminNavbar.php'; ?>
    
    <div class="container">
        <h2 class="page-title">User Management</h2>
        
        <?php
        if (isset($_SESSION['error'])) {
            echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">';
            echo $_SESSION['error'];
            echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
            echo '</div>';
            unset($_SESSION['error']);
        }

        if (isset($_SESSION['message'])) {
            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">';
            echo $_SESSION['message'];
            echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
            echo '</div>';
            unset($_SESSION['message']);
        }
        ?>
        
        <div class="row mb-4">
            <div class="col-md-6">
                <form class="search-box" method="GET">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search by username..." name="search" value="<?php echo htmlspecialchars($search); ?>">
                        <button class="btn btn-search" type="submit"><i class="fas fa-search"></i></button>
                    </div>
                </form>
            </div>
            <div class="col-md-6 text-end">
                <button id="generatePdf" class="btn btn-report me-2">
                    <i class="fas fa-file-pdf me-1"></i> Generate PDF Report
                </button>
                <a href="admin_dashboard.php" class="btn btn-dashboard">
                    <i class="fas fa-arrow-left me-1"></i> Back to Dashboard
                </a>
            </div>
        </div>
        
        <div class="table-responsive">
            <table class="table" id="userTable">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Mobile</th>
                        <th>Avatar</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row["id"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["username"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["email"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["mobile"]) . "</td>";
                            echo "<td>";
                            if (!empty($row['Avatar'])) {
                                echo '<img src="./uploaded_files/' . htmlspecialchars($row['Avatar']) . '" class="user-avatar" alt="User Avatar">';
                            } else {
                                echo '<i class="fas fa-user-circle fa-2x text-secondary"></i>';
                            }
                            echo "</td>";
                            echo "<td class='action-buttons'>";
                            echo '<button class="btn btn-sm btn-delete" onclick="confirmDelete(' . htmlspecialchars($row["id"]) . ')">';
                            echo '<i class="fas fa-trash me-1"></i> Delete';
                            echo '</button>';
                            echo "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo '<tr><td colspan="6" class="no-users">No users found</td></tr>';
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <script type="text/javascript">
        // Initialize tooltips
        document.addEventListener('DOMContentLoaded', function() {
            var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });
        });

        function confirmDelete(id) {
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!',
                background: '#ffffff',
                backdrop: `
                    rgba(0,0,0,0.4)
                    url("/images/nyan-cat.gif")
                    left top
                    no-repeat
                `
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = "delete_user.php?id=" + id;
                }
            });
        }

        // PDF Generation with jsPDF
        document.getElementById('generatePdf').addEventListener('click', function() {
            // Initialize jsPDF
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();
            
            // Add title
            doc.setFontSize(18);
            doc.setTextColor(108, 92, 231);
            doc.text('User Management Report', 105, 15, { align: 'center' });
            
            // Add date
            doc.setFontSize(10);
            doc.setTextColor(100, 100, 100);
            doc.text('Generated on: ' + new Date().toLocaleString(), 105, 22, { align: 'center' });
            
            // Add line separator
            doc.setDrawColor(108, 92, 231);
            doc.setLineWidth(0.5);
            doc.line(20, 25, 190, 25);
            
            // Prepare table data
            const table = document.getElementById('userTable');
            const headers = [];
            const rows = [];
            
            // Get headers
            table.querySelectorAll('thead th').forEach(th => {
                if (th.textContent !== 'Actions') {
                    headers.push({
                        title: th.textContent,
                        dataKey: th.textContent.toLowerCase()
                    });
                }
            });
            
            // Get rows
            table.querySelectorAll('tbody tr').forEach(tr => {
                const row = {};
                const cells = tr.querySelectorAll('td');
                
                headers.forEach((header, index) => {
                    if (index < cells.length) {
                        // Handle avatar column differently
                        if (header.dataKey === 'avatar') {
                            const img = cells[index].querySelector('img');
                            row[header.dataKey] = img ? img.src.includes('uploaded_files') ? 'Has Avatar' : 'Default Icon' : 'No Avatar';
                        } else {
                            row[header.dataKey] = cells[index].textContent.trim();
                        }
                    }
                });
                
                rows.push(row);
            });
            
            // Add table to PDF
            doc.autoTable({
                head: [headers.map(header => header.title)],
                body: rows.map(row => headers.map(header => row[header.dataKey])),
                startY: 30,
                theme: 'grid',
                headStyles: {
                    fillColor: [108, 92, 231],
                    textColor: 255,
                    fontStyle: 'bold'
                },
                alternateRowStyles: {
                    fillColor: [248, 249, 250]
                },
                styles: {
                    cellPadding: 5,
                    fontSize: 10,
                    valign: 'middle'
                },
                columnStyles: {
                    id: { cellWidth: 15 },
                    username: { cellWidth: 30 },
                    email: { cellWidth: 50 },
                    mobile: { cellWidth: 30 },
                    avatar: { cellWidth: 25 }
                },
                margin: { top: 30 }
            });
            
            // Add footer
            const pageCount = doc.internal.getNumberOfPages();
            for(let i = 1; i <= pageCount; i++) {
                doc.setPage(i);
                doc.setFontSize(10);
                doc.setTextColor(150);
                doc.text('Page ' + i + ' of ' + pageCount, 105, 285, { align: 'center' });
            }
            
            // Save the PDF
            doc.save('user_report_' + new Date().toISOString().slice(0, 10) + '.pdf');
            
            // Show success message
            Swal.fire({
                title: 'Report Generated!',
                text: 'The PDF report has been downloaded.',
                icon: 'success',
                confirmButtonColor: '#6c5ce7',
                timer: 2000,
                timerProgressBar: true
            });
        });
    </script>

    <!-- SweetAlert2 for beautiful alerts -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <?php include './footer.php'; ?>
</body>

</html>