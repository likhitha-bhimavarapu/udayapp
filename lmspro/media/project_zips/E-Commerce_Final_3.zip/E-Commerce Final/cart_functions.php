<?php
session_start();

// Initialize cart in session if not already set
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

function addToCart($item) {
    $cart = $_SESSION['cart'];
    $itemId = $item['id'];
    
    // Check if the item already exists in the cart
    $existingItemIndex = -1;
    foreach ($cart as $index => $cartItem) {
        if ($cartItem['id'] == $itemId) {
            $existingItemIndex = $index;
            break;
        }
    }
    
    if ($existingItemIndex !== -1) {
        // Increment quantity if item already in cart
        $cart[$existingItemIndex]['quantity']++;
    } else {
        // Add new item to cart with quantity 1
        $item['quantity'] = 1;
        $cart[] = $item;
    }
    
    $_SESSION['cart'] = $cart;
    calculateTotalAmount(); // Call calculate total amount
}

function calculateTotalAmount() {
    $cart = $_SESSION['cart'];
    if (empty($cart)) {
        return 0;
    }
    
    $total = 0;
    foreach ($cart as $item) {
        if (is_numeric($item['rate']) && is_numeric($item['quantity'])) {
            $total += $item['rate'] * $item['quantity'];
        } else {
            error_log("Invalid rate or quantity: " . print_r($item, true));
        }
    }
    
    echo "Total Amount: $total";
    return $total;
}

function removeFromCart($item) {
    $cart = $_SESSION['cart'];
    foreach ($cart as $key => $cartItem) {
        if ($cartItem['id'] == $item['id']) {
            unset($cart[$key]);
            break;
        }
    }
    // Re-index array to avoid gaps
    $_SESSION['cart'] = array_values($cart);
}

function getCartItems() {
    return isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
}
?>
