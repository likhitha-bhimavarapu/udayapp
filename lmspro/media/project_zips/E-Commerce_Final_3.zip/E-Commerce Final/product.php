<?php
// Database credentials
$servername = "localhost";
$username = "root";
$password = "";
$database = "ecommerceOne";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

echo "Connected successfully";
// Get product details based on product ID
if (isset($_GET['id'])) {
    $product_id = htmlspecialchars($_GET['id']);
    // Fetch product details from the database
    // Replace this with your actual database query
    $connection = mysqli_connect("localhost", "username", "password", "database");
    $query = "SELECT * FROM products WHERE id = '$product_id'";
    $result = mysqli_query($connection, $query);
    $product = mysqli_fetch_assoc($result);
    mysqli_close($connection);
}
?>
<!-- Display product details -->
<?php if (isset($product)) : ?>
    <?php  echo $product['image'];?>
    <h1><?php echo $product['name']; ?></h1>
    <p><?php echo $product['description']; ?></p>
    <p>Price: <?php echo $product['price']; ?></p>
    <!-- Add more product details here -->
<?php else : ?>
    <p>Product not found.</p>
<?php endif; ?>
<!--  -->