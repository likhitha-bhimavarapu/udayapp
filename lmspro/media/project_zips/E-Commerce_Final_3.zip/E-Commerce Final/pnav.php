<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Commerce Store</title>
    <!-- Bootstrap link -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --primary: #4361ee;
            --secondary: #ef476f;
            --accent: #06d6a0;
            --warning: #ffd166;
            --info: #118ab2;
            --light: #f8f9fa;
            --dark: #212529;
            --gray: #6c757d;
            --gray-light: #e9ecef;
            --gray-dark: #343a40;
            --transition: all 0.3s ease;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f9fafb;
            min-height: 100vh;
            overflow-x: hidden;
        }
        
        /* Header & Navbar Styles */
        header {
            background: linear-gradient(135deg, #ffffff 0%, #f5f7ff 100%);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        
        .navbar {
            padding: 15px 0;
            transition: var(--transition);
        }
        
        .navbar-brand {
            font-weight: 700;
            font-size: 1.8rem;
            color: var(--dark);
            position: relative;
            transition: var(--transition);
        }
        
        .navbar-brand:hover {
            transform: translateY(-2px);
        }
        
        .brand-highlight {
            font-size: 2.5rem;
            color: var(--secondary);
            font-weight: 800;
            position: relative;
            display: inline-block;
            transition: var(--transition);
        }
        
        .brand-highlight::after {
            content: '';
            position: absolute;
            bottom: 5px;
            left: 0;
            width: 100%;
            height: 4px;
            background: linear-gradient(90deg, var(--secondary) 0%, rgba(239, 71, 111, 0.2) 100%);
            border-radius: 2px;
        }
        
        .navbar-toggler {
            border: none;
            padding: 0;
            font-size: 1.5rem;
            color: var(--primary);
            transition: var(--transition);
        }
        
        .navbar-toggler:focus {
            box-shadow: none;
            outline: none;
        }
        
        .navbar-toggler:hover {
            color: var(--secondary);
            transform: rotate(90deg);
        }
        
        .navbar-nav {
            align-items: center;
        }
        
        .nav-item {
            position: relative;
            margin: 0 5px;
        }
        
        .nav-link {
            font-weight: 500;
            font-size: 0.95rem;
            color: var(--dark) !important;
            padding: 10px 15px !important;
            border-radius: 8px;
            transition: var(--transition);
            position: relative;
        }
        
        .nav-link::after {
            content: '';
            position: absolute;
            bottom: 5px;
            left: 50%;
            width: 0;
            height: 2px;
            background: var(--primary);
            transition: var(--transition);
            transform: translateX(-50%);
            opacity: 0;
        }
        
        .nav-link:hover {
            color: var(--primary) !important;
            background-color: rgba(67, 97, 238, 0.05);
            transform: translateY(-2px);
        }
        
        .nav-link:hover::after {
            width: 60%;
            opacity: 1;
        }
        
        .nav-link.active {
            color: var(--primary) !important;
            font-weight: 600;
        }
        
        .nav-link.active::after {
            width: 60%;
            opacity: 1;
        }
        
        .logout-btn {
            background: linear-gradient(135deg, var(--secondary) 0%, #e63e65 100%);
            color: white !important;
            border: none;
            padding: 10px 20px !important;
            border-radius: 8px;
            font-weight: 600;
            font-size: 0.9rem;
            transition: var(--transition);
            box-shadow: 0 4px 10px rgba(239, 71, 111, 0.2);
            position: relative;
            overflow: hidden;
        }
        
        .logout-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: 0.5s;
        }
        
        .logout-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 15px rgba(239, 71, 111, 0.3);
        }
        
        .logout-btn:hover::before {
            left: 100%;
        }
        
        /* Icon styles */
        .nav-icon {
            margin-right: 6px;
            font-size: 1rem;
        }
        
        /* Badge styles */
        .cart-badge {
            position: absolute;
            top: 0;
            right: 5px;
            background-color: var(--secondary);
            color: white;
            font-size: 0.7rem;
            width: 18px;
            height: 18px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            transform: translateY(-5px);
        }
        
        /* Search form */
        .search-form {
            position: relative;
            margin-left: 15px;
        }
        
        .search-input {
            border: 1px solid #e1e5eb;
            border-radius: 20px;
            padding: 8px 15px;
            padding-right: 40px;
            font-size: 0.9rem;
            transition: var(--transition);
            width: 180px;
            background-color: rgba(255, 255, 255, 0.8);
        }
        
        .search-input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.1);
            width: 220px;
        }
        
        .search-btn {
            position: absolute;
            right: 5px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: var(--gray);
            font-size: 0.9rem;
            cursor: pointer;
            transition: var(--transition);
            padding: 5px 10px;
        }
        
        .search-btn:hover {
            color: var(--primary);
        }
        
        /* Responsive styles */
        @media (max-width: 991px) {
            .navbar-collapse {
                background-color: white;
                border-radius: 10px;
                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
                padding: 20px;
                margin-top: 15px;
            }
            
            .nav-item {
                margin: 5px 0;
            }
            
            .nav-link {
                padding: 12px 20px !important;
            }
            
            .logout-btn {
                margin-top: 10px;
                width: 100%;
                text-align: center;
            }
            
            .search-form {
                margin: 15px 0;
                width: 100%;
            }
            
            .search-input {
                width: 100%;
            }
        }
        
        /* Animation */
        @keyframes fadeInDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .animate-fade-in-down {
            animation: fadeInDown 0.5s ease forwards;
        }
    </style>
</head>

<body>
    <header class="animate-fade-in-down">
        <nav class="navbar navbar-expand-lg">
            <div class="container">
                <a class="navbar-brand" href="./profile.php">
                    <span class="brand-highlight">E</span>-commerce
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="./profile.php">
                                <i class="fas fa-home nav-icon"></i>Home
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./mycart.php">
                                <i class="fas fa-shopping-cart nav-icon"></i>Cart
                              
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./orderH.php">
                                <i class="fas fa-box nav-icon"></i>Orders
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./contactUs.php">
                                <i class="fas fa-envelope nav-icon"></i>Contact
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./about.php">
                                <i class="fas fa-info-circle nav-icon"></i>About
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./myprofile.php">
                                <i class="fas fa-user nav-icon"></i>Profile
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="logout-btn" href="./logout.php">
                                <i class="fas fa-sign-out-alt me-1"></i>Logout
                            </a>
                        </li>
                    </ul>
                    
                  
                </div>
            </div>
        </nav>
    </header>
    
    <!-- Main content would go here -->
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    
    <script>
        // Add scroll effect to navbar
        window.addEventListener('scroll', function() {
            const header = document.querySelector('header');
            if (window.scrollY > 50) {
                header.style.boxShadow = '0 4px 20px rgba(0, 0, 0, 0.1)';
            } else {
                header.style.boxShadow = '0 4px 20px rgba(0, 0, 0, 0.05)';
            }
        });
        
        // Set active nav item based on current page
        document.addEventListener('DOMContentLoaded', function() {
            const currentLocation = window.location.pathname;
            const navLinks = document.querySelectorAll('.nav-link');
            
            navLinks.forEach(link => {
                const linkPath = link.getAttribute('href');
                if (currentLocation.includes(linkPath) && linkPath !== './profile.php') {
                    link.classList.add('active');
                    document.querySelector('.nav-link[href="./profile.php"]').classList.remove('active');
                }
            });
        });
    </script>
</body>

</html>