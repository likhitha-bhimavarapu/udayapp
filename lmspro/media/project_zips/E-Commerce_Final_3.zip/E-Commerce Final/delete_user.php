<?php
session_start();
include 'db_config.php';

// Check if the user ID is provided
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // SQL query to delete the user
    $sql = "DELETE FROM register WHERE id = '$id'";
    if ($conn->query($sql) === TRUE) {
        $_SESSION['message'] = "User deleted successfully.";
    } else {
        $_SESSION['error'] = "Error: " . $conn->error;
    }
}

header("Location: users.php");
exit();
?>
