<?php
session_start();

// Include database configuration file
include 'db_config.php';

// Initialize the shopping cart if not already initialized
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Add to cart functionality
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['product_id'])) {
    $product_id = $_POST['product_id'];
    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];
    $product_image = $_POST['product_image'];
    // Add product to the session cart array
    $_SESSION['cart'][] = [
        'id' => $product_id,
        'name' => $product_name,
        'price' => $product_price,
        'image' => $product_image,
        'quantity' => 1
    ];
    
    // Return a JSON response
    echo json_encode(['status' => 'success', 'message' => 'Product added to cart successfully!']);
    exit();
}

// Fetch products from the database
$sql = "SELECT * FROM m"; // Replace 'rice' with your actual table name
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Page</title>
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</head>
<style>
    .one h2 a {
        text-decoration: none;
        padding: 20px;
    }
    .one h2 a:hover {
        transition: 0.5s;
        border-radius: 40px;
        background: skyblue;
    }
</style>
<body>
    <?php include './pnav.php' ?>
    <div class="container">
        <div class="row">
            <div class="col-md-6 offset-md-3">
            <h2 align="center" class='text-danger'>WELCOME <?php echo strtoupper($_SESSION['username']); ?></h2>
            </div>
        </div>
        <div class="container mt-5">
            <h2 class="mb-4 text-danger">Eggs, Meat & Fish Products</h2>
            <div class="row">
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo '<div class="col-md-4 mb-4">';
                        echo '<div class="card" style="height:500px">';
                        echo '<img style="height: 200px; width: auto; margin: 0 auto;" src="' . $row['image'] . '" class="card-img-top pt-3" alt="' . $row['name'] . '">';
                        echo '<div class="card-body">';
                        echo '<h5 class="card-title">' . $row['name'] . '</h5>';
                        echo '<p class="card-text" style="height:50px;font-size:13px">' . $row['description'] . '</p>';
                        echo '<h5 class="card-text pt-3">Price:₹ ' . $row['price'] . '</h5>';
                        echo '<form class="add-to-cart-form" method="post" action="">';
                        echo '<input type="hidden" name="product_id" value="' . $row['id'] . '">';
                        echo '<input type="hidden" name="product_name" value="' . $row['name'] . '">';
                        echo '<input type="hidden" name="product_price" value="' . $row['price'] . '">';
                        echo '<input type="hidden" name="product_image" value="' . $row['image'] . '">';
                        echo '<button type="button" class="btn btn-primary buy-button">Buy</button>&emsp;&emsp;<br><br>';
                        echo '<button type="button" class="btn btn-danger add-to-cart-button">Add to Cart</button>&emsp;&emsp;';
                        echo '</form><br>';
                        echo '</div>';
                        echo '</div>';
                        echo '</div>';
                    }
                } else {
                    echo '<div class="col-md-12">';
                    echo '<p>No products found.</p>';
                    echo '</div>';
                }
                ?>
            </div>
        </div>
    </div>

    <?php include './footer.php' ?>

    <script>
        document.querySelectorAll('.add-to-cart-button').forEach(function(button) {
            button.addEventListener('click', function(event) {
                var form = event.target.closest('form');
                var formData = new FormData(form);
                
                fetch('', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        alert(data.message);
                    } else {
                        alert('An error occurred. Please try again.');
                    }
                })
                .catch(error => console.error('Error:', error));
            });
        });
    </script>
</body>
</html>
