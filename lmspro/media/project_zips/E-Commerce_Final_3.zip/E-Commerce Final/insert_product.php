<?php
// Check if form data is present
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database configuration
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "ecommerceone";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get form data
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $category = $_POST['category'];

    // Handle file upload
    $target_dir = "uploads/";
    $original_file_name = basename($_FILES["image"]["name"]);
    $imageFileType = strtolower(pathinfo($original_file_name, PATHINFO_EXTENSION));
    $unique_file_name = uniqid() . '.' . $imageFileType;
    $target_file = $target_dir . $unique_file_name;
    $uploadOk = 1;

    // Check if uploads directory exists, if not, create it
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    // Check if image file is an actual image or fake image
    $check = getimagesize($_FILES["image"]["tmp_name"]);
    if ($check !== false) {
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }

    // Check file size
    if ($_FILES["image"]["size"] > 500000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }

    // Allow certain file formats
    if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }

    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
    } else {
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            // Start a transaction
            $conn->begin_transaction();

            try {
                // Insert into products table
                $stmt = $conn->prepare("INSERT INTO product (name, description, price, image) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("ssds", $name, $description, $price, $target_file);
                if (!$stmt->execute()) {
                    throw new Exception($stmt->error);
                }
                $stmt->close();

                // Get the last inserted product ID
                $product_id = $conn->insert_id;

                // Determine which table to insert based on the category
                switch ($category) {
                    case 'f':
                        $stmt = $conn->prepare("INSERT INTO f (product_id, name, description, price, image) VALUES (?, ?, ?, ?, ?)");
                        $stmt->bind_param("issds", $product_id, $name, $description, $price, $target_file);
                        break;
                    case 'm':
                        $stmt = $conn->prepare("INSERT INTO m (product_id, name, description, price, image) VALUES (?, ?, ?, ?, ?)");
                        $stmt->bind_param("issds", $product_id, $name, $description, $price, $target_file);
                        break;
                    case 'rice':
                        $stmt = $conn->prepare("INSERT INTO rice (product_id, name, description, price, image) VALUES (?, ?, ?, ?, ?)");
                        $stmt->bind_param("issds", $product_id, $name, $description, $price, $target_file);
                        break;
                    default:
                        throw new Exception("Invalid category");
                }

                // Execute the statement
                if (!$stmt->execute()) {
                    throw new Exception($stmt->error);
                }
                $stmt->close();

                // Commit transaction
                // Commit transaction
                $conn->commit();
                echo "New product added successfully";

                // JavaScript for alert and redirect
                echo '<script>';
                echo 'alert("New product added successfully");';
                echo 'window.location.href = "addProduct.php";';
                echo '</script>';
            } catch (Exception $e) {
                // Rollback transaction
                $conn->rollback();
                echo "Error: " . $e->getMessage();
            }

            // Close connection
            $conn->close();
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }
} else {
    echo "No data was submitted.";
}
