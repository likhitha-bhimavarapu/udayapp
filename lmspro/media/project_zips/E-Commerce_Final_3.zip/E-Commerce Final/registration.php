<?php
session_start();

// Check if the form is submitted via POST method
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection parameters
    $db_host = "localhost";
    $db_username = "root";
    $db_password = "";
    $db_name = "ecommerceone";

    // Establish database connection
    $conn = new mysqli($db_host, $db_username, $db_password, $db_name);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Function to safely handle input data
    function sanitize_input($data)
    {
        global $conn;
        return mysqli_real_escape_string($conn, htmlspecialchars($data));
    }

    // Get form data and sanitize
    $username = sanitize_input($_POST["username"]);
    $email = sanitize_input($_POST["email"]);
    $password = sanitize_input($_POST["password"]);
    $cpassword = sanitize_input($_POST["cpassword"]);
    $mobile = sanitize_input($_POST["mobile"]);

    // Handle file upload
    $Avatar = '';
    if (isset($_FILES['Avatar']) && $_FILES['Avatar']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['Avatar']['tmp_name'];
        $fileName = $_FILES['Avatar']['name'];
        $fileSize = $_FILES['Avatar']['size'];
        $fileType = $_FILES['Avatar']['type'];
        $fileNameCmps = explode(".", $fileName);
        $fileExtension = strtolower(end($fileNameCmps));

        // Sanitize file name and move it to the upload directory
        $newFileName = md5(time() . $fileName) . '.' . $fileExtension;
        $uploadFileDir = './uploaded_files/';

        // Check if directory exists, if not create it
        if (!is_dir($uploadFileDir)) {
            mkdir($uploadFileDir, 0777, true);
        }
        $dest_path = $uploadFileDir . $newFileName;

        // Move uploaded file to destination
        if (move_uploaded_file($fileTmpPath, $dest_path)) {
            $Avatar = $newFileName;
        } else {
            echo 'Error: There was some error moving the file to upload directory. Please make sure the upload directory is writable by web server.';
        }
    }

    // Insert user data into database
    $sql = "INSERT INTO register (username, email, password, cpassword, mobile, Avatar) VALUES ('$username', '$email', '$password', '$cpassword', '$mobile', '$Avatar')";

    if ($conn->query($sql) === TRUE) {
        // Registration successful, set session variable for alert
        $_SESSION['register_success'] = true;
        $_SESSION['register_message'] = "Register success!";
        echo "<script>
            alert('Register success!');
            window.location.href = 'login.php';
            </script>";
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | E-commerce</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --primary-color: #ff4757;
            --secondary-color: #2f3542;
            --accent-color: #70a1ff;
            --light-color: #f1f2f6;
            --dark-color: #2f3542;
            --success-color: #2ed573;
            --warning-color: #ffa502;
            --danger-color: #ff4757;
            --info-color: #70a1ff;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        .register-container {
            padding: 40px 0;
            flex: 1;
        }
        
        .register-title {
            font-weight: 700;
            color: var(--primary-color);
            margin-bottom: 30px;
            text-align: center;
            position: relative;
            display: inline-block;
            padding-bottom: 10px;
        }
        
        .register-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-color), var(--accent-color));
            border-radius: 2px;
        }
        
        .register-card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            transition: all 0.3s ease;
            background: white;
            max-width: 500px;
            margin: 0 auto;
        }
        
        .register-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
        }
        
        .card-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, #ff6b81 100%);
            color: white;
            text-align: center;
            padding: 25px 20px;
            border-bottom: none;
        }
        
        .card-header h4 {
            margin: 0;
            font-weight: 600;
        }
        
        .card-body {
            padding: 30px;
        }
        
        .form-group {
            margin-bottom: 20px;
            position: relative;
        }
        
        .form-label {
            font-weight: 500;
            color: var(--secondary-color);
            margin-bottom: 8px;
            font-size: 0.9rem;
            display: block;
        }
        
        .form-control {
            border: 2px solid #e1e5eb;
            border-radius: 8px;
            padding: 12px 15px;
            font-size: 0.95rem;
            transition: all 0.3s ease;
        }
        
        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(255, 71, 87, 0.15);
        }
        
        .form-control-file {
            border: 2px dashed #e1e5eb;
            border-radius: 8px;
            padding: 12px;
            width: 100%;
            transition: all 0.3s ease;
            background-color: #f8f9fa;
            cursor: pointer;
        }
        
        .form-control-file:hover {
            border-color: var(--primary-color);
            background-color: #fff5f7;
        }
        
        .input-icon {
            position: absolute;
            top: 42px;
            right: 15px;
            color: #adb5bd;
        }
        
        .register-btn {
            background: linear-gradient(135deg, var(--primary-color) 0%, #ff6b81 100%);
            border: none;
            border-radius: 50px;
            padding: 12px 30px;
            font-weight: 600;
            font-size: 1rem;
            color: white;
            width: 100%;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(255, 71, 87, 0.3);
            margin-top: 10px;
        }
        
        .register-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(255, 71, 87, 0.4);
            background: linear-gradient(135deg, #ff6b81 0%, var(--primary-color) 100%);
        }
        
        .register-btn:active {
            transform: translateY(0);
        }
        
        .login-link {
            text-align: center;
            margin-top: 20px;
            font-size: 0.9rem;
            color: var(--secondary-color);
        }
        
        .login-link a {
            color: var(--primary-color);
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .login-link a:hover {
            text-decoration: underline;
        }
        
        .password-toggle {
            position: absolute;
            top: 42px;
            right: 15px;
            color: #adb5bd;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .password-toggle:hover {
            color: var(--primary-color);
        }
        
        .form-divider {
            display: flex;
            align-items: center;
            margin: 20px 0;
        }
        
        .form-divider::before,
        .form-divider::after {
            content: '';
            flex: 1;
            height: 1px;
            background-color: #e1e5eb;
        }
        
        .form-divider span {
            padding: 0 15px;
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        .social-login {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .social-btn {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
            color: white;
            transition: all 0.3s ease;
        }
        
        .social-btn.facebook {
            background-color: #3b5998;
        }
        
        .social-btn.google {
            background-color: #db4437;
        }
        
        .social-btn.twitter {
            background-color: #1da1f2;
        }
        
        .social-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        /* Responsive adjustments */
        @media (max-width: 768px) {
            .register-container {
                padding: 20px 0;
            }
            
            .card-body {
                padding: 20px;
            }
        }
        
        /* Animation for form elements */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .form-group {
            animation: fadeInUp 0.5s ease forwards;
            opacity: 0;
        }
        
        .form-group:nth-child(1) { animation-delay: 0.1s; }
        .form-group:nth-child(2) { animation-delay: 0.2s; }
        .form-group:nth-child(3) { animation-delay: 0.3s; }
        .form-group:nth-child(4) { animation-delay: 0.4s; }
        .form-group:nth-child(5) { animation-delay: 0.5s; }
        .form-group:nth-child(6) { animation-delay: 0.6s; }
        
        .register-btn {
            animation: fadeInUp 0.5s ease forwards;
            animation-delay: 0.7s;
            opacity: 0;
        }
        
        .login-link {
            animation: fadeInUp 0.5s ease forwards;
            animation-delay: 0.8s;
            opacity: 0;
        }
    </style>
</head>

<body>
    <?php include './navbar.php'; ?>

    <div class="container register-container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <h2 class="register-title">Create Your Account</h2>
                
                <div class="register-card">
                    <div class="card-header">
                        <h4><i class="fas fa-user-plus me-2"></i>Sign Up</h4>
                    </div>
                    
                    <div class="card-body p-5">
                        <form action="" method="post" enctype="multipart/form-data">
                            <div class="form-group">
                                <label for="username" class="form-label">Username</label>
                                <input type="text" id="username" class="form-control" name="username" placeholder="Choose a username" required>
                                <i class="fas fa-user input-icon"></i>
                            </div>
                            
                            <div class="form-group">
                                <label for="email" class="form-label">Email Address</label>
                                <input type="email" id="email" class="form-control" name="email" placeholder="Enter your email" required>
                                <i class="fas fa-envelope input-icon"></i>
                            </div>
                            
                            <div class="form-group">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" id="password" class="form-control" name="password" placeholder="Create a strong password" required>
                                <i class="fas fa-eye password-toggle" onclick="togglePassword('password')"></i>
                            </div>
                            
                            <div class="form-group">
                                <label for="cpassword" class="form-label">Confirm Password</label>
                                <input type="password" id="cpassword" class="form-control" name="cpassword" placeholder="Confirm your password" required>
                                <i class="fas fa-eye password-toggle" onclick="togglePassword('cpassword')"></i>
                            </div>
                            
                            <div class="form-group">
                                <label for="mobile" class="form-label">Phone Number</label>
                                <input type="text" id="mobile" class="form-control" name="mobile" placeholder="Enter your phone number" required>
                                <i class="fas fa-phone input-icon"></i>
                            </div>
                            
                            <div class="form-group">
                                <label for="Avatar" class="form-label">Profile Image</label>
                                <input type="file" id="Avatar" class="form-control-file" name="Avatar" required>
                            </div>
                            
                            <button type="submit" class="register-btn">
                                <i class="fas fa-user-plus me-2"></i>Create Account
                            </button>
                        </form>
                        
                        <div class="login-link">
                            Already have an account? <a href="./login.php">Sign In</a>
                        </div>
                        
                        <div class="form-divider">
                            <span>or sign up with</span>
                        </div>
                        
                        <div class="social-login">
                            <a href="#" class="social-btn facebook">
                                <i class="fab fa-facebook-f"></i>
                            </a>
                            <a href="#" class="social-btn google">
                                <i class="fab fa-google"></i>
                            </a>
                            <a href="#" class="social-btn twitter">
                                <i class="fab fa-twitter"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Toggle password visibility
        function togglePassword(id) {
            const passwordInput = document.getElementById(id);
            const icon = passwordInput.nextElementSibling;
            
            if (passwordInput.type === "password") {
                passwordInput.type = "text";
                icon.classList.remove("fa-eye");
                icon.classList.add("fa-eye-slash");
            } else {
                passwordInput.type = "password";
                icon.classList.remove("fa-eye-slash");
                icon.classList.add("fa-eye");
            }
        }
    </script>
</body>

</html>