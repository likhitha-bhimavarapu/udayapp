<?php
session_start();

// Check if the user is logged in as admin

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $message = $_POST['message'];

    // Establish database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "college";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check for connection errors
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and execute SQL query
    $stmt = $conn->prepare("INSERT INTO notifications (title, message, created_at) VALUES (?, ?, NOW())");

    // Check for prepare errors
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    // Bind parameters
    $stmt->bind_param("ss", $title, $message);

    // Execute query
    if ($stmt->execute()) {
        $success_message = "Notification sent successfully!";
    } else {
        $error_message = "Error sending notification: " . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Send Notification</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f9fc;
            margin: 0;
            padding: 0;
            font-size: 14px;
        }

        #header {
            background: linear-gradient(45deg, #ff512f, #ff512f);
            color: white;
            padding: 20px;
            text-align: center;
        }

        #header h1 {
            font-size: 2.5rem;
            font-weight: bold;
            margin-bottom: 10px;
            color: white;
            
        }

        #header h6 {
            font-size: 1rem;
            margin-bottom: 5px;
            color: white;
        }

        #header marquee {
            font-size: 1.2rem;
            font-weight: bold;
        }

        .container {
           
            border-radius: 10px;
            padding: 30px;
            max-width: 800px;
            margin: 30px auto;
        }

        h2 {
            color: #343a40;
            font-size: 2rem;
            text-align: center;
            margin-bottom: 20px;
        }

        p {
            font-size: 1.2rem;
            text-align: center;
            margin-bottom: 30px;
        }

        .btn {
            margin: 10px;
            padding: 10px 20px;
            font-size: 1rem;
            font-weight: bold;
            border-radius: 8px;
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .btn:hover {
            transform: scale(1.1);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
        }

        .btn-info {
            background: linear-gradient(45deg, #5b86e5,rgb(90, 112, 159));
            border: none;
            color: white;
        }

        .btn-info:hover {
            background: linear-gradient(45deg, #5b86e5,rgb(90, 112, 159));
        }

        .btn-success {
            background: linear-gradient(45deg,#5b86e5,rgb(90, 112, 159));
            border: none;
            color: white;
        }
        .btn-success:hover {
            background: linear-gradient(45deg, #5b86e5,rgb(90, 112, 159));
        }

        .btn-danger {
            background: linear-gradient(45deg, #e63946, #ff6f61);
            border: none;
            color: white;
        }

        .btn-danger:hover {
            background: linear-gradient(45deg, #ff6f61, #e63946);
        }
        table {

        width: 100%;
        border-collapse: collapse;
        margin: 20px 0;
        font-size: 14px;
        text-align: left;
        background-color: #f9f9f9;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    table th, table td {
        border: 1px solid #ddd;
        padding: 12px 15px;
    }

    table th {
        background-color: #4CAF50;
        color: white;
        text-align: center;
    }

    table tr:nth-child(even) {
        background-color: #f2f2f2;
    }

    table tr:hover {
        background-color: #f1f1f1;
        cursor: pointer;
    }

    table td form {
        display: inline-block;
        margin: 0;
    }

    table td button {
        background-color: #4CAF50;
        color: white;
        border: none;
        padding: 8px 12px;
        font-size: 14px;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    table td button[name="reject"] {
        background-color: #f44336;
    }

    table td button:hover {
        opacity: 0.9;
    }
    </style>
<body>
<div class="col-8 bg-light" id="header" style="width: 100%;">
        <h1 class="text-white">MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS</h1>
        <h6>Catering to the Educational Needs of Gifted Rural Youth of Andhra Pradesh (Established by the Govt. of Andhra Pradesh and recognized as per Section 2(f) of UGC Act, 1956)</h6>
        <h3>SAFETY AND SECURITY PORTAL</h3>
        <marquee behavior="" direction="">
            <h3 class="text-white">MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS</h3>
        </marquee>
    </div>
    <div class="container mt-5" >
    <a href="./admin_dashboard.php" style="font-size: 14px;" class="btn btn-info">Home</a>
   <a href="user_details.php" style="font-size: 14px;" class="btn btn-info">User Details</a>
   <a href="complaint.php" style="font-size: 14px;" class="btn btn-info">complaints</a>
        <a href="Approval.php" style="font-size: 14px;" class="btn btn-info">Out Approval/Reject</a>
        <a href="admin_studentin.php" style="font-size: 14px;" class="btn btn-info">In</a>
        <a href="information.php" style="font-size: 14px;" class="btn btn-success fw-bold" role="button">information</a>
        <a href="admin_logout.php" style="font-size: 14px;" class="btn btn-danger">Logout</a>
    </div>
   </div>
    <div class="container mt-5">
        <h1>Send Notification to All Students</h1>
        <?php
        if (isset($success_message)) {
            echo "<div class='alert alert-success'>$success_message</div>";
        }
        if (isset($error_message)) {
            echo "<div class='alert alert-danger'>$error_message</div>";
        }
        ?>
        <form method="post" action="information.php">
            <div class="mb-3">
                <label for="title" class="form-label">Title</label>
                <input type="text" class="form-control" id="title" name="title" required>
            </div>
            <div class="mb-3">
                <label for="message" class="form-label">Message</label>
                <textarea class="form-control" id="message" name="message" rows="4" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Send Notification</button>
        </form>
    </div>
    <br>
    <br>
    <br>
    <br>
</body>
</html>
