<?php
session_start();

// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "college";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['name']) && isset($_POST['idno']) && isset($_POST['branch']) && isset($_POST['date']) && isset($_POST['reason'])) {
    // Check if the user is logged in
    if (!isset($_SESSION['user_id'])) {
        // Redirect to the login page if not logged in
        header("Location: login.php");
        exit();
    }

    // Get form data
    $name = $_POST['name'];
    $idno = $_POST['idno'];
    $branch = $_POST['branch'];
    $date = $_POST['date'];
    $reason = $_POST['reason'];
    $user_id = $_SESSION['user_id']; // Retrieve the user ID from the session

    // Prepare and bind SQL statement
    $stmt = $conn->prepare("INSERT INTO studentout (name, idno, branch, date, reason, user_id, status) VALUES (?, ?, ?, ?, ?, ?, 'Pending')");
    $stmt->bind_param("sssssi", $name, $idno, $branch, $date, $reason, $user_id);

    // Execute the statement
    if ($stmt->execute()) {
        // Data inserted successfully
        echo "<script>alert('Registration data saved successfully.');</script>";
    } else {
        // Error occurred while inserting data
        echo "<script>alert('Error: " . $conn->error . "');</script>";
    }

    // Close statement
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Out Registration</title>
    <link rel="stylesheet" href="./css/formout.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }

        .registration-form {
            max-width: 500px;
            margin: 100px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.1);
        }

        .registration-form h1 {
            text-align: center;
            padding: 10px;
            border-radius: 10px;
            background-color: #fff;
            color: #000;
            margin-bottom: 20px;
        }

        .registration-form label {
            font-size: 18px;
            font-weight: bold;
        }

        .registration-form input[type="text"],
        .registration-form input[type="date"],
        .registration-form textarea {
            width: calc(100% - 24px);
            padding: 10px;
            border-radius: 10px;
            margin-bottom: 15px;
            border: 1px solid #ced4da;
            box-sizing: border-box;
        }

        .registration-form button {
            width: 100%;
            padding: 10px;
            border-radius: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            cursor: pointer;
            font-size: 18px;
        }

        .registration-form button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
<a href="./dashboard.php" class="btn bg-white" style="float:right;margin-right:200px;color:back;margin-top:50px">Back</a>
    <div class="registration-form " >
        <h1>Student Out Registration</h1>
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div>
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required>
            </div>
            <div>
                <label for="idno">ID Number:</label>
                <input type="text" id="idno" name="idno" required>
            </div>
            <div>
                <label for="branch">Branch:</label>
                <input type="text" id="branch" name="branch" required>
            </div>
            <div>
                <label for="date">Date:</label>
                <input type="date" id="date" name="date" required>
            </div>
            <div>
                <label for="reason">Reason:</label>
                <textarea id="reason" name="reason" required></textarea>
            </div>
            <button type="submit">Submit</button>
        </form>
    </div>
</body>
</html>
