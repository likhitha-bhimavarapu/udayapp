<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .registration-form {
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .registration-form h1 {
            color: #007bff;
        }
        .registration-form button[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
        }
        .registration-form a {
            text-decoration: none;
        }
        .img-section {
            background: url('image.png') no-repeat center center;
            background-size: cover;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-6 img-section d-none d-md-block">
            <img src="../MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS//imgae.png" style="height:100vh" alt="">
        </div>
        <div class="col-md-6">
            <div class="registration-form">
                <h1>REGISTER HERE</h1>
                <form method="POST" action="">
                    <div class="mb-3">
                        <label for="uname" class="form-label">Username:</label>
                        <input type="text" class="form-control" name="uname" id="uname" required>
                    </div>
                    <div class="mb-3">
                        <label for="pwd" class="form-label">Password:</label>
                        <input type="password" class="form-control" name="pwd" id="pwd" required>
                    </div>
                    <div class="mb-3">
                        <label for="cpwd" class="form-label">Confirm Password:</label>
                        <input type="password" class="form-control" name="cpwd" id="cpwd" required>
                    </div>
                    <div class="mb-3">
                        <label for="mobile" class="form-label">Mobile No:</label>
                        <input type="tel" class="form-control" name="mobile" id="mobile" required>
                    </div>
                    <div class="mb-3">
                        <label for="mail" class="form-label">E-mail:</label>
                        <input type="email" class="form-control" name="mail" id="mail" required>
                    </div>
                    <button type="submit" name="submit" class="btn btn-primary">SUBMIT</button>
                    <a href="./login.php" class="btn btn-secondary">Login</a>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "college";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['submit'])) {
    $username = mysqli_real_escape_string($conn, $_POST['uname']);
    $password = mysqli_real_escape_string($conn, $_POST['pwd']);
    $confirm_password = mysqli_real_escape_string($conn, $_POST['cpwd']);
    $mobile = mysqli_real_escape_string($conn, $_POST['mobile']);
    $email = mysqli_real_escape_string($conn, $_POST['mail']);

    if ($password !== $confirm_password) {
        echo "<script>alert('Passwords do not match. Please try again.');</script>";
    } else {
        // Hash the password before storing it
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Insert user data into the database
        $sql = "INSERT INTO users (username, password, mobile, email) VALUES ('$username', '$hashed_password', '$mobile', '$email')";

        if (mysqli_query($conn, $sql)) {
            $user_id = mysqli_insert_id($conn); // Get the user ID of the newly registered user
            echo "<script>alert('Registration successful! Your user ID is $user_id');</script>";
            echo "<script>window.location.href = 'login.php';</script>";
        } else {
            echo "<script>alert('Error: " . mysqli_error($conn) . "');</script>";
        }
    }
}

mysqli_close($conn);
?>
