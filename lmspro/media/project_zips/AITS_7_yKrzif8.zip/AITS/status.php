<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "college";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = $_SESSION['user_id'];

// Fetch the user's requests
$stmt = $conn->prepare("SELECT * FROM studentout WHERE user_id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User - View Request Status</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
        integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Add html2pdf library -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <style>
        body {
            overflow-x: hidden;
        }

        img:hover {
            background-color: mintcream;
            border-radius: 20px;
        }

        ul li {
            list-style-type: none;
        }

        .department-info {
            background-color: rgb(28, 199, 221);
            color: rgb(0, 0, 0);
            border-radius: 20px;
            margin-top: 50px;
        }

        .department-info img {
            border-radius: 20px;
            margin-bottom: 20px;
        }

        .department-info h5 {
            margin-top: 20px;
        }

        .department-info p {
            margin-top: 20px;
        }

        .additional-info {
            margin-top: 50px;
            display: flex;
            justify-content: space-between;
            gap: 20px;
        }

        .additional-info .card {
            text-align: center;
            padding: 20px;
            border-radius: 20px;
        }

        .video-container {
            margin-top: 50px;
            text-align: center;
        }

        @media (max-width: 768px) {
            .additional-info {
                flex-direction: column;
            }

            .additional-info .card {
                margin-top: 20px;
            }
        }

        footer {
            background-color: black;
            color: white;
            padding: 20px 0;
        }

        footer h3 {
            margin-bottom: 15px;
        }

        footer p {
            margin-bottom: 15px;
        }

        footer .social-icons i {
            font-size: 20px;
            margin-right: 15px;
        }

        footer a {
            color: white;
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline;
        }

        footer .quick-links ul {
            list-style: none;
            padding: 0;
        }

        footer .quick-links ul li {
            margin-bottom: 10px;
        }

        @media (max-width: 767px) {
            footer .d-flex {
                flex-direction: column;
                gap: 20px;
            }
        }

        /* PDF report styles */
        #reportContent {
            display: none;
        }
        
        .report-header {
            text-align: center;
            margin-bottom: 20px;
            border-bottom: 2px solid #333;
            padding-bottom: 10px;
        }
        
        .report-title {
            font-size: 24px;
            font-weight: bold;
        }
        
        .report-subtitle {
            font-size: 16px;
            color: #555;
        }
        
        .report-date {
            text-align: right;
            margin-bottom: 20px;
            color: #666;
        }
        
        .report-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        
        .report-table th, .report-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        
        .report-table th {
            background-color: #f2f2f2;
        }
        
        .report-footer {
            margin-top: 30px;
            text-align: center;
            font-size: 12px;
            color: #777;
            border-top: 1px solid #333;
            padding-top: 10px;
        }
        
        .status-approved {
            color: green;
            font-weight: bold;
        }
        
        .status-pending {
            color: orange;
            font-weight: bold;
        }
        
        .status-rejected {
            color: red;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="col-8 bg-light mt-5" id="header" style="width:100%">
        <h3 align="center">MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS</h3>
        <h6 align="center">Catering to the Educational Needs of Gifted Rural Youth of Andhra Pradesh
            (Established by the Govt. of Andhra Pradesh and recognized as per Section 2(f) of UGC Act, 1956)</h6>
        <h3 align="center">SAFETY AND SECURITY PORTAL</h3>
        <marquee behavior="" direction="">
            <h3 style="color: lightcoral;">MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS</h3>
        </marquee>
    </div>
    <div style="display: flex; justify-content:space-around">
        <h6>Welcome, <?php echo $_SESSION['username']; ?></h6>
        <a href="logout.php" class="btn bg-primary " style="width: 200px;margin-left: 30px;margin-bottom: 30px;">Logout</a>
    </div>
    <div style="display: flex; justify-content:space-around" class="two">
        <a href="./dashboard.php" class="btn bg-info">Home</a>
        <a href="./notifications.php" class="btn btn-success fw-bold" role="button">notification</a>
        <a href="./status.php" class="btn btn-success fw-bold" role="button">status</a>
        <a href="./formin.php" class="btn btn-success fw-bold" role="button">Student In</a>
        <a href="./formout.php" class="btn btn-warning fw-bold" role="button">Student Out</a>
    </div>

    <div class="container mt-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1>View Your Request Status</h1>
            <button id="generateReport" class="btn btn-primary">
                <i class="fas fa-file-pdf me-2"></i>Generate Report
            </button>
        </div>
        
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>ID Number</th>
                    <th>Branch</th>
                    <th>Date</th>
                    <th>Reason</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $result->data_seek(0); // Reset pointer for the table
                while ($row = $result->fetch_assoc()): 
                    $statusClass = '';
                    if ($row['status'] == 'Approved') {
                        $statusClass = 'status-approved';
                    } elseif ($row['status'] == 'Pending') {
                        $statusClass = 'status-pending';
                    } elseif ($row['status'] == 'Rejected') {
                        $statusClass = 'status-rejected';
                    }
                ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['id']); ?></td>
                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                    <td><?php echo htmlspecialchars($row['idno']); ?></td>
                    <td><?php echo htmlspecialchars($row['branch']); ?></td>
                    <td><?php echo htmlspecialchars($row['date']); ?></td>
                    <td><?php echo htmlspecialchars($row['reason']); ?></td>
                    <td class="<?php echo $statusClass; ?>"><?php echo htmlspecialchars($row['status']); ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <!-- Hidden content for PDF generation -->
    <div id="reportContent">
        <div class="report-header">
            <div class="report-title">MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS</div>
            <div class="report-subtitle">Student Outpass Request Status Report</div>
        </div>
        
        <div class="report-date">
            Generated on: <span id="currentDate"></span><br>
            Generated by: <?php echo htmlspecialchars($_SESSION['username']); ?>
        </div>
        
        <div class="student-info">
            <p><strong>Student Name:</strong> <?php echo htmlspecialchars($_SESSION['username']); ?></p>
            <p><strong>Total Requests:</strong> <span id="totalRequests"></span></p>
            <p><strong>Approved:</strong> <span id="approvedCount"></span></p>
            <p><strong>Pending:</strong> <span id="pendingCount"></span></p>
            <p><strong>Rejected:</strong> <span id="rejectedCount"></span></p>
        </div>
        
        <table class="report-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>ID Number</th>
                    <th>Branch</th>
                    <th>Date</th>
                    <th>Reason</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $result->data_seek(0); // Reset pointer for the report
                $approvedCount = 0;
                $pendingCount = 0;
                $rejectedCount = 0;
                
                while ($row = $result->fetch_assoc()): 
                    if ($row['status'] == 'Approved') $approvedCount++;
                    elseif ($row['status'] == 'Pending') $pendingCount++;
                    elseif ($row['status'] == 'Rejected') $rejectedCount++;
                    
                    $statusClass = '';
                    if ($row['status'] == 'Approved') {
                        $statusClass = 'status-approved';
                    } elseif ($row['status'] == 'Pending') {
                        $statusClass = 'status-pending';
                    } elseif ($row['status'] == 'Rejected') {
                        $statusClass = 'status-rejected';
                    }
                ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['id']); ?></td>
                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                    <td><?php echo htmlspecialchars($row['idno']); ?></td>
                    <td><?php echo htmlspecialchars($row['branch']); ?></td>
                    <td><?php echo htmlspecialchars($row['date']); ?></td>
                    <td><?php echo htmlspecialchars($row['reason']); ?></td>
                    <td class="<?php echo $statusClass; ?>"><?php echo htmlspecialchars($row['status']); ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        
        <div class="report-footer">
            This report was generated automatically by the Safety and Security Portal of MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS.
        </div>
    </div>

    <br/>
    <br/>
    <br/>
    <br/>

     <!-- Footer -->
     <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h3>About Us</h3>
                    <p>MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS Hyderabad of Telangana was established to play a pivotal role in the development of the intellectual capital in Engineering fields.</p>
                    <div class="social-icons">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-linkedin-in"></i></a>
                        <a href="#"><i class="fab fa-youtube"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
                <div class="col-md-4">
                    <h3>Quick Links</h3>
                    <div class="quick-links">
                        <ul>
                            <li><a href="./dashboard.php">Home</a></li>
                            <li><a href="./notifications.php">notifications</a></li>
                            <li><a href="./status.php">status</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="quick-links">
                        <ul>
                            <li><a href="#">Contact Us</a></li>
                            <p>Email:MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS@gmail.com</p>
                            <p>Mobile Number+91- 1234567890</p>
                            <p>Location:Andhra Pradesh</p>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- End of Footer -->

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Initialize AOS animations
        AOS.init();
        
        // Set current date in the report
        const now = new Date();
        document.getElementById('currentDate').textContent = now.toLocaleString();
        
        // Calculate request counts
        const totalRequests = <?php echo $result->num_rows; ?>;
        const approvedCount = <?php echo $approvedCount; ?>;
        const pendingCount = <?php echo $pendingCount; ?>;
        const rejectedCount = <?php echo $rejectedCount; ?>;
        
        document.getElementById('totalRequests').textContent = totalRequests;
        document.getElementById('approvedCount').textContent = approvedCount;
        document.getElementById('pendingCount').textContent = pendingCount;
        document.getElementById('rejectedCount').textContent = rejectedCount;
        
        // Generate PDF report
        document.getElementById('generateReport').addEventListener('click', function() {
            // Show loading indicator
            const originalButtonText = this.innerHTML;
            this.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Generating Report...';
            this.disabled = true;
            
            // Options for PDF generation
            const element = document.getElementById('reportContent');
            const opt = {
                margin: 10,
                filename: 'outpass_status_report_' + now.getTime() + '.pdf',
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { 
                    scale: 2,
                    logging: true,
                    useCORS: true
                },
                jsPDF: { 
                    unit: 'mm', 
                    format: 'a4', 
                    orientation: 'portrait' 
                }
            };
            
            // Generate PDF
            html2pdf().set(opt).from(element).save().then(() => {
                // Restore button state
                this.innerHTML = originalButtonText;
                this.disabled = false;
            }).catch(err => {
                console.error('Error generating PDF:', err);
                this.innerHTML = originalButtonText;
                this.disabled = false;
                alert('Error generating PDF. Please try again.');
            });
        });
    });
    </script>
</body>
</html>