<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<style>
    body{
        font-size: 14px;
    }
</style>
<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-2 mt-5 text-center">
                <img src="./images/logo.jpg" class="img-fluid" alt="Logo">
            </div>
            <div class="col-md-8 bg-light mt-5 text-center" id="header" >
                <h3>MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS</h3>
                <h6 style="font-size: 14px;">Catering to the Educational Needs of Gifted Rural Youth of Andhra Pradesh (Established by the Govt. of Andhra Pradesh and recognized as per Section 2(f) of UGC Act, 1956)</h6>
                <h3>SAFETY AND SECURITY PORTAL</h3>
            </div>
        </div>
    </div>
    <div class="container mt-5">
        <div class="row">
            <div class="col-12">
                <div id="demo" class="carousel slide" data-bs-ride="carousel">
                    <div class="carousel-indicators">
                        <button type="button" data-bs-target="#demo" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                        <button type="button" data-bs-target="#demo" data-bs-slide-to="1" aria-label="Slide 2"></button>
                        <button type="button" data-bs-target="#demo" data-bs-slide-to="2" aria-label="Slide 3"></button>
                    </div>
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img src="./images/Civil Enginerring.jpg" class="d-block w-100" alt="MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS.jpg">
                        </div>
                        <div class="carousel-item">
                            <img src="./images/Electrical.jpg" class="d-block w-100" alt="MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS.jpeg">
                        </div>
                        <div class="carousel-item">
                            <img src="./images/mechanical.jpg" class="d-block w-100" alt="MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS.jpg">
                        </div>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#demo" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#demo" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
    <div class="container text-center mt-5">
        <h5 class="text-danger" style="font-size: 14px;">We The MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS always fights for the safety and security of the students</h5>
    </div>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-4 mb-4">
                <div class=" h-100">
                    <div class="card-header">
                        <h6 class="text-success">STUDENT OUT REGISTRATION</h6>
                    </div>
                    <div class="">
                        <div class="card-title"><b>Note:</b></div>
                        <p class="card-text" style="font-size: 14px;">1. The students who are willing to go out are mandatory to fill the Student Out.<br>2. The grant of leave will be based on the reason which you mentioned in the form.</p>
                        <br>
                        <br>
                        <a href="./login.php" style="font-size: 14px;" class="btn btn-primary" role="button">FILL THE FORM</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class=" h-100">
                    <div class="card-header">
                        <h6 class="text-success">STUDENT IN CONFIRMATION</h6>
                    </div>
                    <div class="card-body">
                        <div class="card-title"><b>Note:</b></div>
                        <p class="card-text" style="font-size: 14px;">1. The Students who are in should be mandatory to fill the student in confirmation form.</p>
                        <br>
                        <br>
                        <br>
                        <a href="./login.php" style="font-size: 14px;" class="btn btn-primary" role="button">FILL THE FORM</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container mt-5">
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post" enctype="multipart/form-data">
            <div class="row">
                <div class="col-12">
                    <div class="">
                        <div class="card-header text-center" style="background-color: orangered;">
                            <h3 style="color:white">Complaint Box</h3>
                        </div>
                        <div class="card-body text-center">
                            <textarea style="font-size: 14px;" class="form-control" rows="5" placeholder="Drop your complaint here" name="compl"></textarea>
                            <br>
                            <button type="submit" class="btn btn-secondary"><small>Submit your complaint</small></button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <?php
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Database configuration
            $servername = "localhost"; // Change this to your server name
            $username = "root"; // Change this to your database username
            $password = ""; // Change this to your database password
            $dbname = "college"; // Change this to your database name
            // Create a connection
            $conn = new mysqli($servername, $username, $password, $dbname);
            // Check the connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Get the complaint from the form
            $complaint = $_POST['compl'];

            // Prepare and bind
            $stmt = $conn->prepare("INSERT INTO complaints (complaint) VALUES (?)");
            $stmt->bind_param("s", $complaint);

            // Execute the statement
            if ($stmt->execute()) {
                echo "New complaint submitted successfully";
            } else {
                echo "Error: " . $stmt->error;
            }
            // Close the statement and connection
            $stmt->close();
            $conn->close();
        }
        ?>
    </div>
    <div class="container-fluid bg-danger mt-5">
        <div class="row">
            <div class="col-12 text-center">
                <p class="fw-bold mb-0">copyright@2022 Annamacharya</p>
                <p class="fw-bold mb-0">feedback to Annamacharya@gmail.com</p>
            </div>
        </div>
    </div>
</body>
</html>
