<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: admin_login.php');
    exit();
}

$conn = mysqli_connect("localhost", "root", "", "college");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Validate and sanitize the ID
$user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize inputs
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $mobile = mysqli_real_escape_string($conn, $_POST['mobile']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);

    // Use prepared statement for security
    $stmt = $conn->prepare("UPDATE users SET username=?, mobile=?, email=? WHERE user_id=?");
    if ($stmt === false) {
        die("Prepare failed: " . $conn->error);
    }
    
    $stmt->bind_param("sssi", $username, $mobile, $email, $user_id);
    
    if ($stmt->execute()) {
        $_SESSION['message'] = "User updated successfully";
        header("Location: user_details.php");
        exit();
    } else {
        $error = "Error updating user: " . $stmt->error;
    }
    $stmt->close();
}

// Fetch user data using prepared statement
$stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ?");
if ($stmt === false) {
    die("Prepare failed: " . $conn->error);
}

$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

if (!$user) {
    die("User not found");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit User - Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .dashboard-header {
            background-color: #343a40;
            color: white;
            padding: 2rem 0;
            margin-bottom: 2rem;
            border-radius: 0 0 10px 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 2rem;
            border: none;
        }
        .card-header {
            background-color: #6c757d;
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 1rem 1.5rem;
            font-weight: 600;
        }
        .form-container {
            background-color: white;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        }
        .form-control {
            border-radius: 5px;
            padding: 10px 15px;
            border: 1px solid #ced4da;
        }
        .form-control:focus {
            border-color: #80bdff;
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
        }
        .btn {
            border-radius: 5px;
            padding: 8px 20px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        .btn-primary {
            background-color: #0d6efd;
            border-color: #0d6efd;
        }
        .btn-primary:hover {
            background-color: #0b5ed7;
            border-color: #0a58ca;
        }
        .btn-secondary {
            background-color: #6c757d;
            border-color: #6c757d;
        }
        .btn-secondary:hover {
            background-color: #5c636a;
            border-color: #565e64;
        }
        .alert {
            border-radius: 5px;
        }
        .form-label {
            font-weight: 500;
            margin-bottom: 8px;
        }
        .action-buttons {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <!-- Dashboard Header -->
    <div class="dashboard-header">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <h1><i class="fas fa-user-cog"></i> Admin Dashboard</h1>
                    <p class="lead">Welcome, <?php echo $_SESSION['admin']['username'] ?? 'Admin'; ?>!</p>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <!-- Navigation Buttons -->
        <div class="card mb-4">
            <div class="card-body text-center">
                <a href="user_details.php" class="btn btn-info mx-1 mb-2">User Details</a>
                <a href="complaint.php" class="btn btn-info mx-1 mb-2">Complaints</a>
                <a href="Approval.php" class="btn btn-info mx-1 mb-2">Out Approval/Reject</a>
                <a href="admin_studentin.php" class="btn btn-info mx-1 mb-2">In</a>
                <a href="information.php" class="btn btn-success mx-1 mb-2 fw-bold">Information</a>
                <a href="admin_logout.php" class="btn btn-danger mx-1 mb-2">Logout</a>
            </div>
        </div>

        <!-- Edit User Card -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="fas fa-user-edit"></i> Edit User</h5>
            </div>
            <div class="card-body">
                <div class="form-container">
                    <?php if (isset($error)): ?>
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST">
                        <div class="mb-4">
                            <label for="username" class="form-label">Username:</label>
                            <input type="text" class="form-control" id="username" name="username" 
                                   value="<?php echo htmlspecialchars($user['username']); ?>" required>
                        </div>
                        
                        <div class="mb-4">
                            <label for="mobile" class="form-label">Mobile Number:</label>
                            <input type="text" class="form-control" id="mobile" name="mobile" 
                                   value="<?php echo htmlspecialchars($user['mobile']); ?>" required>
                        </div>
                        
                        <div class="mb-4">
                            <label for="email" class="form-label">Email Address:</label>
                            <input type="email" class="form-control" id="email" name="email" 
                                   value="<?php echo htmlspecialchars($user['email']); ?>" required>
                        </div>
                        
                        <div class="action-buttons">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Update User
                            </button>
                            <a href="user_details.php" class="btn btn-secondary">
                                <i class="fas fa-times"></i> Cancel
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Font Awesome for icons -->
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</body>
</html>
<?php mysqli_close($conn); ?>