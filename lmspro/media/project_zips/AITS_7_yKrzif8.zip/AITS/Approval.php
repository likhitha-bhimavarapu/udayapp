<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: admin_login.php');
    exit();
}

// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "college";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle approval/rejection
if (isset($_POST['approve'])) {
    $id = $_POST['id'];
    $stmt = $conn->prepare("UPDATE studentout SET status='Approved' WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
} elseif (isset($_POST['reject'])) {
    $id = $_POST['id'];
    $stmt = $conn->prepare("UPDATE studentout SET status='Rejected' WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
}

// Fetch all student out requests
$result = $conn->query("SELECT * FROM studentout ORDER BY date DESC");

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.25/jspdf.plugin.autotable.min.js"></script>
    <title>Admin - Approve or Reject Requests</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }

        #header {
            background: linear-gradient(45deg, #ff512f, #dd2476);
            color: white;
            padding: 20px 0;
            text-align: center;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        #header h1 {
            font-weight: 700;
            margin-bottom: 5px;
            font-size: 2rem;
        }

        #header h6 {
            font-weight: 400;
            margin-bottom: 5px;
            font-size: 0.9rem;
        }

        #header marquee h3 {
            font-weight: 600;
            margin-top: 5px;
            font-size: 1.1rem;
        }

        .nav-container {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 15px;
            margin: 20px auto;
            max-width: 1200px;
        }

        .btn-nav {
            margin: 5px;
            padding: 8px 15px;
            font-size: 0.85rem;
            font-weight: 600;
            border-radius: 8px;
            transition: all 0.3s ease;
            min-width: 120px;
        }

        .btn-info {
            background: linear-gradient(45deg, #5b86e5, #36d1dc);
            border: none;
            color: white;
        }

        .btn-success {
            background: linear-gradient(45deg, #4e54c8, #8f94fb);
            border: none;
            color: white;
        }

        .btn-danger {
            background: linear-gradient(45deg, #ff416c, #ff4b2b);
            border: none;
            color: white;
        }

        .btn-nav:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
            color: white;
        }

        .approval-container {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            padding: 25px;
            margin: 20px auto;
            max-width: 1200px;
        }

        .page-title {
            color: #343a40;
            font-weight: 700;
            margin-bottom: 25px;
            text-align: center;
            position: relative;
            padding-bottom: 10px;
        }

        .page-title:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 3px;
            background: linear-gradient(45deg, #ff512f, #dd2476);
        }

        .btn-report {
            background: linear-gradient(45deg, #ff512f, #dd2476);
            color: white;
            border: none;
            font-weight: 600;
            padding: 8px 20px;
            border-radius: 8px;
            transition: all 0.3s ease;
            margin-bottom: 20px;
        }

        .btn-report:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
            color: white;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            font-size: 14px;
            text-align: left;
            background-color: #f9f9f9;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        table th {
            background: linear-gradient(45deg, #5b86e5, #36d1dc);
            color: white;
            padding: 12px 15px;
            text-align: center;
            font-weight: 600;
        }

        table td {
            border: 1px solid #ddd;
            padding: 12px 15px;
            vertical-align: middle;
        }

        table tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        table tr:hover {
            background-color: rgba(91, 134, 229, 0.05);
        }

        table td form {
            display: inline-block;
            margin: 0;
        }

        table td button {
            padding: 8px 12px;
            font-size: 14px;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s ease;
            border: none;
            font-weight: 600;
        }

        table td button[name="approve"] {
            background: linear-gradient(45deg, #4CAF50, #2E8B57);
            color: white;
        }

        table td button[name="reject"] {
            background: linear-gradient(45deg, #f44336, #D22B2B);
            color: white;
        }

        table td button:hover {
            opacity: 0.9;
            transform: translateY(-1px);
        }

        .status-pending {
            color: #FFA500;
            font-weight: 600;
        }

        .status-approved {
            color: #4CAF50;
            font-weight: 600;
        }

        .status-rejected {
            color: #f44336;
            font-weight: 600;
        }

        .footer-space {
            height: 50px;
        }
    </style>
</head>
<body>
    <!-- Dashboard Header -->
    <div class="col-8" id="header" style="width: 100%;">
        <h1 class="text-white">MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS</h1>
        <h6>Catering to the Educational Needs of Gifted Rural Youth of Andhra Pradesh (Established by the Govt. of Andhra Pradesh and recognized as per Section 2(f) of UGC Act, 1956)</h6>
        <h3>SAFETY AND SECURITY PORTAL</h3>
        <marquee behavior="" direction="">
            <h3 class="text-white">MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS</h3>
        </marquee>
    </div>

    <!-- Navigation Buttons -->
    <div class="nav-container text-center">
        <a href="./admin_dashboard.php" class="btn btn-info btn-nav">
            <i class="fas fa-home"></i> Home
        </a>
        <a href="user_details.php" class="btn btn-info btn-nav">
            <i class="fas fa-users"></i> User Details
        </a>
        <a href="Approval.php" class="btn btn-info btn-nav">
            <i class="fas fa-check-circle"></i> Out Approval
        </a>
        <a href="complaint.php" class="btn btn-info btn-nav">
            <i class="fas fa-exclamation-circle"></i> Complaints
        </a>
        <a href="admin_studentin.php" class="btn btn-info btn-nav">
            <i class="fas fa-sign-in-alt"></i> In
        </a>
        <a href="information.php" class="btn btn-success btn-nav fw-bold">
            <i class="fas fa-info-circle"></i> Information
        </a>
        <a href="admin_logout.php" class="btn btn-danger btn-nav">
            <i class="fas fa-sign-out-alt"></i> Logout
        </a>
    </div>

    <!-- Approval Section -->
    <div class="approval-container">
        <h1 class="page-title">Approve or Reject Student Out Requests</h1>
        
        <button id="generateReport" class="btn btn-report">
            <i class="fas fa-file-pdf"></i> Generate PDF Report
        </button>
        
        <div class="table-responsive">
            <table id="approvalTable">
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>ID Number</th>
                    <th>Branch</th>
                    <th>Date</th>
                    <th>Reason</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
                <?php while ($row = $result->fetch_assoc()): 
                    $status_class = '';
                    switch($row['status']) {
                        case 'Pending': $status_class = 'status-pending'; break;
                        case 'Approved': $status_class = 'status-approved'; break;
                        case 'Rejected': $status_class = 'status-rejected'; break;
                    }
                ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['id']); ?></td>
                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                    <td><?php echo htmlspecialchars($row['idno']); ?></td>
                    <td><?php echo htmlspecialchars($row['branch']); ?></td>
                    <td><?php echo htmlspecialchars($row['date']); ?></td>
                    <td><?php echo htmlspecialchars($row['reason']); ?></td>
                    <td class="<?php echo $status_class; ?>"><?php echo htmlspecialchars($row['status']); ?></td>
                    <td>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                            <button type="submit" name="approve">Approve</button>
                        </form>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                            <button type="submit" name="reject">Reject</button>
                        </form>
                    </td>
                </tr>
                <?php endwhile; ?>
            </table>
        </div>
    </div>

    <!-- Footer Space -->
    <div class="footer-space"></div>

    <!-- PDF Generation Script -->
    <script>
        document.getElementById('generateReport').addEventListener('click', function() {
            // Initialize jsPDF
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF('landscape');
            
            // Add title
            doc.setFontSize(18);
            doc.setTextColor(40);
            doc.text('Student Out Requests Report - MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS', doc.internal.pageSize.width / 2, 15, { align: 'center' });
            
            // Add date
            doc.setFontSize(10);
            doc.text('Generated on: ' + new Date().toLocaleDateString(), doc.internal.pageSize.width / 2, 22, { align: 'center' });
            
            // Add table
            doc.autoTable({
                html: '#approvalTable',
                startY: 30,
                styles: {
                    cellPadding: 5,
                    fontSize: 10,
                    valign: 'middle',
                    halign: 'left'
                },
                headStyles: {
                    fillColor: [91, 134, 229],
                    textColor: 255,
                    fontStyle: 'bold'
                },
                alternateRowStyles: {
                    fillColor: [248, 249, 250]
                },
                columnStyles: {
                    0: { cellWidth: 15 },
                    1: { cellWidth: 30 },
                    2: { cellWidth: 25 },
                    3: { cellWidth: 25 },
                    4: { cellWidth: 20 },
                    5: { cellWidth: 50 },
                    6: { cellWidth: 20 },
                    7: { cellWidth: 30 }
                },
                didDrawPage: function (data) {
                    // Footer
                    doc.setFontSize(10);
                    doc.setTextColor(150);
                    doc.text('Page ' + data.pageCount, data.settings.margin.left, doc.internal.pageSize.height - 10);
                }
            });
            
            // Save the PDF
            doc.save('Student_Out_Requests_Report_' + new Date().toISOString().slice(0, 10) + '.pdf');
        });
    </script>

    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>