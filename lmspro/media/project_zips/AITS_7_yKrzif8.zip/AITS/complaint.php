<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: admin_login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Admin Portal - Complaints</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.25/jspdf.plugin.autotable.min.js"></script>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        
        #header {
            background: linear-gradient(45deg, #ff512f, #dd2476);
            color: white;
            padding: 20px 0;
            text-align: center;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        
        #header h3 {
            font-weight: 700;
            margin-bottom: 5px;
        }
        
        #header h6 {
            font-weight: 400;
            margin-bottom: 5px;
            font-size: 0.9rem;
        }
        
        #header marquee h3 {
            font-weight: 600;
            margin-top: 5px;
            font-size: 1.1rem;
        }
        
        .nav-container {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 15px;
            margin: 20px auto;
            max-width: 1000px;
        }
        
        .btn-nav {
            margin: 5px;
            padding: 8px 15px;
            font-size: 0.85rem;
            font-weight: 600;
            border-radius: 8px;
            transition: all 0.3s ease;
            min-width: 120px;
        }
        
        .btn-info {
            background: linear-gradient(45deg, #5b86e5, #36d1dc);
            border: none;
            color: white;
        }
        
        .btn-success {
            background: linear-gradient(45deg, #4e54c8, #8f94fb);
            border: none;
            color: white;
        }
        
        .btn-danger {
            background: linear-gradient(45deg, #ff416c, #ff4b2b);
            border: none;
            color: white;
        }
        
        .btn-nav:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
            color: white;
        }
        
        .complaints-container {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            padding: 25px;
            margin: 20px auto;
            max-width: 1000px;
        }
        
        .page-title {
            color: #343a40;
            font-weight: 700;
            margin-bottom: 25px;
            text-align: center;
            position: relative;
            padding-bottom: 10px;
        }
        
        .page-title:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 3px;
            background: linear-gradient(45deg, #ff512f, #dd2476);
        }
        
        .btn-report {
            background: linear-gradient(45deg, #ff512f, #dd2476);
            color: white;
            border: none;
            font-weight: 600;
            padding: 8px 20px;
            border-radius: 8px;
            transition: all 0.3s ease;
            margin-bottom: 20px;
        }
        
        .btn-report:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
            color: white;
        }
        
        .table-responsive {
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }
        
        .table {
            margin-bottom: 0;
        }
        
        .table thead th {
            background: linear-gradient(45deg, #5b86e5, #36d1dc);
            color: white;
            font-weight: 600;
            border: none;
            padding: 12px 15px;
        }
        
        .table tbody tr {
            transition: all 0.2s ease;
        }
        
        .table tbody tr:hover {
            background-color: rgba(91, 134, 229, 0.05);
        }
        
        .table td {
            padding: 12px 15px;
            vertical-align: middle;
            border-top: 1px solid #f1f1f1;
        }
        
        .no-complaints {
            text-align: center;
            padding: 20px;
            color: #6c757d;
            font-style: italic;
        }
        
        .footer-space {
            height: 50px;
        }
    </style>
</head>

<body>
    <!-- Dashboard Header -->
    <div class="col-8" id="header" style="width: 100%;">
        <h3>MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS</h3>
        <h6>Catering to the Educational Needs of Gifted Rural Youth of Andhra Pradesh (Established by the Govt. of Andhra Pradesh and recognized as per Section 2(f) of UGC Act, 1956)</h6>
        <h3>SAFETY AND SECURITY PORTAL</h3>
        <marquee behavior="" direction="">
            <h3>MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS</h3>
        </marquee>
    </div>

    <!-- Navigation Buttons -->
    <div class="nav-container text-center">
        <a href="./admin_dashboard.php" class="btn btn-info btn-nav">
            <i class="fas fa-home"></i> Home
        </a>
        <a href="user_details.php" class="btn btn-info btn-nav">
            <i class="fas fa-users"></i> User Details
        </a>
        <a href="complaint.php" class="btn btn-info btn-nav">
            <i class="fas fa-exclamation-circle"></i> Complaints
        </a>
        <a href="Approval.php" class="btn btn-info btn-nav">
            <i class="fas fa-check-circle"></i> Out Approval
        </a>
        <a href="admin_studentin.php" class="btn btn-info btn-nav">
            <i class="fas fa-sign-in-alt"></i> In
        </a>
        <a href="information.php" class="btn btn-success btn-nav fw-bold">
            <i class="fas fa-info-circle"></i> Information
        </a>
        <a href="admin_logout.php" class="btn btn-danger btn-nav">
            <i class="fas fa-sign-out-alt"></i> Logout
        </a>
    </div>

    <!-- Complaints Section -->
    <div class="complaints-container">
        <h1 class="page-title">Complaints Management</h1>
        
        <button id="generateReport" class="btn btn-report">
            <i class="fas fa-file-pdf"></i> Generate PDF Report
        </button>
        
        <div class="table-responsive">
            <table class="table table-striped" id="complaintsTable">
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Complaint</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Database configuration
                    $servername = "localhost";
                    $username = "root";
                    $password = "";
                    $dbname = "college";

                    // Create connection
                    $conn = new mysqli($servername, $username, $password, $dbname);

                    // Check connection
                    if ($conn->connect_error) {
                        die("<tr><td colspan='2' class='no-complaints'>Connection failed: " . $conn->connect_error . "</td></tr>");
                    }

                    // Retrieve complaints from the database
                    $sql = "SELECT id, complaint FROM complaints";
                    $result = $conn->query($sql);

                    if ($result && $result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>
                                    <td>" . htmlspecialchars($row["id"]) . "</td>
                                    <td>" . htmlspecialchars($row["complaint"]) . "</td>
                                  </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='2' class='no-complaints'>No complaints found</td></tr>";
                    }

                    // Close connection
                    $conn->close();
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Footer Space -->
    <div class="footer-space"></div>

    <!-- PDF Generation Script -->
    <script>
        document.getElementById('generateReport').addEventListener('click', function() {
            // Initialize jsPDF
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();
            
            // Add title
            doc.setFontSize(18);
            doc.setTextColor(40);
            doc.text('Complaints Report - MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS', 105, 15, { align: 'center' });
            
            // Add date
            doc.setFontSize(10);
            doc.text('Generated on: ' + new Date().toLocaleDateString(), 105, 22, { align: 'center' });
            
            // Add table
            doc.autoTable({
                html: '#complaintsTable',
                startY: 30,
                styles: {
                    cellPadding: 5,
                    fontSize: 10,
                    valign: 'middle',
                    halign: 'left'
                },
                headStyles: {
                    fillColor: [91, 134, 229],
                    textColor: 255,
                    fontStyle: 'bold'
                },
                alternateRowStyles: {
                    fillColor: [248, 249, 250]
                },
                columnStyles: {
                    0: { cellWidth: 15 },
                    1: { cellWidth: 150 }
                },
                didDrawPage: function (data) {
                    // Footer
                    doc.setFontSize(10);
                    doc.setTextColor(150);
                    doc.text('Page ' + data.pageCount, data.settings.margin.left, doc.internal.pageSize.height - 10);
                }
            });
            
            // Save the PDF
            doc.save('Complaints_Report_' + new Date().toISOString().slice(0, 10) + '.pdf');
        });
    </script>

    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>