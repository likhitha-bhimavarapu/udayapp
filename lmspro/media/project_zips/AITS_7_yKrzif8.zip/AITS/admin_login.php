<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if ($username === 'admin' && $password === 'admin') {
        $_SESSION['admin'] = true;
        header('Location: admin_dashboard.php');
        exit();
    } else {
        $error = "Invalid username or password";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - E-Diary</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <style>
        body {
            margin: 0;
            padding: 0;
        }
        #header {
            background-color: #f8f9fa;
            padding: 20px;
            text-align: center;
        }
        #header h3 {
            margin-bottom: 10px;
        }
        #header h6 {
            margin-bottom: 10px;
        }
        #header marquee h3 {
            color: lightcoral;
            margin-bottom: 10px;
        }
        .login-container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 80vh;
        }
        .login-image {
            max-width: 100%;
            height: auto;
            border-radius: 20px;
        }
    </style>
</head>
<body>
    <div class="col-8 bg-light" id="header" style="width: 100%;">
        <h3>MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS</h3>
        <h6>Catering to the Educational Needs of Gifted Rural Youth of Andhra Pradesh (Established by the Govt. of Andhra Pradesh and recognized as per Section 2(f) of UGC Act, 1956)</h6>
        <h3>SAFETY AND SECURITY PORTAL</h3>
        <marquee behavior="" direction="">
            <h3>MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS</h3>
        </marquee>

    </div>
    <div class="container login-container ">
        <div class="row">
            <div class="col-md-6 d-none d-md-block">
                <img src="../MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS//images//cse-ai-ml.png" alt="Login Image" class="login-image">
            </div>
            <div class="col-md-6">
                <h2>Admin Login</h2>
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo $error; ?>
                    </div>
                <?php endif; ?>
                <form method="POST" action="">
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Login</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
