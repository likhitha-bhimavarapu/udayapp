<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "college";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch notifications ordered by created_at in descending order
$result = $conn->query("SELECT * FROM notifications ORDER BY created_at DESC");

// Store notifications in an array for later use
$notifications = [];
while ($row = $result->fetch_assoc()) {
    $notifications[] = $row;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student - View Notifications</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Your existing CSS styles remain the same */
        body {
            overflow-x: hidden;
        }
        /* ... (keep all your existing styles) ... */
        
        /* PDF report specific styles */
        #reportContent {
            padding: 20px;
            background-color: white;
            color: black;
        }
        
        .report-header {
            text-align: center;
            margin-bottom: 20px;
            border-bottom: 2px solid #333;
            padding-bottom: 10px;
        }
        
        .report-title {
            font-size: 24px;
            font-weight: bold;
        }
        
        .report-subtitle {
            font-size: 16px;
            color: #555;
        }
        
        .report-date {
            text-align: right;
            margin-bottom: 20px;
            color: #666;
        }
        
        .report-notification {
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid #eee;
            page-break-inside: avoid;
        }
        
        .report-notification-title {
            font-weight: bold;
            font-size: 18px;
            margin-bottom: 5px;
            color: #333;
        }
        
        .report-notification-date {
            font-size: 12px;
            color: #777;
            margin-bottom: 10px;
        }
        
        .report-notification-message {
            font-size: 14px;
            line-height: 1.5;
        }
        
        .report-footer {
            margin-top: 30px;
            text-align: center;
            font-size: 12px;
            color: #777;
            border-top: 1px solid #333;
            padding-top: 10px;
        }
    </style>
</head>
<body>
<div class="col-8 bg-light mt-5" id="header" style="width:100%">
    <h3 align="center">MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS</h3>
    <h6 align="center">Catering to the Educational Needs of Gifted Rural Youth of Andhra Pradesh
        (Established by the Govt. of Andhra Pradesh and recognized as per Section 2(f) of UGC Act, 1956)</h6>
    <h3 align="center">SAFETY AND SECURITY PORTAL</h3>
    <marquee behavior="" direction="">
        <h3 style="color: lightcoral;">MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS</h3>
    </marquee>
</div>
<div style="display: flex; justify-content:space-around">
    <h6>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?></h6>
    <a href="logout.php" class="btn bg-primary " style="width: 200px;margin-left: 30px;margin-bottom: 30px;">Logout</a>
</div>
<div style="display: flex; justify-content:space-around" class="two">
    <a href="./dashboard.php" class="btn bg-info">Home</a>
    <a href="./notifications.php" class="btn btn-success fw-bold" role="button">Notification</a>
    <a href="./status.php" class="btn btn-success fw-bold" role="button">Status</a>
    <a href="./formin.php" class="btn btn-success fw-bold" role="button">Student In</a>
    <a href="./formout.php" class="btn btn-warning fw-bold" role="button">Student Out</a>
</div>
<div class="container mt-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Notifications</h1>
        <button id="generateReport" class="btn btn-primary">
            <i class="fas fa-file-pdf me-2"></i>Generate Report
        </button>
    </div>
    
    <div id="notificationsContainer">
        <?php foreach ($notifications as $row): ?>
            <div class="card mb-3">
                <div class="card-body">
                    <h5 class="card-title"><?php echo htmlspecialchars($row['title']); ?></h5>
                    <p class="card-text"><?php echo nl2br(htmlspecialchars($row['message'])); ?></p>
                    <p class="card-text"><small class="text-muted">Posted on <?php echo htmlspecialchars($row['created_at']); ?></small></p>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Content for PDF generation (not hidden anymore) -->
<div id="reportContent" style="display: none;">
    <div class="report-header">
        <div class="report-title">MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS</div>
        <div class="report-subtitle">Notifications Report</div>
    </div>
    
    <div class="report-date">
        Generated on: <span id="currentDate"></span><br>
        Generated by: <?php echo htmlspecialchars($_SESSION['username']); ?>
    </div>
    
    <div id="reportNotifications">
        <?php foreach ($notifications as $row): ?>
            <div class="report-notification">
                <div class="report-notification-title"><?php echo htmlspecialchars($row['title']); ?></div>
                <div class="report-notification-date">Posted on: <?php echo htmlspecialchars($row['created_at']); ?></div>
                <div class="report-notification-message"><?php echo nl2br(htmlspecialchars($row['message'])); ?></div>
            </div>
        <?php endforeach; ?>
    </div>
    
    <div class="report-footer">
        This report was generated automatically by the Safety and Security Portal.
    </div>
</div>

<br/>
<br/>
<br>
<br><br>
<!-- Footer -->
<footer>
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <h3>About Us</h3>
                <p>MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS Hyderabad of Telangana was established to play a pivotal role in the development of the intellectual capital in Engineering fields.</p>
                <div class="social-icons">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-linkedin-in"></i></a>
                    <a href="#"><i class="fab fa-youtube"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
            <div class="col-md-4">
                <h3>Quick Links</h3>
                <div class="quick-links">
                    <ul>
                        <li><a href="./dashboard.php">Home</a></li>
                        <li><a href="./notifications.php">Notifications</a></li>
                        <li><a href="./status.php">Status</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-4">
                <div class="quick-links">
                    <ul>
                        <li><a href="#">Contact Us</a></li>
                        <p>Email: MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS@gmail.com</p>
                        <p>Mobile Number: +91-1234567890</p>
                        <p>Location: Andhra Pradesh</p>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- End of Footer -->

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Set current date in the report
    const now = new Date();
    document.getElementById('currentDate').textContent = now.toLocaleString();
    
    // Generate PDF report
    document.getElementById('generateReport').addEventListener('click', function() {
        // Show loading indicator
        const originalButtonText = this.innerHTML;
        this.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Generating Report...';
        this.disabled = true;
        
        // Get the report content element
        const element = document.getElementById('reportContent');
        
        // Temporarily show the content for PDF generation
        element.style.display = 'block';
        
        // Options for PDF generation
        const opt = {
            margin: 15,
            filename: 'notifications_report_' + now.getTime() + '.pdf',
            image: { 
                type: 'jpeg', 
                quality: 0.98 
            },
            html2canvas: { 
                scale: 2,
                logging: true,
                useCORS: true,
                letterRendering: true,
                allowTaint: true
            },
            jsPDF: { 
                unit: 'mm', 
                format: 'a4', 
                orientation: 'portrait' 
            }
        };
        
        // Generate PDF
        html2pdf().set(opt).from(element).save().then(() => {
            // Hide the content again after generation
            element.style.display = 'none';
            
            // Restore button state
            this.innerHTML = originalButtonText;
            this.disabled = false;
        }).catch(err => {
            console.error('Error generating PDF:', err);
            element.style.display = 'none';
            this.innerHTML = originalButtonText;
            this.disabled = false;
            alert('Error generating PDF. Please try again.');
        });
    });
});
</script>
</body>
</html>