<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
    crossorigin="anonymous"></script>
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
    integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
<style>
    body{
        overflow-x: hidden;
    }
    img:hover {
        background-color: mintcream;
        border-radius: 20px;


    }
    ul li {
        list-style-type: none;
       
    }
    .department-info {
            background-color: rgb(28, 199, 221);
            color: rgb(0, 0, 0);
            border-radius: 20px;
            margin-top: 50px;
        }

        .department-info img {
            border-radius: 20px;
            margin-bottom: 20px;
        }

        .department-info h5 {
            margin-top: 20px;
        }

        .department-info p {
            margin-top: 20px;
        }

        .additional-info {
            margin-top: 50px;
            display: flex;
            justify-content: space-between;
            gap: 20px;
        }

        .additional-info .card {
            text-align: center;
            padding: 20px;
            border-radius: 20px;
        }

        .video-container {
            margin-top: 50px;
            text-align: center;
        }

        @media (max-width: 768px) {
            .additional-info {
                flex-direction: column;
            }

            .additional-info .card {
                margin-top: 20px;
            }
        }
        footer {
            background-color: black;
            color: white;
            padding: 20px 0;
        }
        footer h3 {
            margin-bottom: 15px;
        }
        footer p {
            margin-bottom: 15px;
        }
        footer .social-icons i {
            font-size: 20px;
            margin-right: 15px;
        }
        footer a {
            color: white;
            text-decoration: none;
        }
        footer a:hover {
            text-decoration: underline;
        }
        footer .quick-links ul {
            list-style: none;
            padding: 0;
        }
        footer .quick-links ul li {
            margin-bottom: 10px;
        }
        @media (max-width: 767px) {
            footer .d-flex {
                flex-direction: column;
                gap: 20px;
            }
        }
   
</style>

<head>
    <title>Dashboard</title>
</head>
<body>
    <div class="col-8 bg-light mt-5" id="header" style="width:100%">
        <h1 align="center" class="text-danger">MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS</h1>
        <h6 align="center">Catering to the Educational Needs of Gifted Rural
            Youth of Andhra Pradesh
            (Established by the Govt. of Andhra Pradesh and recognized as per Section
            2(f) of UGC Act, 1956)</h6>
        <h3 align="center">SAFETY AND SECURITY PORTAL</h3>
        <marquee behavior="" direction="">
            <h3 style="color: red;">MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS</h3>
        </marquee>
    </div>
    <div style="display: flex; justify-content:space-around">
        <h6>Welcome,
            <?php echo $_SESSION['username']; ?>
        </h6>
        <a href="logout.php" class="btn bg-primary "
            style="width: 200px;margin-left: 30px;margin-bottom: 30px;">Logout</a>
    </div>
    <div style="display: flex; justify-content:space-around" class="two">
    <a href="./notifications.php" class="btn btn-success fw-bold" role="button">notification</a>
    <a href="./status.php" class="btn btn-success fw-bold" role="button">status</a>
        <a href="./formin.php" class="btn btn-success fw-bold" role="button">Student In</a>
        <a href="./formout.php" class="btn btn-warning fw-bold" role="button">Student Out</a>
    </div>

    <div>
        <div class="row p-3 mt-5" style="background-color: rgb(28, 199, 221);color: rgb(0, 0, 0);border-radius: 20px;">

            <img class="col-sm-6" src="./images/cse-ds.jpg" alt="" height="400" width="800"
                style="border-radius: 20px;margin-top: 10px;">
            <div class="col-sm-6" style="margin-top: 20px;">
                <h5 class="fw-bold" style="margin-top: 20px;">Computer Science and Engineering(data Science)</h5>
                <p style=" margin-top: 50px;">Bachelor of Technology in CSE (Data Science)
                    B.Tech CSE (Data Science) is a 4-year undergraduate degree programme. Data Science teaches the
                    students
                    how to combine machine learning techniques, algorithms, tools, business acumen and mathematics and
                    apply
                    on raw data to extract insight information from it. In short, technology, algorithm development and
                    data
                    inference are blended together to solve complex problems analytically in Data Science.

                    Throughout the entire duration of the programme, the students are taught how to amalgamate business
                    knowledge, tools and statistics to generate business value in creative ways.

                    The four-year undergraduate curriculum includes a detailed delivery of Basic Sciences, Mathematical
                    Foundations, Statistical Foundations, Artificial Intelligence, Machine Learning, Data Science, Deep
                    Learning, and Data Visualization.
                </p>
            </div>
        </div>
    </div>

    <div>
        <div class=" row d-flex p-3 mt-5"
            style="border-radius: 20px;">

            <div class="col-sm-6" style="margin-top: 20px;">
                <h5 class="fw-bold">Electronics & Communication Engineering </h5>
                <p style="margin-top: 50px;">The ECE department was established in the academic year 2006
                    with an
                    annual intake of 60 students. The
                    number of students further went up to 120 in the year 2007.

                    The Department comprises of a team of dynamic, dedicated, well qualified, and experienced
                    academicians.
                    They are all professors, associate professors, assistant professors and senior faculty with vast
                    research experience in their respective fields. It is a strong team striving to incorporate
                    excellence
                    in theory and practice.

                    The department has also been inviting visiting faculty from various prestigious universities to
                    update
                    the students about the latest academic developments.

                    The faculty ensures each student receives personal attention. They encourage students to be
                    innovative,
                    thus instilling an interest for research and development in the students. The ECE department has
                    also
                    been propagating research based knowledge through various conferences.

                </p>

            </div>
            <img src="./images/Elec- Communication Enginerring.png" alt="" srcset="" height="400" width="800"
                class="col-sm-6" style="border-radius: 20px;">
        </div>
    </div>
    <div>
        <div class=" row d-flex p-3 mt-5"
            style="background-color: rgb(28, 199, 221);color: rgb(0, 0, 0);border-radius: 20px;">
            <img src="./images/Civil Enginerring.jpg" alt="" srcset="" height="400" width="800" class="col-sm-6"
                style="border-radius: 20px;">
            <div class="col-sm-6" style="margin-top: 20px;">
                <h5 class="fw-bold">Civil Engineering</h5>
                <p style="margin-top: 50px;">Vision
                    Specially trained human resources at Department of Civil Engineering, MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS will handle critical
                    areas in
                    System planning, Design and Rehabilitation management of the infrastructure for giving much needed
                    impetus for economic development and improve quality of life, meeting the societal needs.

                    Mission
                    To generate a specialized cadre of Civil Engineers, by imparting training through with the help of
                    state
                    of the art laboratories, and updated hardware and software.

                    To excel in R&D and Industrial Consultancy with linkages in India and abroad, and bring teaching,
                    research and consultancy to international standards in the field of Civil Engineering.

                    About Department
                    The MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS HyderabadDepartment of Civil Engineering was established in the academic year 2011, with an
                    annual intake of 40 students. The number of students further went up to 120 in the year 2013.

                </p>

            </div>
        </div>
    </div>
    <div>
        <div class=" row d-flex p-3 mt-5"
            style="border-radius: 20px;">

            <div class="col-sm-6" style="margin-top: 20px;">
                <h5 class="fw-bold">Electronics & Communication Engineering </h5>
                <p style="margin-top: 50px;">The Department of MCA was established in the academic year
                    2022-23 with
                    the intake of 120 affiliated to
                    Jawaharlal Nehru Technological University Hyderabad, Hyderabad. It strives hard to develop world
                    class,
                    self disciplined computer professionals who will be responsible for uplifting the economical status
                    of
                    our Nation and humanity.</p>

            </div>
            <img src="./images/MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS-hyd-mba.webp" alt="" srcset="" height="400" width="800" class="col-sm-6"
                style="border-radius: 20px;">
        </div>
    </div>
    <div>
        <div class="row p-3 mt-5" style="background-color: rgb(28, 199, 221);color: rgb(0, 0, 0);border-radius: 20px;">

            <img src="./images/Electrical.jpg" alt="" height="400" width="800"
                style="border-radius: 20px;margin-top: 10px;" class="col-sm-6">

            <div class="col-sm-6" style="margin-top: 20px;">
                <h5 class="fw-bold">Electrical & Electronics Engineering</h5>
                <p style="margin-top: 50px;">Electrical and Electronics Engineering (EEE) is a profession
                    that uses
                    Science and Technology, and
                    problem solving skills to design, construct, and maintain products. It is a challenging, but
                    exciting
                    and rewarding area of study.

                    The Dept. of Electrical and Electronics Engineering at Annamacharya Institute of Technology and
                    Sciences, was set up in the year 2006 to impart high quality technical education.

                    Since then the department has made remarkable progress towards achieving its goal. ItoffersB.Tech
                    course
                    in EEE, and two exclusive M.Tech Programmers, one in Power Electronics, and the other in Electrical
                    Power Systems.

                    MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS EEE department is headed by Associate Professor G. Bhaskar. The department is also supported by
                    N.
                    Baburao Professor & Dean of student affairs. He has more than 25 Years of combined experience in
                    teaching &industries.

                    In addition to that, the department has a strong pool of faculty,that also includes well acclaimed
                    R&D
                    specialists. The department’s professors and lecturers don an un paralleled level of expertise in
                    their
                    fields.

                    It is the pure expertise and dedication of faculty members, teamed with high class infrastructure
                    facilities, and topped up with perseverance of the students, that has led the branch to secure a top
                    position in the institute.

                    The department is also equipped with 7 state of the art laboratories which includes a computer
                    centre
                    too.</p>
            </div>
        </div>
    </div>
    <div>
        <div class=" row d-flex p-3 mt-5"
            style="color: rgb(0, 0, 0);border-radius: 20px;">

            <div class="col-sm-6" style="margin-top: 20px;">
                <h5 class="fw-bold">AIML (Artificial Intelligence and Machine Learning) </h5>
                <p style="margin-top: 50px;">
                    The 4-year B.Tech program in Artificial Intelligence and Machine Learning (AIML) focuses on complex
                    inputs and outputs that are used to make decisions or enhance human capabilities.

                    The Artificial Intelligence degree offers courses that span across computer science, AI/machine
                    learning, mathematics/statistics, computational modeling skills, domain knowledge and neural
                    networks.
                    The AIML degree will prepare students to stand out in one of the world’s fastest-growing careers.

                    Graduate of B.Tech in CSE (AIML) will acquire computer science skills with the added expertise in
                    artificial intelligence and machine learning to work across many sectors, including medicine,
                    finance,
                    robotics, and business intelligence.

                    Artificial intelligence engineer
                    Software developer
                    Robotics Programmer
                    Data Analyst
                    Popular employers include: Google, Facebook, Amazon, IBM, Intel, Samsung, NVIDIA, RBS, JP Morgan,
                    Citigroup.

                </p>

            </div>
            <img src="./images/cse-ai-ml.png" alt="" srcset="" height="400" width="800" class="col-sm-6"
                style="border-radius: 20px;">
        </div>
    </div>
    <div class="department-info container">
    <div class="row">
        <div class="col-sm-6">
            <img src="./images/mechanical.jpg" alt="Mechanical Engineering" class="img-fluid">
        </div>
        <div class="col-sm-6">
            <h5 class="fw-bold">Mechanical Engineering</h5>
            <p>A separate section for Mechanical Engineering was introduced in the year 2010 at MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS Hyderabad. However, what started as a small-scale academic unit has now grown to be a full-fledged department with well-qualified, experienced, and dedicated staff members.</p>
            <p>The Mechanical Engineering department boasts of an excellent infrastructure facilitating training the students on the latest technologies. It also has modern laboratories with sophisticated equipment and a spacious central library.</p>
        </div>
    </div>
</div>

<div class="additional-info container" style="height:400px;">
    <img src="./images/unnamed.jpg" alt="MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS Campus" class="img-fluid w-25">
    <div class="card" style="flex: 1;" >
        <h5>Why Choose Us?</h5>
        <p>MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS Hyderabad of Telangana was established to play a pivotal role in the development of the intellectual capital in Engineering fields.</p>
        <p>Annacharya Educational Trust aims to provide professional and higher education to students from rural areas.</p>
    </div>
    <div class="card" style="flex: 1;">
        <h5>VISION & MISSION</h5>
        <p>Vision: We strive to inculcate a sound knowledge of Engineering and Management in students along with social responsibility and ethical practices, to enable them to face impending challenges and carve a niche for the country in the global arena.</p>
    </div>
    <div class="card" style="flex: 1;">
        <h5>EVENTS</h5>
        <p>29 September: Fresher's Day Celebration at MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS</p>
        <p>15 September: Engineer's Day Celebrations at MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS</p>
        <p>J.R. SEAMLESS Pvt Ltd., Conducted On-Campus Placement Drive at MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS, Hyd.</p>
    </div>
</div>


        <!-- Footer -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h3>About Us</h3>
                    <p>MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS Hyderabad of Telangana was established to play a pivotal role in the development of the intellectual capital in Engineering fields.</p>
                    <div class="social-icons">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-linkedin-in"></i></a>
                        <a href="#"><i class="fab fa-youtube"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
                <div class="col-md-4">
                    <h3>Quick Links</h3>
                    <div class="quick-links">
                        <ul>
                            <li><a href="./dashboard.php">Home</a></li>
                            <li><a href="./notifications.php">notifications</a></li>
                            <li><a href="./status.php">status</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="quick-links">
                        <ul>
                            <li><a href="#">Contact Us</a></li>
                            <p>Email:MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS@gmail.com</p>
                            <p>Mobile Number+91- 1234567890</p>
                            <p>Location:Andhra Pradesh</p>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- End of Footer -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
   
</body>
</html>