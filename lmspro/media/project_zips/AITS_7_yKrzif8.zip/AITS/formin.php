<?php
session_start();
// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "college";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['username']) && isset($_POST['password'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query to check user credentials with parameterized query to prevent SQL injection
    $stmt = $conn->prepare("SELECT user_id, password FROM users WHERE username=?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($user_id, $hashed_password);

    if ($stmt->num_rows > 0) {
        $stmt->fetch();
        if (password_verify($password, $hashed_password)) {
            $_SESSION['username'] = $username;
            $_SESSION['user_id'] = $user_id;
            $_SESSION['login_success'] = true; // Set the session variable indicating a successful login
            header("Location: dashboard.php"); // Redirect to dashboard
            exit();
        } else {
            echo "<script>alert('Incorrect password.');</script>";
        }
    } else {
        echo "<script>alert('No user found with the provided username.');</script>";
    }

    $stmt->close();
}

if (isset($_POST['name']) && isset($_POST['idno']) && isset($_POST['date'])) {
    // Check if the user is logged in
    if (!isset($_SESSION['user_id'])) {
        // Redirect to the login page if not logged in
        header("Location: login.php");
        exit();
    }

    // Get form data
    $name = $_POST['name'];
    $idno = $_POST['idno'];
    $date = $_POST['date'];
    $user_id = $_SESSION['user_id']; // Retrieve the user ID from the session

    // Prepare and bind SQL statement
    $stmt = $conn->prepare("INSERT INTO studentin (name, idno, date, user_id) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("sssi", $name, $idno, $date, $user_id);

    // Execute the statement
    if ($stmt->execute()) {
        // Data inserted successfully
        echo "<script>alert('Confirmation data saved successfully.');</script>";
    } else {
        // Error occurred while inserting data
        echo "<script>alert('Error: " . $conn->error . "');</script>";
    }

    // Close statement
    $stmt->close();
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student In Confirmation</title>
    <link rel="stylesheet" href="./css/formout.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .confirmation-form {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 20px;
            box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.1);
        }

        .confirmation-form h1 {
            text-align: center;
            padding: 10px;
            border-radius: 20px;
            background-color: ivory;
            color: black;
        }

        .confirmation-form label {
            font-weight: bold;
        }

        .confirmation-form input[type="text"],
        .confirmation-form input[type="date"] {
            width: 100%;
            padding: 10px;
            border-radius: 10px;
            margin-bottom: 15px;
            border: 1px solid #ced4da;
        }

        .confirmation-form button {
            width: 100%;
            padding: 10px;
            border-radius: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            cursor: pointer;
        }

        .confirmation-form button:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>
    <a href="./dashboard.php" class="btn bg-white" style="float:right;margin-right:200px;color:back;margin-top:50px">Back</a>
    <div class="confirmation-form">
        <h1>Student In Confirmation</h1>
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="mb-3">
                <label for="name" class="form-label">Name:</label>
                <input type="text" id="name" name="name" required class="form-control">
            </div>
            <div class="mb-3">
                <label for="idno" class="form-label">ID Number:</label>
                <input type="text" id="idno" name="idno" required class="form-control">
            </div>
            <div class="mb-3">
                <label for="date" class="form-label">Date:</label>
                <input type="date" id="date" name="date" required class="form-control">
            </div>
            <button type="submit" class="btn btn-primary">Confirm</button>
        </form>
    </div>
    
</body>

</html>
