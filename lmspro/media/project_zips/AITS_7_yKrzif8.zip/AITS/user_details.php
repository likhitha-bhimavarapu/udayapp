<?php
session_start();

if (!isset($_SESSION['admin'])) {
    header('Location: admin_login.php');
    exit();
}

// Database connection
$conn = mysqli_connect("localhost", "root", "", "college");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Identify primary key column
$primary_key = 'user_id';

// Get all column names
$columns = [];
$result = mysqli_query($conn, "SHOW COLUMNS FROM users");
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $columns[] = $row['Field'];
    }
    mysqli_free_result($result);
}

// Search functionality
$search = '';
$users = [];
if (isset($_POST['search'])) {
    $search = mysqli_real_escape_string($conn, $_POST['search']);
    $conditions = [];
    if (in_array('username', $columns)) $conditions[] = "username LIKE '%$search%'";
    if (in_array('mobile', $columns)) $conditions[] = "mobile LIKE '%$search%'";
    if (in_array('email', $columns)) $conditions[] = "email LIKE '%$search%'";
    $where = $conditions ? 'WHERE ' . implode(' OR ', $conditions) : '';
} else {
    $where = '';
}

// Execute query
$sql = "SELECT user_id, username, mobile, email FROM users $where";
$result = mysqli_query($conn, $sql);

if (!$result) {
    die("Database error: " . mysqli_error($conn));
}

$users = mysqli_fetch_all($result, MYSQLI_ASSOC);
mysqli_free_result($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Details - Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.25/jspdf.plugin.autotable.min.js"></script>
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .dashboard-header {
            background-color: #343a40;
            color: white;
            padding: 2rem 0;
            margin-bottom: 2rem;
            border-radius: 0 0 10px 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 2rem;
            border: none;
        }
        .card-header {
            background-color: #6c757d;
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 1rem 1.5rem;
        }
        .table-responsive {
            border-radius: 10px;
            overflow: hidden;
        }
        .table {
            margin-bottom: 0;
        }
        .table thead th {
            background-color: #495057;
            color: white;
            border-bottom: none;
        }
        .table tbody tr:hover {
            background-color: rgba(0, 0, 0, 0.02);
        }
        .btn-report {
            background-color: #dc3545;
            color: white;
            margin-left: 10px;
        }
        .btn-report:hover {
            background-color: #bb2d3b;
            color: white;
        }
        .action-buttons .btn {
            margin-right: 5px;
            min-width: 70px;
        }
        .search-container {
            background-color: white;
            padding: 1.5rem;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
            margin-bottom: 1.5rem;
        }
    </style>
</head>
<body>
    <!-- Dashboard Header -->
    <div class="dashboard-header">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <h1><i class="fas fa-user-cog"></i> Admin Dashboard</h1>
                    <p class="lead">Welcome, <?php echo $_SESSION['admin']['username'] ?? 'Admin'; ?>!</p>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <!-- Navigation Buttons -->
        <div class="card mb-4">
            <div class="card-body text-center">
                <a href="user_details.php" class="btn btn-info mx-1 mb-2">User Details</a>
                <a href="complaint.php" class="btn btn-info mx-1 mb-2">Complaints</a>
                <a href="Approval.php" class="btn btn-info mx-1 mb-2">Out Approval/Reject</a>
                <a href="admin_studentin.php" class="btn btn-info mx-1 mb-2">In</a>
                <a href="information.php" class="btn btn-success mx-1 mb-2 fw-bold">Information</a>
                <a href="admin_logout.php" class="btn btn-danger mx-1 mb-2">Logout</a>
            </div>
        </div>

        <!-- User Details Card -->
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">User Details</h5>
                <button id="generateReport" class="btn btn-sm btn-report">
                    <i class="fas fa-file-pdf"></i> Generate PDF Report
                </button>
            </div>
            <div class="card-body">
                <!-- Search Form -->
                <div class="search-container">
                    <form method="POST" class="row g-3">
                        <div class="col-md-10">
                            <input type="text" name="search" class="form-control" placeholder="Search by username, mobile or email" value="<?php echo htmlspecialchars($search); ?>">
                        </div>
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-primary w-100">Search</button>
                        </div>
                    </form>
                </div>

                <!-- User Table -->
                <div class="table-responsive">
                    <table class="table table-hover" id="userTable">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Username</th>
                                <th>Mobile</th>
                                <th>Email</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($users) > 0): ?>
                                <?php foreach ($users as $user): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($user['user_id']); ?></td>
                                        <td><?php echo htmlspecialchars($user['username']); ?></td>
                                        <td><?php echo htmlspecialchars($user['mobile']); ?></td>
                                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                                        <td class="action-buttons">
                                            <a href="edit_user.php?user_id=<?php echo $user['user_id']; ?>" class="btn btn-sm btn-warning">Edit</a>
                                            <a href="delete_user.php?user_id=<?php echo $user['user_id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this user?');">Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="text-center">No users found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- PDF Generation Script -->
    <script>
        document.getElementById('generateReport').addEventListener('click', function() {
            // Initialize jsPDF
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();
            
            // Add title
            doc.setFontSize(18);
            doc.setTextColor(40);
            doc.text('User Details Report', 105, 15, { align: 'center' });
            
            // Add date
            doc.setFontSize(10);
            doc.text('Generated on: ' + new Date().toLocaleDateString(), 105, 22, { align: 'center' });
            
            // Add table
            doc.autoTable({
                html: '#userTable',
                startY: 30,
                styles: {
                    cellPadding: 3,
                    fontSize: 10,
                    valign: 'middle',
                    halign: 'center'
                },
                headStyles: {
                    fillColor: [73, 80, 87],
                    textColor: 255,
                    fontStyle: 'bold'
                },
                alternateRowStyles: {
                    fillColor: [248, 249, 250]
                },
                columnStyles: {
                    0: { cellWidth: 15 },
                    1: { cellWidth: 40 },
                    2: { cellWidth: 35 },
                    3: { cellWidth: 60 },
                    4: { cellWidth: 40 }
                },
                didDrawPage: function (data) {
                    // Footer
                    doc.setFontSize(10);
                    doc.setTextColor(150);
                    doc.text('Page ' + data.pageCount, data.settings.margin.left, doc.internal.pageSize.height - 10);
                }
            });
            
            // Save the PDF
            doc.save('User_Details_Report_' + new Date().toISOString().slice(0, 10) + '.pdf');
        });
    </script>

    <!-- Font Awesome for icons -->
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</body>
</html>
<?php mysqli_close($conn); ?>