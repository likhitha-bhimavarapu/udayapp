<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            color: white;
        }
        .container {
            margin-top: 10px;
        }
        .login-form {
         
            padding: 30px;
            border-radius: 10px;
          
            color: #000;
        }
        .login-form h2 {
            color: #007bff;
        }
        .login-form input {
            border-radius: 10px;
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
        }
        .login-form button {
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 10px;
            padding: 10px 20px;
            width: 100%;
            margin-bottom: 10px;
        }
        .login-form button:hover {
            background-color: #0056b3;
        }
        .login-form a {
            text-decoration: none;
            color: #007bff;
        }
        .login-form a:hover {
            text-decoration: underline;
        }
        .header {
            text-align: center;
            margin-bottom: 50px;
        }
        .header img {
            border-radius: 50%;
        }
        .header h3, .header h6 {
            margin: 0;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="header mb-4">
                <img src="./images/logo.jpg" alt="Logo" height="100" width="100">
                <h3 class="mt-2" style="color:rgb(128, 0, 255)">MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS</h3>
                <h6 class="" style="color:rgb(128, 0, 255)">Catering to the Educational Needs of Gifted Rural Youth of Andhra Pradesh</h6>
                <h6 class="" style="color:rgb(128, 0, 255)">(Established by the Govt. of Andhra Pradesh and recognized as per Section 2(f) of UGC Act, 1956)</h6>
                <h3 class="" style="color:rgb(128, 0, 255)">SAFETY AND SECURITY PORTAL</h3>
            </div>
            <div class="login-form">
                <h2 style="color:orangered" class="text-center">Login</h2>
                <br>
                <br>
                <form method="POST" action="">
                    <label for="username" style="color:orangered" class="fw-bold">Username:</label>
                    <input type="text"  id="username" class="w-50" name="username" required><br>
                    <label for="password" style="color:orangered" class="fw-bold ">Password:</label>
                    <input type="password" id="password" class="w-50" name="password" required><br>
                    <button type="submit"  class="btn btn-success w-25">Login</button><br>
                    <a href="./register form.php" class="btn btn-link w-25">Register</a>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Check if the session variable indicating a successful login is set
    <?php if(isset($_SESSION['login_success']) && $_SESSION['login_success'] === true) { ?>
        // Display an alert
        alert('Login successful!');
        <?php 
            // Unset the session variable to prevent the alert from showing again on page reload
            unset($_SESSION['login_success']);
        ?>
    <?php } ?>
</script>
</body>
</html>

<?php
session_start();
// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "college";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['username']) && isset($_POST['password'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query to check user credentials with parameterized query to prevent SQL injection
    $stmt = $conn->prepare("SELECT user_id, password FROM users WHERE username=?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($user_id, $hashed_password);

    if ($stmt->num_rows > 0) {
        $stmt->fetch();
        if (password_verify($password, $hashed_password)) {
            $_SESSION['username'] = $username;
            $_SESSION['user_id'] = $user_id;
            $_SESSION['login_success'] = true; // Set the session variable indicating a successful login
            header("Location: dashboard.php");
             // Redirect to dashboard
             
            exit();
        } else {
            echo "<script>alert('Incorrect password.');</script>";
        }
    } else {
        echo "<script>alert('No user found with the provided username.');</script>";
    }

    $stmt->close();
}
$conn->close();
?>
