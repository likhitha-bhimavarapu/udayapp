<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: admin_login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - E-Diary</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-gradient: linear-gradient(45deg, #5b86e5, #36d1dc);
            --secondary-gradient: linear-gradient(45deg, #4e54c8, #8f94fb);
            --danger-gradient: linear-gradient(45deg, #ff416c, #ff4b2b);
            --header-gradient: linear-gradient(45deg, #ff512f, #dd2476);
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .dashboard-header {
            background: var(--header-gradient);
            color: white;
            padding: 2rem 0;
            text-align: center;
            box-shadow: var(--shadow);
            position: relative;
            z-index: 10;
        }

        .dashboard-header h1 {
            font-weight: 700;
            margin-bottom: 0.5rem;
            font-size: 2.5rem;
            text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.2);
        }

        .dashboard-header h6 {
            font-weight: 400;
            margin-bottom: 0.5rem;
            font-size: 1rem;
            opacity: 0.9;
        }

        .dashboard-header marquee h3 {
            font-weight: 600;
            margin-top: 0.5rem;
            font-size: 1.2rem;
        }

        .dashboard-container {
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding: 2rem 0;
        }

        .dashboard-card {
            background-color: white;
            border-radius: 15px;
            box-shadow: var(--shadow);
            padding: 2.5rem;
            max-width: 900px;
            margin: 0 auto;
            width: 90%;
            position: relative;
            overflow: hidden;
            border: none;
        }

        .dashboard-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: var(--header-gradient);
        }

        .dashboard-title {
            color: #343a40;
            font-weight: 700;
            margin-bottom: 1.5rem;
            text-align: center;
            position: relative;
            padding-bottom: 15px;
        }

        .dashboard-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 3px;
            background: var(--header-gradient);
        }

        .welcome-text {
            font-size: 1.2rem;
            text-align: center;
            margin-bottom: 2rem;
            color: #6c757d;
        }

        .btn-dashboard {
            margin: 0.5rem;
            padding: 0.75rem 1.5rem;
            font-size: 1rem;
            font-weight: 600;
            border-radius: 8px;
            transition: var(--transition);
            border: none;
            color: white;
            min-width: 180px;
            position: relative;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .btn-dashboard:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
            color: white;
        }

        .btn-dashboard i {
            margin-right: 8px;
        }

        .btn-info {
            background: var(--primary-gradient);
        }

        .btn-success {
            background: var(--secondary-gradient);
        }

        .btn-danger {
            background: var(--danger-gradient);
        }

        .action-buttons {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            margin-top: 1.5rem;
        }

        @media (max-width: 768px) {
            .dashboard-header h1 {
                font-size: 2rem;
            }
            
            .dashboard-header h6 {
                font-size: 0.9rem;
            }
            
            .dashboard-card {
                padding: 1.5rem;
            }
            
            .btn-dashboard {
                min-width: 160px;
                font-size: 0.9rem;
                padding: 0.6rem 1.2rem;
            }
        }
    </style>
</head>
<body>
    <!-- Dashboard Header -->
    <div class="dashboard-header">
        <h1>MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS</h1>
        <h6>Catering to the Educational Needs of Gifted Rural Youth of Andhra Pradesh (Established by the Govt. of Andhra Pradesh and recognized as per Section 2(f) of UGC Act, 1956)</h6>
        <h3>SAFETY AND SECURITY PORTAL</h3>
        <marquee behavior="" direction="">
            <h3>MOTHER THERESA INSTITUTION OF COMPUTER APPLICATIONS</h3>
        </marquee>
    </div>

    <!-- Dashboard Content -->
    <div class="dashboard-container">
        <div class="dashboard-card">
            <h2 class="dashboard-title">Admin Dashboard</h2>
            <p class="welcome-text">Welcome, <?php echo htmlspecialchars($_SESSION['admin']['username'] ?? 'Admin'); ?>!</p>
            
            <div class="action-buttons">
                <a href="user_details.php" class="btn btn-info btn-dashboard">
                    <i class="fas fa-users"></i> User Details
                </a>
                <a href="complaint.php" class="btn btn-info btn-dashboard">
                    <i class="fas fa-exclamation-circle"></i> Complaints
                </a>
                <a href="Approval.php" class="btn btn-info btn-dashboard">
                    <i class="fas fa-check-circle"></i> Out Approval
                </a>
                <a href="admin_studentin.php" class="btn btn-info btn-dashboard">
                    <i class="fas fa-sign-in-alt"></i> Student In
                </a>
                <a href="information.php" class="btn btn-success btn-dashboard">
                    <i class="fas fa-info-circle"></i> Information
                </a>
                <a href="admin_logout.php" class="btn btn-danger btn-dashboard">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Font Awesome -->
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</body>
</html>