# similarity_detector_python-flask-app

It is project about finding the similarity in percentage between the given text using the python cdifflib library and integrated in python flask

**prerequisite**

1.Basic python

2.Python Flask [Web frame work]

4.Basic Html and Css to make website

**Working**

1.Make sure that you have installed python and any one ide for python [Anaconda spyder, pycharm] in your Computer

2.Download code from github

3.Open the project folder in your IDE.

4.Locate to app.py file and run the file

5.In the compiler you will get the message like this. If not you have error in the code

Restarting with stat
Debugger is active!
Debugger PIN: 716-674-243
Running on http://127.0.0.1:5000/ (Press CTRL+C to quit)

6.On the clicking the url your website will be locally hosted in your web browser.

**Python Packages to be installed and commands**

1.Flask --> pip install Flask

2.difflib --> pip install cdifflib

**Project Files and its functions**

1.It is very simple deployment as you can find only app.py file contains all the function in it

2.The website consisits of 2 functions 

  i) you can copy the text and paste in text box to find the similarities between them
  
  ii) You can upload the txt and docx files and can able to find the similarities between them
  
  
3..txt files are the sample files you can use it for demo

4.profile, requirements are the files help to deploy this app in cloud [heroku] it ia paas service helps to deploye the web apps

5. profile file tells the endpoint to be specified for application and requirements tells the neccessary packages to be installed to run web app.

6.This web application in cloud: https://similaritydectecor12.herokuapp.com/    

you can click and can use anywhere you wanted without python ide as it was published in cloud.
 


