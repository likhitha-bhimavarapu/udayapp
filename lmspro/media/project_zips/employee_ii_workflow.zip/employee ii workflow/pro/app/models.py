from django.db import models

class Technology(models.Model):
    name = models.CharField(max_length=100, unique=True)

    def __str__(self):
        return self.name

class Manager(models.Model):
    username = models.CharField(max_length=50, unique=True)
    password = models.CharField(max_length=50)
    technology = models.ForeignKey(Technology, on_delete=models.CASCADE, related_name='managers')
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class TeamLead(models.Model):
    username = models.CharField(max_length=50, unique=True)
    password = models.CharField(max_length=50)
    manager = models.ForeignKey(Manager, on_delete=models.CASCADE, related_name='team_leads')
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Project(models.Model):
    name = models.CharField(max_length=100)
    technology = models.ForeignKey(Technology, on_delete=models.CASCADE, related_name='projects')
    team_lead = models.ForeignKey(TeamLead, on_delete=models.CASCADE, related_name='projects')
    start_date = models.DateField()
    end_date = models.DateField()
    description = models.TextField()

    def __str__(self):
        return self.name  # Return the project name for string representation

    
from django.db import models


from django.db import models
from django.utils import timezone

class Employee(models.Model):
    employee_id = models.CharField(max_length=10, unique=True)
    name = models.CharField(max_length=100)
    designation = models.CharField(max_length=100)
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name="employees", null=True, blank=True)
    team_lead = models.ForeignKey('TeamLead', on_delete=models.SET_NULL, null=True, blank=True, related_name="employees")
    date_of_joining = models.DateField()
    mobile_number = models.CharField(max_length=15)
    email = models.EmailField()
    work_location = models.CharField(max_length=100)
    username = models.CharField(max_length=50, unique=True)
    password = models.CharField(max_length=50)
    experience = models.PositiveIntegerField()
    login_time = models.DateTimeField(null=True, blank=True)
    logout_time = models.DateTimeField(null=True, blank=True)
    clock_in_time = models.DateTimeField(null=True, blank=True)
    clock_out_time = models.DateTimeField(null=True, blank=True)
    break_start_time = models.DateTimeField(null=True, blank=True)
    break_end_time = models.DateTimeField(null=True, blank=True)
    technologies = models.ManyToManyField(Technology, blank=True, related_name="employees")  # Many-to-many field
    
    def start_work(self):
        self.clock_in_time = timezone.now()
        self.save()
    
    def end_work(self):
        self.clock_out_time = timezone.now()
        self.save()
    
    def start_break(self):
        self.break_start_time = timezone.now()
        self.save()
    
    def end_break(self):
        self.break_end_time = timezone.now()
        self.save()

    def total_work_time(self):
        if self.clock_in_time and self.clock_out_time:
            return self.clock_out_time - self.clock_in_time
        return timezone.timedelta(0)

    def total_break_time(self):
        if self.break_start_time and self.break_end_time:
            return self.break_end_time - self.break_start_time
        return timezone.timedelta(0)
    
    def __str__(self):
        return self.username



from django.db import models
from django.utils import timezone
from django.db import models
from django.utils import timezone

class Assignment(models.Model):
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='assignments')
    team_lead = models.ForeignKey(TeamLead, on_delete=models.CASCADE, related_name='assignments')
    task_title = models.CharField(max_length=255)
    description = models.TextField()
    assigned_date = models.DateTimeField(default=timezone.now)
    due_date = models.DateTimeField()
    status_choices = [
        ('Pending', 'Pending'),
        ('In Progress', 'In Progress'),
        ('Completed', 'Completed'),
    ]
    status = models.CharField(max_length=20, choices=status_choices, default='Pending')
    report = models.TextField(blank=True, null=True)
    file = models.FileField(upload_to='assignments/', blank=True, null=True)  # File upload field
    project_percentage = models.CharField(max_length=10, blank=True, null=True)
    partial_report = models.TextField(blank=True, null=True)


    def __str__(self):
        return f"Task: {self.task_title} assigned to {self.employee.name}"

class LeaveRequest(models.Model):
    STATUS_CHOICES = [
        ('Pending', 'Pending'),
        ('Approved', 'Approved'),
        ('Rejected', 'Rejected'),
    ]
    
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    start_date = models.DateField()
    end_date = models.DateField()
    reason = models.TextField()
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='Pending')
    team_lead = models.ForeignKey(TeamLead, on_delete=models.SET_NULL, null=True)

    def __str__(self):
        return f"{self.employee.name} - {self.start_date} to {self.end_date}"

