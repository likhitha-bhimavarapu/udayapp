from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from .models import Technology, Manager, TeamLead, Project

# Admin credentials
ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "admin"

# Admin Login View
def admin_login(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            return redirect("admin_dashboard")
        else:
            return HttpResponse("Invalid Credentials")
    return render(request, "admin_login.html")

def project_manager_login(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            return redirect("project_manager_dashboard")
        else:
            return HttpResponse("Invalid Credentials")
    return render(request, "project_manager_login.html")


def project_manager_dashboard(request):
    technologies = Technology.objects.all()
    employees = Employee.objects.all()
    team_leads = TeamLead.objects.all()
    projects = Project.objects.all()
    
    # Calculate counts for the dashboard
    technology_count = technologies.count()
    employee_count = employees.count()
    team_lead_count = team_leads.count()
    project_count = projects.count()
    
    return render(request, 'project_manager_dashboard.html', {
        'employees': employees, 
        'technologies': technologies,
        'team_leads': team_leads,
        'projects': projects,
        'technology_count': technology_count,
        'employee_count': employee_count,
        'team_lead_count': team_lead_count,
        'project_count': project_count,
    })




# views.py
from django.shortcuts import render, redirect, get_object_or_404
from .models import Employee, TeamLead, Project
# View to Assign Employees to Team Lead
def assign_employees_to_team_lead(request, team_lead_id):
    team_lead = get_object_or_404(TeamLead, id=team_lead_id)
    employees = Employee.objects.filter(team_lead__isnull=True)  # Unassigned employees

    if request.method == "POST":
        selected_employee_ids = request.POST.getlist("employees")
        for employee_id in selected_employee_ids:
            employee = get_object_or_404(Employee, id=employee_id)
            employee.team_lead = team_lead
            employee.save()
        return redirect("project_manager_dashboard")

    return render(request, "assign_employees_to_team_lead.html", {        
        "employees": employees
    })

# views.py
# views.py
from django.shortcuts import render, get_object_or_404, redirect
from .models import Technology, TeamLead, Project, Employee

def admin_dashboard(request):
    technologies = Technology.objects.all()
    employees = Employee.objects.all()
    team_leads = TeamLead.objects.all()
    projects = Project.objects.all()
    
    # Calculate counts for the dashboard
    technology_count = technologies.count()
    employee_count = employees.count()
    team_lead_count = team_leads.count()
    project_count = projects.count()
    
    return render(request, 'admin_dashboard.html', {
        'employees': employees, 
        'technologies': technologies,
        'team_leads': team_leads,
        'projects': projects,
        'technology_count': technology_count,
        'employee_count': employee_count,
        'team_lead_count': team_lead_count,
        'project_count': project_count,
    })


from django.shortcuts import render, get_object_or_404

def team_lead_details(request, team_lead_id):
    team_lead = get_object_or_404(TeamLead, id=team_lead_id)
    return render(request, "team_lead_details.html", {"team_lead": team_lead})

from .models import Employee

def employee_list(request):
    employees = Employee.objects.all()
    return render(request, "employee_list.html", {"employees": employees})


# Technology Management Views
def add_technology(request):
    if request.method == "POST":
        name = request.POST.get("name")
        Technology.objects.create(name=name)
        return redirect("project_manager_dashboard")
    return render(request, "add_technology.html")


def edit_technology(request, tech_id):
    technology = get_object_or_404(Technology, id=tech_id)
    if request.method == "POST":
        technology.name = request.POST.get("name")
        technology.save()
        return redirect("project_manager_dashboard")
    return render(request, "edit_technology.html", {"technology": technology})


def delete_technology(request, tech_id):
    technology = get_object_or_404(Technology, id=tech_id)
    technology.delete()
    return redirect("project_manager_dashboard")


# Manager and Team Lead Assignment Views
def add_manager(request, tech_id):
    technology = get_object_or_404(Technology, id=tech_id)
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        name = request.POST.get("name")
        Manager.objects.create(username=username, password=password, technology=technology, name=name)
        return redirect("project_manager_dashboard")
    return render(request, "add_manager.html", {"technology": technology})


def add_team_lead(request, manager_id):
    manager = get_object_or_404(Manager, id=manager_id)
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        name = request.POST.get("name")
        TeamLead.objects.create(username=username, password=password, manager=manager, name=name)
        return redirect("project_manager_dashboard")
    return render(request, "add_team_lead.html", {"manager": manager})


# Project Assignment to Team Lead
from django.shortcuts import render, get_object_or_404, redirect
from .models import Technology, TeamLead, Project
from django.shortcuts import render, get_object_or_404, redirect
from .models import Technology, TeamLead, Project
from django.shortcuts import render, get_object_or_404, redirect
from .models import Technology, TeamLead, Project

from .models import Technology

def technology_list(request):
    technologies = Technology.objects.all()
    return render(request, 'technology_list.html', {'technologies': technologies})

def assign_project(request, tech_id, team_lead_id):
    technology = get_object_or_404(Technology, id=tech_id)
    team_lead = get_object_or_404(TeamLead, id=team_lead_id)
    if request.method == "POST":
        project_name = request.POST.get("project_name")
        start_date = request.POST.get("start_date")
        end_date = request.POST.get("end_date")
        description = request.POST.get("description")

        # Create a new Project object with the provided details
        Project.objects.create(
            name=project_name,
            technology=technology,
            team_lead=team_lead,
            start_date=start_date,
            end_date=end_date,
            description=description
        )
        return redirect("project_manager_dashboard")
    return render(request, "assign_project.html", {"technology": technology, "team_lead": team_lead})

from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from .models import Technology, Manager, TeamLead, Project

# Manager Login View
def manager_login(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        try:
            manager = Manager.objects.get(username=username, password=password)
            # Redirect to manager dashboard if credentials are valid
            return redirect("manager_dashboard", manager_id=manager.id)
        except Manager.DoesNotExist:
            return HttpResponse("Invalid Manager Credentials")
    return render(request, "manager_login.html")


from django.shortcuts import render
from django.utils import timezone
from .models import Employee

# Admin Dashboard View
def view_employee_timings(request):
    # Get all employees
    employees = Employee.objects.all()
    
    employee_data = []
    for employee in employees:
        # Calculate work time and break time for each employee
        total_work_time = employee.total_work_time()
        total_break_time = employee.total_break_time()

        # Format time (hours, minutes, seconds)
        def format_timedelta(timedelta_obj):
            total_seconds = int(timedelta_obj.total_seconds())
            hours = total_seconds // 3600
            minutes = (total_seconds % 3600) // 60
            seconds = total_seconds % 60
            return f"{hours} hours, {minutes} minutes, {seconds} seconds"

        formatted_work_time = format_timedelta(total_work_time)
        formatted_break_time = format_timedelta(total_break_time)
        
        # Append to employee data list
        employee_data.append({
            
            "name": employee.username,
            "work_time": formatted_work_time,
            "break_time": formatted_break_time
        })

    context = {
        "employee_data": employee_data
    }
    return render(request, "view_employee_timings.html", context)


# Team Lead Login View
def team_lead_login(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        try:
            team_lead = TeamLead.objects.get(username=username, password=password)
            # Redirect to team lead dashboard if credentials are valid
            return redirect("team_lead_dashboard", team_lead_id=team_lead.id)
        except TeamLead.DoesNotExist:
            return HttpResponse("Invalid Team Lead Credentials")
    return render(request, "team_lead_login.html")

# Manager Dashboard View
from django.shortcuts import render, get_object_or_404
from .models import Manager, TeamLead, Project, Assignment, Employee

def manager_dashboard(request, manager_id):
    manager = get_object_or_404(Manager, id=manager_id)
    team_leads = manager.team_leads.all()  # Get all team leads under this manager
    team_lead_data = []

    for team_lead in team_leads:
        employees = team_lead.employees.all()
        projects = Project.objects.filter(team_lead=team_lead)
        assignments = Assignment.objects.filter(team_lead=team_lead)
        
        team_lead_data.append({
            "team_lead": team_lead,
            "employees": employees,
            "projects": projects,
            "assignments": assignments
        })

    return render(request, "manager_dashboard.html", {"manager": manager, "team_lead_data": team_lead_data})


# Team Lead Dashboard View
from django.shortcuts import render
from .models import Employee  # Import the Employee model

from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import TeamLead, Employee, Technology, Project, Assignment
from django.utils import timezone

def team_lead_dashboard(request, team_lead_id):
    team_lead = TeamLead.objects.get(id=team_lead_id)
    employees = Employee.objects.filter(team_lead=team_lead)
    technologies = Technology.objects.all()
    projects = Project.objects.all()
    num_employees = employees.count()

    if request.method == "POST":
        employee_id = request.POST.get("employee_id")
        task_title = request.POST.get("task_title")
        description = request.POST.get("description")
        due_date = request.POST.get("due_date")
        file = request.FILES.get("file")  # Get the uploaded file

        employee = Employee.objects.get(id=employee_id)

        # Create the assignment and save the uploaded file
        assignment = Assignment(
            employee=employee,
            team_lead=team_lead,
            task_title=task_title,
            description=description,
            due_date=due_date,
            file=file  # Assign the file to the model field
        )
        assignment.save()
        return redirect("team_lead_dashboard", team_lead_id=team_lead.id)

    return render(request, "team_lead_dashboard.html", {
        "team_lead": team_lead,
        "employees": employees,
        "technologies": technologies,
        "projects": projects,
        "num_employees": num_employees,
        "assignments": Assignment.objects.filter(team_lead=team_lead)
    })

# views.py
from django.shortcuts import render, redirect, get_object_or_404
from .models import Employee, TeamLead, LeaveRequest
from django.utils import timezone
from django.http import HttpResponse

def request_leave(request, employee_id):
    employee = get_object_or_404(Employee, id=employee_id)
    
    if request.method == "POST":
        start_date = request.POST.get("start_date")
        end_date = request.POST.get("end_date")
        reason = request.POST.get("reason")
        
        # Create a new leave request with status 'Pending'
        leave_request = LeaveRequest(
            employee=employee,
            team_lead=employee.team_lead,
            start_date=start_date,
            end_date=end_date,
            reason=reason,
            status='Pending'
        )
        leave_request.save()
        return HttpResponse("Leave request submitted successfully.")
    
    # Fetch all leave requests for this employee to show history
    leave_requests = LeaveRequest.objects.filter(employee=employee).order_by('-start_date')
    return render(request, "request_leave.html", {
        "employee": employee,
        "leave_requests": leave_requests  # Pass leave history to template
    })

def team_lead_leave(request, team_lead_id):
    team_lead = get_object_or_404(TeamLead, id=team_lead_id)
    
    # Get all leave requests managed by this team lead (not just pending)
    all_leave_requests = LeaveRequest.objects.filter(team_lead=team_lead).order_by('-start_date')
    
    if request.method == "POST":
        leave_request_id = request.POST.get("leave_request_id")
        action = request.POST.get("action")  # 'approve' or 'reject'
        
        leave_request = get_object_or_404(LeaveRequest, id=leave_request_id)
        if action == "approve":
            leave_request.status = 'Approved'
        elif action == "reject":
            leave_request.status = 'Rejected'
        leave_request.save()
        
        return redirect("team_lead_leave", team_lead_id=team_lead_id)

    return render(request, "team_lead_leave.html", {
        "team_lead": team_lead,
        "all_leave_requests": all_leave_requests  # Pass all leave requests to template
    })

from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from .models import Employee

# Admin - Add Employee
from django.shortcuts import get_object_or_404
from django.shortcuts import render, get_object_or_404, redirect
from .models import Employee, Project, Technology

from django.shortcuts import render, redirect, get_object_or_404
from .models import Employee, Project, Technology

def add_employee(request):
    if request.method == "POST":
        # Retrieve form data
        employee_id = request.POST.get("employee_id")
        name = request.POST.get("name")
        designation = request.POST.get("designation")
        project_id = request.POST.get("project_id")  # Get the selected project ID
        date_of_joining = request.POST.get("date_of_joining")
        mobile_number = request.POST.get("mobile_number")
        email = request.POST.get("email")
        work_location = request.POST.get("work_location")
        username = request.POST.get("username")
        password = request.POST.get("password")
        experience = request.POST.get("experience")

        # Retrieve the selected project instance
        project = get_object_or_404(Project, id=project_id)

        # Create and save the employee with the project
        employee = Employee.objects.create(
            employee_id=employee_id,
            name=name,
            designation=designation,
            project=project,  # Link the project
            date_of_joining=date_of_joining,
            mobile_number=mobile_number,
            email=email,
            work_location=work_location,
            username=username,
            password=password,
            experience=experience,
        )

        # Retrieve and associate technologies with the employee
        technology_ids = request.POST.getlist('technologies')  # Get selected technology IDs
        employee.technologies.set(technology_ids)

        return redirect("admin_dashboard")

    # Fetch projects and technologies for the dropdowns
    projects = Project.objects.all()
    technologies = Technology.objects.all()

    return render(request, "add_employee.html", {"projects": projects, "technologies": technologies})



# Edit Employee View
def edit_employee(request, employee_id):
    employee = get_object_or_404(Employee, employee_id=employee_id)
    if request.method == "POST":
        employee.name = request.POST.get("name")
        employee.designation = request.POST.get("designation")
        project_id = request.POST.get("project_id")
        employee.project = Project.objects.get(id=project_id) if project_id else None
        # employee.date_of_joining = request.POST.get("date_of_joining")
        employee.mobile_number = request.POST.get("mobile_number")
        employee.email = request.POST.get("email")
        employee.work_location = request.POST.get("work_location")
        employee.username = request.POST.get("username")
        employee.password = request.POST.get("password")
        employee.experience = request.POST.get("experience")
        employee.save()
        return redirect("admin_dashboard")
    
    projects = Project.objects.all()
    return render(request, "edit_employee.html", {"employee": employee, "projects": projects})


# Delete Employee View (no changes needed)
def delete_employee(request, employee_id):
    employee = get_object_or_404(Employee, employee_id=employee_id)
    employee.delete()
    return redirect("project_manager_dashboard")


# Admin - Edit Employee
# def edit_employee(request, employee_id):
#     employee = get_object_or_404(Employee, employee_id=employee_id)
#     if request.method == "POST":
#         employee.name = request.POST.get("name")
#         employee.designation = request.POST.get("designation")
#         employee.project_name = request.POST.get("project_name")
#         employee.date_of_joining = request.POST.get("date_of_joining")
#         employee.mobile_number = request.POST.get("mobile_number")
#         employee.email = request.POST.get("email")
#         employee.work_location = request.POST.get("work_location")
#         employee.username = request.POST.get("username")
#         employee.password = request.POST.get("password")
#         employee.save()
#         return redirect("admin_dashboard")
#     return render(request, "edit_employee.html", {"employee": employee})

# # Admin - Delete Employee
# def delete_employee(request, employee_id):
#     employee = get_object_or_404(Employee, employee_id=employee_id)
#     employee.delete()
#     return redirect("admin_dashboard")

# Employee Login
from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.utils import timezone
from .models import Employee

from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Employee
from django.utils import timezone

def employee_login(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        try:
            employee = Employee.objects.get(username=username, password=password)
            employee.login_time = timezone.now()
            employee.save()
            return redirect("employee_dashboard", employee_id=employee.id)
        except Employee.DoesNotExist:
            return HttpResponse("Invalid Credentials")
    return render(request, "employee_login.html")



# views.py
from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.utils import timezone
from .models import Employee

from django.utils import timezone

def employee_dashboard(request, employee_id):
    employee = Employee.objects.get(id=employee_id)
    # Fetch relevant data for the employee dashboard

    
    # Fetch all assignments for the employee
    assignments = Assignment.objects.filter(employee=employee)
    
    # Calculate total work time in seconds
    total_work_time = timezone.timedelta(0)
    if employee.clock_in_time and employee.clock_out_time:
        total_work_time = employee.clock_out_time - employee.clock_in_time
    
    # Calculate total break time in seconds
    total_break_time = timezone.timedelta(0)
    if employee.break_start_time and employee.break_end_time:
        total_break_time = employee.break_end_time - employee.break_start_time
    
    # Format the total work time and break time to display in hours, minutes, and seconds
    def format_timedelta(timedelta_obj):
        total_seconds = int(timedelta_obj.total_seconds())
        hours = total_seconds // 3600
        minutes = (total_seconds % 3600) // 60
        seconds = total_seconds % 60
        return f"{hours} hours, {minutes} minutes, {seconds} seconds"
    
    formatted_work_time = format_timedelta(total_work_time)
    formatted_break_time = format_timedelta(total_break_time)
    
    context = {
        "employee": employee,
        "total_work_time": formatted_work_time,
        "total_break_time": formatted_break_time,
        "assignments": assignments,  # Pass assignments to the template
    }
    return render(request, "employee_dashboard.html", context)

def clock(request, employee_id):
    employee = Employee.objects.get(id=employee_id)
    # Fetch relevant data for the employee dashboard

    
    # Fetch all assignments for the employee
    assignments = Assignment.objects.filter(employee=employee)
    
    # Calculate total work time in seconds
    total_work_time = timezone.timedelta(0)
    if employee.clock_in_time and employee.clock_out_time:
        total_work_time = employee.clock_out_time - employee.clock_in_time
    
    # Calculate total break time in seconds
    total_break_time = timezone.timedelta(0)
    if employee.break_start_time and employee.break_end_time:
        total_break_time = employee.break_end_time - employee.break_start_time
    
    # Format the total work time and break time to display in hours, minutes, and seconds
    def format_timedelta(timedelta_obj):
        total_seconds = int(timedelta_obj.total_seconds())
        hours = total_seconds // 3600
        minutes = (total_seconds % 3600) // 60
        seconds = total_seconds % 60
        return f"{hours} hours, {minutes} minutes, {seconds} seconds"
    
    formatted_work_time = format_timedelta(total_work_time)
    formatted_break_time = format_timedelta(total_break_time)
    
    context = {
        "employee": employee,
        "total_work_time": formatted_work_time,
        "total_break_time": formatted_break_time,
        "assignments": assignments,  # Pass assignments to the template
    }
    return render(request, "clock.html", context)

def assignment(request, employee_id):
    employee = Employee.objects.get(id=employee_id)
    # Fetch relevant data for the employee dashboard

    
    # Fetch all assignments for the employee
    assignments = Assignment.objects.filter(employee=employee)
    
    # Calculate total work time in seconds
    total_work_time = timezone.timedelta(0)
    if employee.clock_in_time and employee.clock_out_time:
        total_work_time = employee.clock_out_time - employee.clock_in_time
    
    # Calculate total break time in seconds
    total_break_time = timezone.timedelta(0)
    if employee.break_start_time and employee.break_end_time:
        total_break_time = employee.break_end_time - employee.break_start_time
    
    # Format the total work time and break time to display in hours, minutes, and seconds
    def format_timedelta(timedelta_obj):
        total_seconds = int(timedelta_obj.total_seconds())
        hours = total_seconds // 3600
        minutes = (total_seconds % 3600) // 60
        seconds = total_seconds % 60
        return f"{hours} hours, {minutes} minutes, {seconds} seconds"
    
    formatted_work_time = format_timedelta(total_work_time)
    formatted_break_time = format_timedelta(total_break_time)
    
    context = {
        "employee": employee,
        "total_work_time": formatted_work_time,
        "total_break_time": formatted_break_time,
        "assignments": assignments,  # Pass assignments to the template
    }
    return render(request, "assignment.html", context)

# views.py
from django.shortcuts import render, get_object_or_404, redirect
from .models import Assignment

from django.shortcuts import render, get_object_or_404, redirect
from .models import Assignment, Employee
from django.shortcuts import get_object_or_404, redirect, render

def update_assignment_status(request, assignment_id):
    assignment = get_object_or_404(Assignment, id=assignment_id)
    employee = assignment.employee  # Get the associated employee

    if request.method == "POST":
        report = request.POST.get("report", "")
        project_percentage = request.POST.get("project_percentage", "")  # Get the new field

        # Update the assignment fields
        assignment.status = 'Completed'
        assignment.report = report
        assignment.project_percentage = project_percentage  # Save the percentage
        assignment.save()

        return redirect('employee_dashboard', employee_id=employee.id)

    return render(request, "update_assignment_status.html", {"assignment": assignment})

from django.shortcuts import get_object_or_404, redirect
from .models import Assignment

def partial_project_update(request, assignment_id):
    assignment = get_object_or_404(Assignment, id=assignment_id)
    if request.method == 'POST':
        assignment.project_percentage = request.POST.get('project_percentage', '')
        assignment.partial_report = request.POST.get('partial_report', '')
        
        # You can optionally change the status to 'In Progress'
        if assignment.status == 'Pending':
            assignment.status = 'In Progress'
        
        assignment.save()
        return redirect('employee_dashboard', employee_id=assignment.employee.id)

def update_partial_assignment(request, assignment_id):
    assignment = get_object_or_404(Assignment, id=assignment_id)
    if request.method == "POST":
        percentage = request.POST.get("project_percentage")
        partial_report = request.POST.get("partial_report")

        assignment.project_percentage = percentage
        assignment.partial_report = partial_report

        if assignment.status == 'Pending':
            assignment.status = 'In Progress'

        assignment.save()
        return redirect('team_lead_dashboard', team_lead_id=assignment.team_lead.id)


def clock_in(request, employee_id):
    employee = Employee.objects.get(id=employee_id)
    if not employee.clock_in_time:
        employee.start_work()  # This method should set the current time as clock_in_time
        return redirect("employee_dashboard", employee_id=employee.id)
    return HttpResponse("You are already clocked in.")

def clock_out(request, employee_id):
    employee = Employee.objects.get(id=employee_id)
    if employee.clock_in_time and not employee.clock_out_time:
        employee.end_work()  # This method should set the current time as clock_out_time
        return redirect("employee_dashboard", employee_id=employee.id)
    return HttpResponse("You need to clock in first or have already clocked out.")

def start_break(request, employee_id):
    employee = Employee.objects.get(id=employee_id)
    if employee.clock_in_time and not employee.break_start_time:
        employee.start_break()  # This method should set the current time as break_start_time
        return redirect("employee_dashboard", employee_id=employee.id)
    return HttpResponse("You need to be clocked in or are already on a break.")

def end_break(request, employee_id):
    employee = Employee.objects.get(id=employee_id)
    if employee.break_start_time and not employee.break_end_time:
        employee.end_break()  # This method should set the current time as break_end_time
        return redirect("employee_dashboard", employee_id=employee.id)
    return HttpResponse("You are not currently on a break.")



def employee_logout(request, employee_id):
    employee = Employee.objects.get(id=employee_id)
    employee.logout_time = timezone.now()
    employee.save()
    return redirect("employee_login")


# views.py
from django.shortcuts import render, get_object_or_404, redirect
from .models import Project, Technology, TeamLead

def project_list(request):
    projects = Project.objects.all()
    return render(request, "project_list.html", {"projects": projects})

def edit_project(request, project_id):
    project = get_object_or_404(Project, id=project_id)
    if request.method == "POST":
        project.name = request.POST.get("project_name")
        project.start_date = request.POST.get("start_date")
        project.end_date = request.POST.get("end_date")
        project.description = request.POST.get("description")
        project.save()
        return redirect("project_list")
    return render(request, "edit_project.html", {"project": project})

def delete_project(request, project_id):
    project = get_object_or_404(Project, id=project_id)
    if request.method == "POST":
        project.delete()
        return redirect("project_list")
    return render(request, "delete_project.html", {"project": project})

from django.shortcuts import render, get_object_or_404
from .models import Technology, Employee

def technology_employees(request, technology_id):
    # Get the technology object
    technology = get_object_or_404(Technology, id=technology_id)
    
    # Get all employees associated with this technology
    employees = Employee.objects.filter(technologies=technology)
    
    # Render the template with the technology and its employees
    return render(request, 'technology_employees.html', {'technology': technology, 'employees': employees})

def emp_navbar(request):       
    return render(request, 'emp_navbar.html')


def home(request):       
    return render(request, 'home.html')


def leave_admin(request):
 
    all_leave_requests = LeaveRequest.objects.all().order_by('-start_date')  
 
    return render(request, "leave_admin.html", {
        "all_leave_requests": all_leave_requests  # Pass all leave requests to template
    })  

def manager_leave_emp(request):
 
    all_leave_requests = LeaveRequest.objects.all().order_by('-start_date')  
 
    return render(request, "manager_leave_emp.html", {
        "all_leave_requests": all_leave_requests  # Pass all leave requests to template
    })  




