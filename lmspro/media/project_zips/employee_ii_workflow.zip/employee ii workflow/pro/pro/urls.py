"""
URL configuration for pro project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""


from django.urls import path
from app import views
from django.conf import settings
from django.conf.urls.static import static


urlpatterns = [
    path('', views.admin_login, name='admin_login'),
    path('admin-dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('project_manager_login/', views.project_manager_login, name='project_manager_login'),
    path('project_manager_dashboard/', views.project_manager_dashboard, name='project_manager_dashboard'),
    
    path('view_employee_timings/', views.view_employee_timings, name='view_employee_timings'),
    path('add-technology/', views.add_technology, name='add_technology'),
    path('edit-technology/<int:tech_id>/', views.edit_technology, name='edit_technology'),
    path('delete-technology/<int:tech_id>/', views.delete_technology, name='delete_technology'),
    path('add-manager/<int:tech_id>/', views.add_manager, name='add_manager'),
    path('add-team-lead/<int:manager_id>/', views.add_team_lead, name='add_team_lead'),
    path('assign-project/<int:tech_id>/<int:team_lead_id>/', views.assign_project, name='assign_project'),
    path('manager_login/', views.manager_login, name='manager_login'),
    path('team_lead_login/', views.team_lead_login, name='team_lead_login'),
    path('manager_dashboard/<int:manager_id>/', views.manager_dashboard, name='manager_dashboard'),
    path('team_lead_dashboard/<int:team_lead_id>/', views.team_lead_dashboard, name='team_lead_dashboard'),
    path('assign_project/<int:tech_id>/<int:team_lead_id>/', views.assign_project, name='assign_project'),
    path('employee_login/', views.employee_login, name='employee_login'),
    path('add_employee/', views.add_employee, name='add_employee'),
    path('edit_employee/<str:employee_id>/', views.edit_employee, name='edit_employee'),
    path('delete_employee/<str:employee_id>/', views.delete_employee, name='delete_employee'),
    path('employee_list/', views.employee_list, name='employee_list'),
    
    path('assign_employees/<int:team_lead_id>/', views.assign_employees_to_team_lead, name='assign_employees_to_team_lead'),
    path('team_lead/<int:team_lead_id>/', views.team_lead_details, name='team_lead_details'),
    path('employee_dashboard/<int:employee_id>/', views.employee_dashboard, name='employee_dashboard'),
    path('clock/<int:employee_id>/', views.clock, name='clock'),
    path('assignment/<int:employee_id>/', views.assignment, name='assignment'),
    path("employee_logout/<int:employee_id>/", views.employee_logout, name="employee_logout"),

    path("clock_in/<int:employee_id>/", views.clock_in, name="clock_in"),
    path("clock_out/<int:employee_id>/", views.clock_out, name="clock_out"),
    path("start_break/<int:employee_id>/", views.start_break, name="start_break"),
    path("end_break/<int:employee_id>/", views.end_break, name="end_break"),

    path('admin/projects/', views.project_list, name='project_list'),
    path('admin/projects/edit/<int:project_id>/', views.edit_project, name='edit_project'),
    path('admin/projects/delete/<int:project_id>/', views.delete_project, name='delete_project'),
    path('request_leave/<int:employee_id>/', views.request_leave, name='request_leave'),
    path('team_lead_leave/<int:team_lead_id>/', views.team_lead_leave, name='team_lead_leave'),
    path('update_assignment_status/<int:assignment_id>/', views.update_assignment_status, name='update_assignment_status'),
    path('technology/<int:technology_id>/employees/', views.technology_employees, name='technology_employees'),
    path('emp_navbar/', views.emp_navbar, name='emp_navbar'),
    path('home/<int:employee_id>/', views.home, name='home'),
    path('leave_admin/', views.leave_admin, name='leave_admin'),
    path('manager_leave_emp/', views.manager_leave_emp, name='manager_leave_emp'),   
    path('assignment/<int:assignment_id>/partial/', views.partial_project_update, name='partial_project_update'),
    path('assignment/<int:assignment_id>/partial_update/', views.update_partial_assignment, name='update_partial_assignment'),

]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)